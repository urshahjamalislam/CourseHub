# Course Hub Security Specification & Invariants

## 1. Data Invariants
1. **Self-Assigned Role Prevention**: A student registering at `/users/{userId}` can ONLY create their profile with `role == 'student'` and cannot set `role` to `'admin'` or `'instructor'` unless already an admin.
2. **PII Isolation**: Private user profiles (`/users/{userId}`) containing `email`, `phone`, `educationLevel`, and `institution` are readable ONLY by the document owner (`request.auth.uid == userId`) or an administrator (`isAdmin()`). Public display metadata lives in `/public_profiles/{userId}`.
3. **Free vs Paid Enrollment Integrity**: Students may only self-create an active `/enrollments/{uid}_{courseId}` document if the referenced `/courses/{courseId}` exists, is `'published'`, and has `isFree == true`. Paid enrollments require admin verification or backend payment verification.
4. **Protected Lesson Content**: `/lesson_contents/{lessonId}` containing `youtubeVideoId` and downloadable PDF URLs is readable ONLY if the user is an admin, the course's instructor, the lesson has `isFreePreview == true`, or the user has an `'active'` enrollment for that course.
5. **Exam Answer Key Secrecy**: `/question_answers/{questionId}` is unreadable by students before submission unless `practiceMode == true` on the parent exam. Once the student creates `/exam_results/{uid}_{examId}`, they can view the answer key and their instant objective score.
6. **Immutable Ownership & Temporal Integrity**: `userId`, `createdAt`, and relational parent IDs (`courseId`, `lessonId`, `examId`) are immutable after creation; timestamps match `request.time`.
7. **Strict Path & Payload Bounds**: Every document ID matches `^[a-zA-Z0-9_\-]+$` (<= 128 chars), every string has explicit `.size()` bounds, and every create/update checks strict `keys().hasOnly(...)` / `affectedKeys().hasOnly(...)` to block shadow fields.

## 2. Dirty Dozen Adversarial Payloads (Verified Denied)
1. **Privilege Escalation on Signup**: `create /users/attacker` with `{ role: "admin" }` -> DENIED (`role == 'student'` enforced).
2. **Role Mutation on Profile Update**: `update /users/student1` with `{ role: "admin" }` -> DENIED (`affectedKeys().hasOnly(...)` excludes `role`).
3. **PII Scraping**: `get /users/victim` or `list /users` as `student1` -> DENIED (`isOwner` / `isAdmin` enforced).
4. **Free Bypass on Paid Course**: `create /enrollments/student1_paidCourse` when `courses/paidCourse.isFree == false` -> DENIED.
5. **Unverified Email Spoof**: `create /comments/c1` when `request.auth.token.email == 'mitamony146700@gmail.com'` and `email_verified == false` -> DENIED.
6. **Locked Lesson Video Scraping**: `get /lesson_contents/paidLesson1` by unenrolled student when `isFreePreview == false` -> DENIED.
7. **Exam Answer Key Cheating**: `get /question_answers/q1` before creating `/exam_results/student1_exam1` when `practiceMode == false` -> DENIED.
8. **Shadow Field Injection**: `create /comments/c2` with `{ isVerified: true, ...validFields }` -> DENIED (`keys().hasOnly(...)`).
9. **ID Poisoning**: `create /bookmarks/<1500-char-id>` -> DENIED (`isValidId` <= 128 chars).
10. **Comment Identity Spoofing**: `create /comments/c3` with `{ userId: "otherUser" }` -> DENIED (`incoming().userId == request.auth.uid`).
11. **Exam Score Tampering**: `update /exam_results/student1_exam1` after `graded == true` -> DENIED (terminal state lock).
12. **Payment Self-Verification**: `create /payments/p1` with `{ status: "verified" }` as student -> DENIED (`status == 'pending'` only for student creation, `verified` strictly admin/server).
