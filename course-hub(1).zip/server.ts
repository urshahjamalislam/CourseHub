import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface GatewayConfigStatus {
  id: 'bkash' | 'nagad' | 'rocket' | 'sslcommerz';
  name: string;
  configured: boolean;
  requiredEnvVars: string[];
  description: string;
}

function getGatewayStatuses(): GatewayConfigStatus[] {
  return [
    {
      id: 'bkash',
      name: 'bKash Checkout',
      configured: Boolean(
        process.env.BKASH_APP_KEY &&
          process.env.BKASH_APP_SECRET &&
          process.env.BKASH_USERNAME &&
          process.env.BKASH_PASSWORD
      ),
      requiredEnvVars: ['BKASH_APP_KEY', 'BKASH_APP_SECRET', 'BKASH_USERNAME', 'BKASH_PASSWORD'],
      description: 'bKash Tokenized Checkout API for instant mobile wallet payments.',
    },
    {
      id: 'nagad',
      name: 'Nagad Payment Gateway',
      configured: Boolean(
        process.env.NAGAD_MERCHANT_ID &&
          process.env.NAGAD_PUBLIC_KEY &&
          process.env.NAGAD_PRIVATE_KEY
      ),
      requiredEnvVars: ['NAGAD_MERCHANT_ID', 'NAGAD_PUBLIC_KEY', 'NAGAD_PRIVATE_KEY'],
      description: 'Nagad Merchant PGW with RSA signature verification.',
    },
    {
      id: 'rocket',
      name: 'Rocket (DBBL)',
      configured: Boolean(process.env.ROCKET_MERCHANT_ID && process.env.ROCKET_API_SECRET),
      requiredEnvVars: ['ROCKET_MERCHANT_ID', 'ROCKET_API_SECRET'],
      description: 'Dutch-Bangla Bank Rocket merchant payment gateway.',
    },
    {
      id: 'sslcommerz',
      name: 'SSLCommerz',
      configured: Boolean(process.env.SSLCOMMERZ_STORE_ID && process.env.SSLCOMMERZ_STORE_PASSWORD),
      requiredEnvVars: ['SSLCOMMERZ_STORE_ID', 'SSLCOMMERZ_STORE_PASSWORD'],
      description: 'Cards, mobile banking, and net banking aggregator for Bangladesh.',
    },
  ];
}

function sanitizePdfText(input: string): string {
  return input.replace(/[^\x20-\x7E]/g, ' ').replace(/[()\\]/g, '\\$&').slice(0, 140);
}

function buildSimplePdf(title: string, subtitle: string, lines: string[]): Buffer {
  const safeTitle = sanitizePdfText(title || 'Course Hub Study Material');
  const safeSubtitle = sanitizePdfText(subtitle || 'Course Hub — Learn • Grow • Achieve');
  const safeLines = lines.slice(0, 22).map((l) => sanitizePdfText(l));

  const streamOps: string[] = [
    'BT',
    '/F1 18 Tf',
    '56 760 Td',
    `(${safeTitle}) Tj`,
    '/F1 11 Tf',
    '0 -24 Td',
    `(${safeSubtitle}) Tj`,
    '0 -18 Td',
    '(----------------------------------------------------------------------) Tj',
  ];

  for (const line of safeLines) {
    streamOps.push('0 -18 Td');
    streamOps.push(`(${line}) Tj`);
  }
  streamOps.push('ET');

  const contentStream = streamOps.join('\n');
  const contentBytes = Buffer.byteLength(contentStream, 'utf8');

  const objects: string[] = [
    '1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n',
    '2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n',
    '3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n',
    `4 0 obj\n<< /Length ${contentBytes} >>\nstream\n${contentStream}\nendstream\nendobj\n`,
    '5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += obj;
  }
  const xrefOffset = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return Buffer.from(pdf, 'utf8');
}

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'course-hub-api', timestamp: new Date().toISOString() });
  });

  app.get('/api/payments/gateways', (_req, res) => {
    res.json({ gateways: getGatewayStatuses() });
  });

  app.post('/api/payments/initiate', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication required to initiate a payment.' });
      return;
    }

    const { gateway, courseId, amount } = req.body as {
      gateway?: string;
      courseId?: string;
      amount?: number;
    };

    const gateways = getGatewayStatuses();
    const target = gateways.find((g) => g.id === gateway);
    if (!target) {
      res.status(400).json({ error: 'Unsupported payment gateway selected.' });
      return;
    }

    if (!target.configured) {
      res.status(503).json({
        configured: false,
        gateway: target.id,
        gatewayName: target.name,
        requiredEnvVars: target.requiredEnvVars,
        message: `${target.name} is not configured on the server yet. Add ${target.requiredEnvVars.join(', ')} to server environment variables to enable live checkout. No simulated payment was approved.`,
      });
      return;
    }

    res.status(200).json({
      configured: true,
      gateway: target.id,
      courseId,
      amount,
      message: `${target.name} credentials detected. Ready for merchant session creation.`,
    });
  });

  app.post('/api/payments/verify', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication required for payment verification.' });
      return;
    }

    const { gateway } = req.body as { gateway?: string };
    const gateways = getGatewayStatuses();
    const target = gateways.find((g) => g.id === gateway);

    if (!target || !target.configured) {
      res.status(503).json({
        verified: false,
        configured: false,
        requiredEnvVars: target?.requiredEnvVars ?? [],
        message:
          'Backend payment verification requires live merchant gateway credentials. Admins can also manually verify bank/MFS transaction references in the Admin Payments panel.',
      });
      return;
    }

    res.status(501).json({
      verified: false,
      message: 'Connect live merchant callback URL for automated verification.',
    });
  });

  app.get('/api/resources/pdf', (req, res) => {
    const title = String(req.query.title || 'Course Hub Lecture Notes');
    const course = String(req.query.course || 'Course Hub Curriculum');
    const summary = String(
      req.query.summary || 'Structured study sheet generated for Course Hub learners.'
    );

    const lines = [
      `Course: ${course}`,
      `Document: ${title}`,
      '',
      'Key Learning Outline:',
      summary.slice(0, 80),
      summary.slice(80, 160),
      summary.slice(160, 240),
      '',
      'Prepared for enrolled students on Course Hub.',
      'Learn • Grow • Achieve',
    ].filter((l) => l !== undefined);

    const pdfBuffer = buildSimplePdf(title, `Course Hub — ${course}`, lines);
    const safeFilename =
      title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') || 'course-hub-resource';

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}.pdf"`);
    res.send(pdfBuffer);
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Course Hub server running on http://0.0.0.0:${port}`);
  });
}

startServer();
