import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  collection,
  onSnapshot,
  query,
  where,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';
import {
  db,
  handleFirestoreError,
  OperationType,
  generateDocId,
  clampStr,
} from '../lib/firebase';
import { useAuth } from './AuthContext';
import {
  Announcement,
  BookmarkItem,
  Category,
  Chapter,
  Course,
  Enrollment,
  Exam,
  ExamResult,
  Lesson,
  LessonProgress,
  LiveClass,
  NotificationItem,
  SiteSettings,
  StudyMaterial,
} from '../types/lms';
import {
  DEMO_ANNOUNCEMENTS,
  DEMO_CATEGORIES,
  DEMO_CHAPTERS,
  DEMO_COURSES,
  DEMO_EXAMS,
  DEMO_LESSONS,
  DEMO_LIVE_CLASSES,
  DEMO_STUDY_MATERIALS,
} from '../data/demoCurriculum';

interface LmsDataContextValue {
  categories: Category[];
  courses: Course[];
  chapters: Chapter[];
  lessons: Lesson[];
  enrollments: Enrollment[];
  lessonProgress: LessonProgress[];
  bookmarks: BookmarkItem[];
  notifications: NotificationItem[];
  studyMaterials: StudyMaterial[];
  liveClasses: LiveClass[];
  exams: Exam[];
  examResults: ExamResult[];
  announcements: Announcement[];
  siteSettings: SiteSettings;
  isUsingDemoPreview: boolean;
  loadingCatalog: boolean;
  enrollInFreeCourse: (course: Course) => Promise<void>;
  toggleBookmark: (item: {
    itemType: 'lesson' | 'material' | 'course';
    itemId: string;
    courseId?: string;
    title: string;
    subtitle?: string;
  }) => Promise<boolean>;
  markNotificationRead: (notificationId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  recordLessonVisit: (courseId: string, lessonId: string) => Promise<void>;
  toggleLessonCompleted: (courseId: string, lessonId: string, completed: boolean) => Promise<void>;
  savePersonalNotes: (courseId: string, lessonId: string, notes: string) => Promise<void>;
}

const DEFAULT_SETTINGS: SiteSettings = {
  id: 'global',
  siteName: 'Course Hub',
  tagline: 'Learn • Grow • Achieve',
  heroTitle: 'Learn Without Limits.',
  heroSubtitle: 'Discover courses, improve your skills, and achieve your goals.',
  contactEmail: 'support@coursehub.edu',
  contactPhone: '+880 1700-000000',
  contactAddress: 'Dhaka, Bangladesh',
  defaultTheme: 'dark',
  allowRegistration: true,
  updatedAt: new Date().toISOString(),
};

const LmsDataContext = createContext<LmsDataContextValue | undefined>(undefined);

export function LmsDataProvider({ children }: { children: React.ReactNode }) {
  const { firebaseUser, isVerified, isAdmin, authReady } = useAuth();

  const [dbCategories, setDbCategories] = useState<Category[]>([]);
  const [dbCourses, setDbCourses] = useState<Course[]>([]);
  const [dbChapters, setDbChapters] = useState<Chapter[]>([]);
  const [dbLessons, setDbLessons] = useState<Lesson[]>([]);
  const [dbMaterials, setDbMaterials] = useState<StudyMaterial[]>([]);
  const [dbLiveClasses, setDbLiveClasses] = useState<LiveClass[]>([]);
  const [dbExams, setDbExams] = useState<Exam[]>([]);
  const [dbAnnouncements, setDbAnnouncements] = useState<Announcement[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);

  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [lessonProgress, setLessonProgress] = useState<LessonProgress[]>([]);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [examResults, setExamResults] = useState<ExamResult[]>([]);

  const [loadingCatalog, setLoadingCatalog] = useState(true);

  useEffect(() => {
    if (!authReady) return;

    const catQ = isAdmin
      ? collection(db, 'categories')
      : query(collection(db, 'categories'), where('isVisible', '==', true));
    const courseQ = isAdmin
      ? collection(db, 'courses')
      : query(collection(db, 'courses'), where('status', '==', 'published'));
    const lessonQ = isAdmin
      ? collection(db, 'lessons')
      : query(collection(db, 'lessons'), where('status', '==', 'published'));
    const examQ = isAdmin
      ? collection(db, 'exams')
      : query(collection(db, 'exams'), where('status', '==', 'published'));

    const unsubCats = onSnapshot(
      catQ,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Category).sort((a, b) => a.order - b.order);
        setDbCategories(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'categories')
    );

    const unsubCourses = onSnapshot(
      courseQ,
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as Course)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setDbCourses(list);
        setLoadingCatalog(false);
      },
      (err) => {
        setLoadingCatalog(false);
        handleFirestoreError(err, OperationType.LIST, 'courses');
      }
    );

    const unsubChapters = onSnapshot(
      collection(db, 'chapters'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Chapter).sort((a, b) => a.order - b.order);
        setDbChapters(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'chapters')
    );

    const unsubLessons = onSnapshot(
      lessonQ,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Lesson).sort((a, b) => a.order - b.order);
        setDbLessons(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'lessons')
    );

    const unsubMats = onSnapshot(
      collection(db, 'study_materials'),
      (snap) => {
        setDbMaterials(snap.docs.map((d) => d.data() as StudyMaterial));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'study_materials')
    );

    const unsubLive = onSnapshot(
      collection(db, 'live_classes'),
      (snap) => {
        setDbLiveClasses(snap.docs.map((d) => d.data() as LiveClass));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'live_classes')
    );

    const unsubExams = onSnapshot(
      examQ,
      (snap) => {
        setDbExams(snap.docs.map((d) => d.data() as Exam));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'exams')
    );

    const unsubAnn = onSnapshot(
      collection(db, 'announcements'),
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as Announcement)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setDbAnnouncements(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'announcements')
    );

    const unsubSettings = onSnapshot(
      doc(db, 'site_settings', 'global'),
      (snap) => {
        if (snap.exists()) {
          setSiteSettings(snap.data() as SiteSettings);
        }
      },
      () => {
        // Fallback to default settings if not yet created
      }
    );

    return () => {
      unsubCats();
      unsubCourses();
      unsubChapters();
      unsubLessons();
      unsubMats();
      unsubLive();
      unsubExams();
      unsubAnn();
      unsubSettings();
    };
  }, [authReady, isAdmin]);

  // Authenticated student subscriptions
  useEffect(() => {
    if (!authReady || !firebaseUser || !isVerified) {
      setEnrollments([]);
      setLessonProgress([]);
      setBookmarks([]);
      setNotifications([]);
      setExamResults([]);
      return;
    }

    const uid = firebaseUser.uid;
    const unsubEnroll = onSnapshot(
      query(collection(db, 'enrollments'), where('userId', '==', uid)),
      (snap) => setEnrollments(snap.docs.map((d) => d.data() as Enrollment)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'enrollments')
    );

    const unsubProg = onSnapshot(
      query(collection(db, 'lesson_progress'), where('userId', '==', uid)),
      (snap) => setLessonProgress(snap.docs.map((d) => d.data() as LessonProgress)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'lesson_progress')
    );

    const unsubBook = onSnapshot(
      query(collection(db, 'bookmarks'), where('userId', '==', uid)),
      (snap) => setBookmarks(snap.docs.map((d) => d.data() as BookmarkItem)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'bookmarks')
    );

    const unsubNotif = onSnapshot(
      query(collection(db, 'notifications'), where('userId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as NotificationItem)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setNotifications(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    const unsubResults = onSnapshot(
      query(collection(db, 'exam_results'), where('userId', '==', uid)),
      (snap) => setExamResults(snap.docs.map((d) => d.data() as ExamResult)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'exam_results')
    );

    return () => {
      unsubEnroll();
      unsubProg();
      unsubBook();
      unsubNotif();
      unsubResults();
    };
  }, [authReady, firebaseUser, isVerified]);

  // Show clearly labeled demo preview catalog ONLY if Firestore has 0 courses
  const isUsingDemoPreview = !loadingCatalog && dbCourses.length === 0;

  const categories = dbCategories.length > 0 ? dbCategories : isUsingDemoPreview ? DEMO_CATEGORIES : [];
  const courses = dbCourses.length > 0 ? dbCourses : isUsingDemoPreview ? DEMO_COURSES : [];
  const chapters = dbChapters.length > 0 ? dbChapters : isUsingDemoPreview ? DEMO_CHAPTERS : [];
  const lessons = dbLessons.length > 0 ? dbLessons : isUsingDemoPreview ? DEMO_LESSONS : [];
  const studyMaterials = dbMaterials.length > 0 ? dbMaterials : isUsingDemoPreview ? DEMO_STUDY_MATERIALS : [];
  const liveClasses = dbLiveClasses.length > 0 ? dbLiveClasses : isUsingDemoPreview ? DEMO_LIVE_CLASSES : [];
  const exams = dbExams.length > 0 ? dbExams : isUsingDemoPreview ? DEMO_EXAMS : [];
  const announcements = dbAnnouncements.length > 0 ? dbAnnouncements : isUsingDemoPreview ? DEMO_ANNOUNCEMENTS : [];

  const enrollInFreeCourse = async (course: Course) => {
    if (!firebaseUser || !isVerified) {
      throw new Error('Please sign in with a verified account to enroll.');
    }
    if (!course.isFree) {
      throw new Error('Paid courses require verified payment before enrollment.');
    }
    if (isUsingDemoPreview) {
      throw new Error('Demo preview catalog is read-only until an administrator seeds courses to Firestore.');
    }
    const id = `${firebaseUser.uid}_${course.id}`;
    const now = new Date().toISOString();
    const payload: Enrollment = {
      id,
      userId: firebaseUser.uid,
      courseId: course.id,
      courseTitle: clampStr(course.title, 160),
      status: 'active',
      progressPercent: 0,
      completedLessonsCount: 0,
      enrolledAt: now,
      updatedAt: now,
    };
    try {
      await setDoc(doc(db, 'enrollments', id), payload);
      const notifId = generateDocId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: firebaseUser.uid,
        type: 'enrollment',
        title: 'Enrollment Confirmed',
        message: `You are now enrolled in ${clampStr(course.title, 120)}.`,
        link: `course:${course.id}`,
        read: false,
        createdAt: now,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `enrollments/${id}`);
    }
  };

  const toggleBookmark = async (item: {
    itemType: 'lesson' | 'material' | 'course';
    itemId: string;
    courseId?: string;
    title: string;
    subtitle?: string;
  }) => {
    if (!firebaseUser || !isVerified) {
      throw new Error('Sign in to save bookmarks.');
    }
    const id = `${firebaseUser.uid}_${item.itemType}_${item.itemId}`;
    const existing = bookmarks.find((b) => b.id === id);
    try {
      if (existing) {
        await deleteDoc(doc(db, 'bookmarks', id));
        return false;
      } else {
        await setDoc(doc(db, 'bookmarks', id), {
          id,
          userId: firebaseUser.uid,
          itemType: item.itemType,
          itemId: item.itemId,
          courseId: item.courseId || '',
          title: clampStr(item.title, 200),
          subtitle: clampStr(item.subtitle || '', 200),
          createdAt: new Date().toISOString(),
        });
        return true;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `bookmarks/${id}`);
    }
  };

  const markNotificationRead = async (notificationId: string) => {
    try {
      await updateDoc(doc(db, 'notifications', notificationId), { read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `notifications/${notificationId}`);
    }
  };

  const markAllNotificationsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    await Promise.all(unread.map((n) => markNotificationRead(n.id)));
  };

  const recalculateCourseProgress = async (courseId: string, updatedLessonId: string, completedState: boolean) => {
    if (!firebaseUser) return;
    const enrollment = enrollments.find((e) => e.courseId === courseId && e.status === 'active');
    if (!enrollment) return;

    const courseLessons = lessons.filter((l) => l.courseId === courseId && l.status === 'published');
    const total = Math.max(courseLessons.length, 1);
    const completedSet = new Set(
      lessonProgress.filter((p) => p.courseId === courseId && p.completed).map((p) => p.lessonId)
    );
    if (completedState) completedSet.add(updatedLessonId);
    else completedSet.delete(updatedLessonId);

    const completedCount = completedSet.size;
    const progressPercent = Math.min(100, Math.round((completedCount / total) * 100));

    try {
      await updateDoc(doc(db, 'enrollments', enrollment.id), {
        lastLessonId: updatedLessonId,
        completedLessonsCount: completedCount,
        progressPercent,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `enrollments/${enrollment.id}`);
    }
  };

  const recordLessonVisit = async (courseId: string, lessonId: string) => {
    if (!firebaseUser || !isVerified) return;
    const id = `${firebaseUser.uid}_${lessonId}`;
    const existing = lessonProgress.find((p) => p.id === id);
    const now = new Date().toISOString();
    try {
      if (existing) {
        await updateDoc(doc(db, 'lesson_progress', id), {
          lastWatchedAt: now,
          updatedAt: now,
        });
      } else {
        await setDoc(doc(db, 'lesson_progress', id), {
          id,
          userId: firebaseUser.uid,
          courseId,
          lessonId,
          completed: false,
          personalNotes: '',
          lastWatchedAt: now,
          updatedAt: now,
        });
      }
      const enrollment = enrollments.find((e) => e.courseId === courseId && e.status === 'active');
      if (enrollment) {
        await updateDoc(doc(db, 'enrollments', enrollment.id), {
          lastLessonId: lessonId,
          updatedAt: now,
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `lesson_progress/${id}`);
    }
  };

  const toggleLessonCompleted = async (courseId: string, lessonId: string, completed: boolean) => {
    if (!firebaseUser || !isVerified) {
      throw new Error('Sign in to track lesson completion.');
    }
    const id = `${firebaseUser.uid}_${lessonId}`;
    const existing = lessonProgress.find((p) => p.id === id);
    const now = new Date().toISOString();
    try {
      if (existing) {
        await updateDoc(doc(db, 'lesson_progress', id), {
          completed,
          lastWatchedAt: now,
          updatedAt: now,
        });
      } else {
        await setDoc(doc(db, 'lesson_progress', id), {
          id,
          userId: firebaseUser.uid,
          courseId,
          lessonId,
          completed,
          personalNotes: '',
          lastWatchedAt: now,
          updatedAt: now,
        });
      }
      await recalculateCourseProgress(courseId, lessonId, completed);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `lesson_progress/${id}`);
    }
  };

  const savePersonalNotes = async (courseId: string, lessonId: string, notes: string) => {
    if (!firebaseUser || !isVerified) {
      throw new Error('Sign in to save personal notes.');
    }
    const id = `${firebaseUser.uid}_${lessonId}`;
    const existing = lessonProgress.find((p) => p.id === id);
    const now = new Date().toISOString();
    const clampedNotes = clampStr(notes, 8000);
    try {
      if (existing) {
        await updateDoc(doc(db, 'lesson_progress', id), {
          personalNotes: clampedNotes,
          updatedAt: now,
        });
      } else {
        await setDoc(doc(db, 'lesson_progress', id), {
          id,
          userId: firebaseUser.uid,
          courseId,
          lessonId,
          completed: false,
          personalNotes: clampedNotes,
          lastWatchedAt: now,
          updatedAt: now,
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `lesson_progress/${id}`);
    }
  };

  return (
    <LmsDataContext.Provider
      value={{
        categories,
        courses,
        chapters,
        lessons,
        enrollments,
        lessonProgress,
        bookmarks,
        notifications,
        studyMaterials,
        liveClasses,
        exams,
        examResults,
        announcements,
        siteSettings,
        isUsingDemoPreview,
        loadingCatalog,
        enrollInFreeCourse,
        toggleBookmark,
        markNotificationRead,
        markAllNotificationsRead,
        recordLessonVisit,
        toggleLessonCompleted,
        savePersonalNotes,
      }}
    >
      {children}
    </LmsDataContext.Provider>
  );
}

export function useLmsData() {
  const ctx = useContext(LmsDataContext);
  if (!ctx) throw new Error('useLmsData must be used inside LmsDataProvider');
  return ctx;
}
