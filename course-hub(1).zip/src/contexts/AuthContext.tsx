import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  BOOTSTRAPPED_ADMIN_EMAIL,
  clampStr,
  handleFirestoreError,
  OperationType,
  testConnection,
} from '../lib/firebase';
import { UserProfile, UserRole } from '../types/lms';

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  authReady: boolean;
  isAdmin: boolean;
  isInstructor: boolean;
  isVerified: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (
    email: string,
    password: string,
    displayName: string,
    extra?: { phone?: string; educationLevel?: string; institution?: string }
  ) => Promise<void>;
  sendResetEmail: (email: string) => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfileData: (updates: {
    displayName: string;
    phone?: string;
    educationLevel?: string;
    institution?: string;
    photoURL?: string;
  }) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [hasAdminDoc, setHasAdminDoc] = useState(false);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    testConnection();
  }, []);

  const syncUserProfile = async (
    user: User,
    extra?: { displayName?: string; phone?: string; educationLevel?: string; institution?: string }
  ) => {
    if (!user.emailVerified) {
      setProfile({
        uid: user.uid,
        displayName: user.displayName || extra?.displayName || 'Student',
        email: user.email || '',
        phone: extra?.phone || '',
        photoURL: user.photoURL || '',
        educationLevel: extra?.educationLevel || '',
        institution: extra?.institution || '',
        role: 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      setHasAdminDoc(false);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    const publicRef = doc(db, 'public_profiles', user.uid);
    const adminRef = doc(db, 'admins', user.uid);

    const isBootstrapped = user.email === BOOTSTRAPPED_ADMIN_EMAIL && user.emailVerified;

    let adminExists = false;
    try {
      const adminSnap = await getDoc(adminRef);
      adminExists = adminSnap.exists();
    } catch {
      adminExists = false;
    }
    setHasAdminDoc(adminExists || isBootstrapped);

    try {
      const snap = await getDoc(userRef);
      const now = new Date().toISOString();
      if (!snap.exists()) {
        const assignedRole: UserRole = isBootstrapped || adminExists ? 'admin' : 'student';
        const newProfile: UserProfile = {
          uid: user.uid,
          displayName: clampStr(extra?.displayName || user.displayName || user.email?.split('@')[0] || 'Learner', 120),
          email: clampStr(user.email || '', 200),
          phone: clampStr(extra?.phone || '', 30),
          photoURL: clampStr(user.photoURL || '', 500),
          educationLevel: clampStr(extra?.educationLevel || 'HSC', 80),
          institution: clampStr(extra?.institution || '', 160),
          role: assignedRole,
          createdAt: now,
          updatedAt: now,
        };
        await setDoc(userRef, newProfile);
        await setDoc(publicRef, {
          uid: newProfile.uid,
          displayName: newProfile.displayName,
          photoURL: newProfile.photoURL || '',
          role: newProfile.role,
          title: assignedRole === 'admin' ? 'Platform Administrator' : 'Student',
          updatedAt: now,
        });
        setProfile(newProfile);
      } else {
        const existing = snap.data() as UserProfile;
        setProfile(existing);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    }
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          await syncUserProfile(user);
        } catch (err) {
          console.error('Error syncing user profile:', err);
        }
      } else {
        setProfile(null);
        setHasAdminDoc(false);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  const signInWithGoogle = async () => {
    const res = await signInWithPopup(auth, googleProvider);
    await syncUserProfile(res.user);
  };

  const signInWithEmail = async (email: string, password: string) => {
    const res = await signInWithEmailAndPassword(auth, email.trim(), password);
    await syncUserProfile(res.user);
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    displayName: string,
    extra?: { phone?: string; educationLevel?: string; institution?: string }
  ) => {
    const res = await createUserWithEmailAndPassword(auth, email.trim(), password);
    await updateProfile(res.user, { displayName: clampStr(displayName, 120) });
    await sendEmailVerification(res.user);
    await syncUserProfile(res.user, { displayName, ...extra });
  };

  const sendResetEmail = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const resendVerificationEmail = async () => {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
    }
  };

  const refreshUser = async () => {
    if (auth.currentUser) {
      await auth.currentUser.reload();
      const updated = auth.currentUser;
      setFirebaseUser({ ...updated } as User);
      await syncUserProfile(updated);
    }
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
    setHasAdminDoc(false);
  };

  const updateProfileData = async (updates: {
    displayName: string;
    phone?: string;
    educationLevel?: string;
    institution?: string;
    photoURL?: string;
  }) => {
    if (!firebaseUser || !firebaseUser.emailVerified) {
      throw new Error('Verified account required to update profile.');
    }
    const now = new Date().toISOString();
    const payload = {
      displayName: clampStr(updates.displayName, 120),
      phone: clampStr(updates.phone || '', 30),
      educationLevel: clampStr(updates.educationLevel || '', 80),
      institution: clampStr(updates.institution || '', 160),
      photoURL: clampStr(updates.photoURL || '', 500),
      updatedAt: now,
    };

    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), payload);
      await updateDoc(doc(db, 'public_profiles', firebaseUser.uid), {
        displayName: payload.displayName,
        photoURL: payload.photoURL,
        updatedAt: now,
      });
      setProfile((prev) => (prev ? { ...prev, ...payload } : null));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const isBootstrappedAdmin =
    Boolean(firebaseUser?.emailVerified) && firebaseUser?.email === BOOTSTRAPPED_ADMIN_EMAIL;
  const isAdmin = isBootstrappedAdmin || hasAdminDoc;
  const isInstructor = isAdmin || profile?.role === 'instructor';
  const isVerified = Boolean(firebaseUser?.emailVerified);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        authReady,
        isAdmin,
        isInstructor,
        isVerified,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        sendResetEmail,
        resendVerificationEmail,
        refreshUser,
        logout,
        updateProfileData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
