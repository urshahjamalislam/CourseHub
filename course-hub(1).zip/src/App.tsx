import { useEffect, useState } from 'react';
import { AppRoute } from './types/lms';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './contexts/ToastContext';
import { AuthProvider } from './contexts/AuthContext';
import { LmsDataProvider } from './contexts/LmsDataContext';
import { AppShell } from './components/layout/AppShell';
import { HomePage } from './components/pages/HomePage';
import { ExploreCoursesPage } from './components/pages/ExploreCoursesPage';
import { CourseDetailsPage } from './components/pages/CourseDetailsPage';
import { LectureViewerPage } from './components/pages/LectureViewerPage';
import { StudentDashboardPage } from './components/pages/StudentDashboardPage';
import { AuthPage } from './components/pages/AuthPage';
import {
  BookmarksPage,
  InfoPage,
  LearningHistoryPage,
  NotificationsPage,
  ProfilePage,
  SettingsPage,
} from './components/pages/ProfileAndSettingsPages';
import { LiveClassesPage } from './components/pages/LiveClassesPage';
import { ExamsPage } from './components/pages/ExamsPage';
import { StudyMaterialsPage } from './components/pages/StudyMaterialsPage';
import { CommunityPage } from './components/pages/CommunityPage';
import { InstructorPanelPage } from './components/pages/InstructorPanelPage';
import { AdminPanelPage } from './components/pages/AdminPanelPage';

function getInitialRoute(): AppRoute {
  try {
    const pathname = window.location.pathname.replace(/\/+$/, '') || '/';
    const params = new URLSearchParams(window.location.search);
    const course = params.get('course');
    const lesson = params.get('lesson');
    if (course && lesson) return { page: 'lecture', courseId: course, lessonId: lesson };
    if (course) return { page: 'course', courseId: course };

    const pageParam = params.get('page');
    const target = pageParam ? `/${pageParam}` : pathname;

    if (target === '/admin') return { page: 'admin', tab: 'overview' };
    if (target === '/instructor') return { page: 'instructor' };
    if (target === '/explore') return { page: 'explore' };
    if (target === '/dashboard') return { page: 'dashboard' };
    if (target === '/live-classes') return { page: 'live-classes' };
    if (target === '/exams') return { page: 'exams' };
    if (target === '/materials') return { page: 'materials' };
    if (target === '/community') return { page: 'community' };
    if (target === '/bookmarks') return { page: 'bookmarks' };
    if (target === '/history') return { page: 'history' };
    if (target === '/notifications') return { page: 'notifications' };
    if (target === '/profile') return { page: 'profile' };
    if (target === '/settings') return { page: 'settings' };
    if (target === '/auth' || target === '/login') return { page: 'auth', mode: 'login' };
    if (target === '/signup') return { page: 'auth', mode: 'signup' };
    if (target === '/about') return { page: 'info', section: 'about' };
    if (target === '/contact') return { page: 'info', section: 'contact' };
    if (target === '/privacy') return { page: 'info', section: 'privacy' };
    if (target === '/terms') return { page: 'info', section: 'terms' };
  } catch {
    // ignore URL parse issues
  }
  return { page: 'home' };
}

function routeToUrl(next: AppRoute): string {
  switch (next.page) {
    case 'home':
      return '/';
    case 'explore': {
      const p = new URLSearchParams();
      if (next.query) p.set('q', next.query);
      if (next.categoryId) p.set('cat', next.categoryId);
      const qs = p.toString();
      return qs ? `/explore?${qs}` : '/explore';
    }
    case 'course':
      return `/?course=${encodeURIComponent(next.courseId)}`;
    case 'lecture':
      return next.lessonId
        ? `/?course=${encodeURIComponent(next.courseId)}&lesson=${encodeURIComponent(next.lessonId)}`
        : `/?course=${encodeURIComponent(next.courseId)}`;
    case 'auth':
      return next.mode === 'signup' ? '/signup' : '/auth';
    case 'info':
      return `/${next.section}`;
    default:
      return `/${next.page}`;
  }
}

function CourseHubRouter() {
  const [route, setRoute] = useState<AppRoute>(getInitialRoute);

  const navigate = (next: AppRoute) => {
    setRoute(next);
    try {
      const targetUrl = routeToUrl(next);
      const currentUrl = window.location.pathname + window.location.search;
      if (currentUrl !== targetUrl) {
        window.history.pushState(null, '', targetUrl);
      }
    } catch {
      // ignore history errors in restricted iframes
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const onPop = () => setRoute(getInitialRoute());
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  return (
    <AppShell route={route} onNavigate={navigate}>
      {route.page === 'home' && <HomePage onNavigate={navigate} />}
      {route.page === 'explore' && (
        <ExploreCoursesPage
          initialQuery={route.query}
          initialCategoryId={route.categoryId}
          onNavigate={navigate}
        />
      )}
      {route.page === 'course' && (
        <CourseDetailsPage courseId={route.courseId} onNavigate={navigate} />
      )}
      {route.page === 'lecture' && (
        <LectureViewerPage
          courseId={route.courseId}
          lessonId={route.lessonId}
          onNavigate={navigate}
        />
      )}
      {route.page === 'dashboard' && <StudentDashboardPage onNavigate={navigate} />}
      {route.page === 'live-classes' && <LiveClassesPage />}
      {route.page === 'exams' && (
        <ExamsPage initialExamId={route.examId} onNavigate={navigate} />
      )}
      {route.page === 'materials' && <StudyMaterialsPage />}
      {route.page === 'community' && <CommunityPage initialCourseId={route.courseId} />}
      {route.page === 'bookmarks' && <BookmarksPage onNavigate={navigate} />}
      {route.page === 'history' && <LearningHistoryPage onNavigate={navigate} />}
      {route.page === 'notifications' && <NotificationsPage onNavigate={navigate} />}
      {route.page === 'profile' && <ProfilePage onNavigate={navigate} />}
      {route.page === 'settings' && <SettingsPage onNavigate={navigate} />}
      {route.page === 'auth' && (
        <AuthPage initialMode={route.mode} onNavigate={navigate} />
      )}
      {route.page === 'instructor' && <InstructorPanelPage onNavigate={navigate} />}
      {route.page === 'admin' && (
        <AdminPanelPage initialTab={route.tab} onNavigate={navigate} />
      )}
      {route.page === 'info' && (
        <InfoPage section={route.section} onNavigate={navigate} />
      )}
    </AppShell>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <ToastProvider>
          <AuthProvider>
            <LmsDataProvider>
              <CourseHubRouter />
            </LmsDataProvider>
          </AuthProvider>
        </ToastProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
