import React, { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  ChevronDown,
  ChevronRight,
  Copy,
  Eye,
  FileText,
  GripVertical,
  Plus,
  Save,
  Trash2,
  Video,
} from 'lucide-react';
import {
  deleteDoc,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  AppRoute,
  Chapter,
  Course,
  CourseLevel,
  Lesson,
  LessonContent,
  PublishStatus,
} from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import {
  clampStr,
  db,
  extractYouTubeId,
  generateDocId,
  handleFirestoreError,
  OperationType,
  slugify,
} from '../../lib/firebase';

interface CourseBuilderProps {
  initialCourseId?: string;
  onNavigate: (route: AppRoute) => void;
  restrictToInstructorUid?: string;
}

const PRESET_THUMBNAILS = [
  { label: 'Physics Art', url: '/src/assets/images/course_physics_1795451152018.jpg' },
  { label: 'Chemistry Art', url: '/src/assets/images/course_chemistry_1795451151420.jpg' },
  { label: 'Math Art', url: '/src/assets/images/course_math_1795451152325.jpg' },
  { label: 'ICT Art', url: '/src/assets/images/course_ict_1795451151778.jpg' },
  { label: 'Study Desk', url: '/src/assets/images/hero_learning_academy_1795451152199.jpg' },
];

export function CourseBuilder({
  initialCourseId,
  onNavigate,
  restrictToInstructorUid,
}: CourseBuilderProps) {
  const { courses, chapters, lessons, categories, exams } = useLmsData();
  const { firebaseUser, profile } = useAuth();
  const { showToast, confirm } = useToast();

  const editableCourses = useMemo(
    () =>
      restrictToInstructorUid
        ? courses.filter((c) => c.instructorId === restrictToInstructorUid)
        : courses,
    [courses, restrictToInstructorUid]
  );

  const [selectedCourseId, setSelectedCourseId] = useState<string>(
    initialCourseId || editableCourses[0]?.id || 'NEW'
  );

  const activeCourse =
    selectedCourseId !== 'NEW' ? editableCourses.find((c) => c.id === selectedCourseId) : undefined;

  // Course Form State
  const [title, setTitle] = useState(activeCourse?.title || '');
  const [slug, setSlug] = useState(activeCourse?.slug || '');
  const [description, setDescription] = useState(activeCourse?.description || '');
  const [thumbnailUrl, setThumbnailUrl] = useState(
    activeCourse?.thumbnailUrl || PRESET_THUMBNAILS[0].url
  );
  const [bannerUrl, setBannerUrl] = useState(
    activeCourse?.bannerUrl || PRESET_THUMBNAILS[0].url
  );
  const [categoryId, setCategoryId] = useState(
    activeCourse?.categoryId || categories[0]?.id || 'cat_science'
  );
  const [instructorName, setInstructorName] = useState(
    activeCourse?.instructorName || profile?.displayName || 'Course Hub Instructor'
  );
  const [instructorTitle, setInstructorTitle] = useState(
    activeCourse?.instructorTitle || 'Senior Lecturer'
  );
  const [level, setLevel] = useState<CourseLevel>(activeCourse?.level || 'HSC');
  const [language, setLanguage] = useState(activeCourse?.language || 'Bangla & English');
  const [isFree, setIsFree] = useState<boolean>(activeCourse ? activeCourse.isFree : true);
  const [price, setPrice] = useState<number>(activeCourse?.price ?? 0);
  const [status, setStatus] = useState<PublishStatus>(activeCourse?.status || 'draft');
  const [isFeatured, setIsFeatured] = useState<boolean>(activeCourse?.isFeatured || false);
  const [durationText, setDurationText] = useState(activeCourse?.durationText || '2h 30m');
  const [requirementsText, setRequirementsText] = useState(
    (activeCourse?.requirements || []).join('\n')
  );
  const [outcomesText, setOutcomesText] = useState((activeCourse?.outcomes || []).join('\n'));
  const [savingCourse, setSavingCourse] = useState(false);

  // Chapter & Lesson UI state
  const [expandedChapters, setExpandedChapters] = useState<Record<string, boolean>>({});
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [newChapterDesc, setNewChapterDesc] = useState('');
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);

  // Lesson modal/drawer editor
  const [lessonModal, setLessonModal] = useState<{
    open: boolean;
    chapterId: string;
    editingLesson?: Lesson;
  } | null>(null);
  const [lTitle, setLTitle] = useState('');
  const [lDesc, setLDesc] = useState('');
  const [lYoutubeUrl, setLYoutubeUrl] = useState('');
  const [lDuration, setLDuration] = useState('45:00');
  const [lThumb, setLThumb] = useState('');
  const [lSlidesUrl, setLSlidesUrl] = useState('');
  const [lSlidesName, setLSlidesName] = useState('');
  const [lNotesPdfUrl, setLNotesPdfUrl] = useState('');
  const [lNotesPdfName, setLNotesPdfName] = useState('');
  const [lAttachUrl, setLAttachUrl] = useState('');
  const [lAttachName, setLAttachName] = useState('');
  const [lDownloadsEnabled, setLDownloadsEnabled] = useState(true);
  const [lAssignment, setLAssignment] = useState('');
  const [lQuizId, setLQuizId] = useState('');
  const [lNotesMd, setLNotesMd] = useState('');
  const [lObjectivesText, setLObjectivesText] = useState('');
  const [lFreePreview, setLFreePreview] = useState(false);
  const [lStatus, setLStatus] = useState<PublishStatus>('published');
  const [savingLesson, setSavingLesson] = useState(false);

  // Drag & Drop state
  const [draggedLessonId, setDraggedLessonId] = useState<string | null>(null);

  const loadCourseIntoForm = (course?: Course) => {
    if (!course) {
      setSelectedCourseId('NEW');
      setTitle('');
      setSlug('');
      setDescription('');
      setThumbnailUrl(PRESET_THUMBNAILS[0].url);
      setBannerUrl(PRESET_THUMBNAILS[0].url);
      setCategoryId(categories[0]?.id || 'cat_science');
      setInstructorName(profile?.displayName || 'Instructor');
      setInstructorTitle('Senior Lecturer');
      setLevel('HSC');
      setLanguage('Bangla & English');
      setIsFree(true);
      setPrice(0);
      setStatus('draft');
      setIsFeatured(false);
      setDurationText('2h 00m');
      setRequirementsText('');
      setOutcomesText('');
      return;
    }
    setSelectedCourseId(course.id);
    setTitle(course.title);
    setSlug(course.slug);
    setDescription(course.description || '');
    setThumbnailUrl(course.thumbnailUrl || PRESET_THUMBNAILS[0].url);
    setBannerUrl(course.bannerUrl || course.thumbnailUrl || PRESET_THUMBNAILS[0].url);
    setCategoryId(course.categoryId);
    setInstructorName(course.instructorName || '');
    setInstructorTitle(course.instructorTitle || '');
    setLevel(course.level || 'HSC');
    setLanguage(course.language || 'Bangla & English');
    setIsFree(course.isFree);
    setPrice(course.price);
    setStatus(course.status);
    setIsFeatured(course.isFeatured);
    setDurationText(course.durationText || '');
    setRequirementsText((course.requirements || []).join('\n'));
    setOutcomesText((course.outcomes || []).join('\n'));
  };

  const courseChapters = useMemo(
    () =>
      activeCourse
        ? chapters.filter((c) => c.courseId === activeCourse.id).sort((a, b) => a.order - b.order)
        : [],
    [chapters, activeCourse?.id]
  );

  const courseLessons = useMemo(
    () =>
      activeCourse
        ? lessons.filter((l) => l.courseId === activeCourse.id).sort((a, b) => a.order - b.order)
        : [],
    [lessons, activeCourse?.id]
  );

  const handleSaveCourse = async (overrideStatus?: PublishStatus) => {
    if (!title.trim()) {
      showToast('Validation', 'Course title is required.', 'warning');
      return;
    }
    setSavingCourse(true);
    const now = new Date().toISOString();
    const id = activeCourse?.id || generateDocId('course');
    const cat = categories.find((c) => c.id === categoryId);
    const finalStatus = overrideStatus || status;

    const reqs = requirementsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 20);
    const outs = outcomesText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 20);

    const payload: Course = {
      id,
      title: clampStr(title, 160),
      slug: clampStr(slug || slugify(title), 180),
      description: clampStr(description, 4000),
      thumbnailUrl: clampStr(thumbnailUrl, 600),
      bannerUrl: clampStr(bannerUrl || thumbnailUrl, 600),
      categoryId,
      categoryName: clampStr(cat?.name || 'General', 80),
      instructorId: activeCourse?.instructorId || firebaseUser?.uid || 'admin',
      instructorName: clampStr(instructorName, 120),
      instructorTitle: clampStr(instructorTitle, 120),
      level,
      language: clampStr(language, 40),
      price: isFree ? 0 : Math.max(0, Number(price) || 0),
      isFree,
      status: finalStatus,
      isFeatured,
      requirements: reqs,
      outcomes: outs,
      totalChapters: courseChapters.length,
      totalLessons: courseLessons.length,
      durationText: clampStr(durationText, 60),
      createdAt: activeCourse?.createdAt || now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'courses', id), payload);
      setSelectedCourseId(id);
      setStatus(finalStatus);
      showToast(
        finalStatus === 'published' ? 'Course Published' : 'Course Saved',
        payload.title,
        'success'
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `courses/${id}`);
    } finally {
      setSavingCourse(false);
    }
  };

  const handleDeleteCourse = async () => {
    if (!activeCourse) return;
    const ok = await confirm({
      title: 'Delete Course',
      message: `Are you sure you want to delete "${activeCourse.title}"?`,
      confirmLabel: 'Delete Course',
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteDoc(doc(db, 'courses', activeCourse.id));
      showToast('Course Deleted', activeCourse.title, 'info');
      loadCourseIntoForm(undefined);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `courses/${activeCourse.id}`);
    }
  };

  const handleDuplicateCourse = async () => {
    if (!activeCourse) return;
    const now = new Date().toISOString();
    const newId = generateDocId('course');
    const copy: Course = {
      ...activeCourse,
      id: newId,
      title: `${activeCourse.title} (Copy)`.slice(0, 160),
      slug: `${activeCourse.slug}-copy-${Date.now().toString().slice(-4)}`,
      status: 'draft',
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'courses', newId), copy);
    loadCourseIntoForm(copy);
    showToast('Course Duplicated', 'Draft copy created.', 'success');
  };

  // Chapter CRUD
  const handleAddChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse || !newChapterTitle.trim()) return;
    const id = generateDocId('chap');
    const now = new Date().toISOString();
    const nextOrder = courseChapters.length + 1;
    try {
      await setDoc(doc(db, 'chapters', id), {
        id,
        courseId: activeCourse.id,
        title: clampStr(newChapterTitle, 180),
        description: clampStr(newChapterDesc, 1000),
        order: nextOrder,
        createdAt: now,
        updatedAt: now,
      });
      await updateDoc(doc(db, 'courses', activeCourse.id), {
        totalChapters: nextOrder,
        updatedAt: now,
      });
      setExpandedChapters((prev) => ({ ...prev, [id]: true }));
      setNewChapterTitle('');
      setNewChapterDesc('');
      showToast('Chapter Added', undefined, 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `chapters/${id}`);
    }
  };

  const handleSaveChapterEdit = async () => {
    if (!editingChapter || !editingChapter.title.trim()) return;
    try {
      await updateDoc(doc(db, 'chapters', editingChapter.id), {
        title: clampStr(editingChapter.title, 180),
        description: clampStr(editingChapter.description || '', 1000),
        updatedAt: new Date().toISOString(),
      });
      setEditingChapter(null);
      showToast('Chapter Updated', undefined, 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `chapters/${editingChapter.id}`);
    }
  };

  const handleMoveChapter = async (idx: number, dir: -1 | 1) => {
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= courseChapters.length) return;
    const a = courseChapters[idx];
    const b = courseChapters[targetIdx];
    const now = new Date().toISOString();
    const batch = writeBatch(db);
    batch.update(doc(db, 'chapters', a.id), { order: b.order, updatedAt: now });
    batch.update(doc(db, 'chapters', b.id), { order: a.order, updatedAt: now });
    await batch.commit();
  };

  const handleDeleteChapter = async (ch: Chapter) => {
    const ok = await confirm({
      title: 'Delete Chapter',
      message: `Delete "${ch.title}"? Lessons inside should be removed or reassigned.`,
      confirmLabel: 'Delete',
      destructive: true,
    });
    if (!ok) return;
    await deleteDoc(doc(db, 'chapters', ch.id));
    showToast('Chapter Deleted', ch.title, 'info');
  };

  // Lesson CRUD & Drag-and-Drop
  const openLessonModal = async (chapterId: string, existing?: Lesson) => {
    setLessonModal({ open: true, chapterId, editingLesson: existing });
    if (!existing) {
      setLTitle('');
      setLDesc('');
      setLYoutubeUrl('');
      setLDuration('45:00');
      setLThumb(activeCourse?.thumbnailUrl || '');
      setLSlidesUrl('');
      setLSlidesName('');
      setLNotesPdfUrl('');
      setLNotesPdfName('');
      setLAttachUrl('');
      setLAttachName('');
      setLDownloadsEnabled(true);
      setLAssignment('');
      setLQuizId('');
      setLNotesMd('');
      setLObjectivesText('');
      setLFreePreview(false);
      setLStatus('published');
      return;
    }

    setLTitle(existing.title);
    setLDuration(existing.durationText || '45:00');
    setLThumb(existing.thumbnailUrl || '');
    setLFreePreview(existing.isFreePreview);
    setLStatus(existing.status);

    try {
      const snap = await getDoc(doc(db, 'lesson_contents', existing.id));
      if (snap.exists()) {
        const c = snap.data() as LessonContent;
        setLDesc(c.description || '');
        setLYoutubeUrl(c.youtubeVideoId ? `https://youtu.be/${c.youtubeVideoId}` : '');
        setLSlidesUrl(c.slidesUrl || '');
        setLSlidesName(c.slidesName || '');
        setLNotesPdfUrl(c.notesPdfUrl || '');
        setLNotesPdfName(c.notesPdfName || '');
        setLAttachUrl(c.attachmentUrl || '');
        setLAttachName(c.attachmentName || '');
        setLDownloadsEnabled(c.downloadsEnabled);
        setLAssignment(c.assignmentText || '');
        setLQuizId(c.quizId || '');
        setLNotesMd(c.lectureNotesMarkdown || '');
        setLObjectivesText((c.learningObjectives || []).join('\n'));
      }
    } catch {
      // ignore if empty
    }
  };

  const handleSaveLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse || !lessonModal || !lTitle.trim()) return;

    const extractedVideoId = lYoutubeUrl.trim() ? extractYouTubeId(lYoutubeUrl) : '';
    if (lYoutubeUrl.trim() && !extractedVideoId) {
      showToast(
        'Invalid YouTube URL',
        'Please paste a valid YouTube watch, youtu.be, live, or embed URL.',
        'warning'
      );
      return;
    }

    setSavingLesson(true);
    const now = new Date().toISOString();
    const editing = lessonModal.editingLesson;
    const id = editing?.id || generateDocId('les');
    const chLessons = courseLessons.filter((l) => l.chapterId === lessonModal.chapterId);

    const lessonDoc: Lesson = {
      id,
      courseId: activeCourse.id,
      chapterId: lessonModal.chapterId,
      title: clampStr(lTitle, 200),
      lessonNumber: editing?.lessonNumber || chLessons.length + 1,
      order: editing?.order || courseLessons.length + 1,
      durationText: clampStr(lDuration, 40),
      thumbnailUrl: clampStr(lThumb || activeCourse.thumbnailUrl || '', 600),
      isFreePreview: lFreePreview,
      status: lStatus,
      viewsCount: editing?.viewsCount ?? 0,
      likesCount: editing?.likesCount ?? 0,
      createdAt: editing?.createdAt || now,
      updatedAt: now,
    };

    const objectives = lObjectivesText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 20);

    const contentDoc: LessonContent = {
      id,
      courseId: activeCourse.id,
      chapterId: lessonModal.chapterId,
      isFreePreview: lFreePreview,
      youtubeVideoId: extractedVideoId || '',
      description: clampStr(lDesc, 4000),
      learningObjectives: objectives,
      lectureNotesMarkdown: clampStr(lNotesMd, 10000),
      slidesUrl: clampStr(lSlidesUrl, 600),
      slidesName: clampStr(lSlidesName || 'Class_Slides.pdf', 160),
      notesPdfUrl: clampStr(lNotesPdfUrl, 600),
      notesPdfName: clampStr(lNotesPdfName || 'Lecture_Notes.pdf', 160),
      attachmentUrl: clampStr(lAttachUrl, 600),
      attachmentName: clampStr(lAttachName || 'Attachment.pdf', 160),
      downloadsEnabled: lDownloadsEnabled,
      assignmentText: clampStr(lAssignment, 2000),
      quizId: clampStr(lQuizId, 128),
      updatedAt: now,
    };

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'lessons', id), lessonDoc);
      batch.set(doc(db, 'lesson_contents', id), contentDoc);
      if (!editing) {
        batch.update(doc(db, 'courses', activeCourse.id), {
          totalLessons: courseLessons.length + 1,
          updatedAt: now,
        });
      }
      await batch.commit();
      setLessonModal(null);
      showToast('Lesson Saved', lessonDoc.title, 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `lessons/${id}`);
    } finally {
      setSavingLesson(false);
    }
  };

  const handleReorderLessonsInChapter = async (
    chapterId: string,
    sourceId: string,
    targetId: string
  ) => {
    if (sourceId === targetId) return;
    const chList = courseLessons.filter((l) => l.chapterId === chapterId);
    const fromIdx = chList.findIndex((l) => l.id === sourceId);
    const toIdx = chList.findIndex((l) => l.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;

    const reordered = [...chList];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);

    const now = new Date().toISOString();
    const batch = writeBatch(db);
    reordered.forEach((les, idx) => {
      batch.update(doc(db, 'lessons', les.id), {
        lessonNumber: idx + 1,
        order: idx + 1,
        updatedAt: now,
      });
    });
    await batch.commit();
    showToast('Lesson Order Updated', undefined, 'success');
  };

  const handleDeleteLesson = async (les: Lesson) => {
    const ok = await confirm({
      title: 'Delete Lesson',
      message: `Delete "${les.title}"?`,
      confirmLabel: 'Delete',
      destructive: true,
    });
    if (!ok) return;
    await deleteDoc(doc(db, 'lessons', les.id));
    await deleteDoc(doc(db, 'lesson_contents', les.id));
    if (activeCourse) {
      await updateDoc(doc(db, 'courses', activeCourse.id), {
        totalLessons: Math.max(0, courseLessons.length - 1),
        updatedAt: new Date().toISOString(),
      });
    }
    showToast('Lesson Deleted', les.title, 'info');
  };

  const previewExtractedId = lYoutubeUrl.trim() ? extractYouTubeId(lYoutubeUrl) : null;

  return (
    <div className="space-y-8">
      {/* Course Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-0">
          <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap">
            Select Course:
          </label>
          <select
            value={selectedCourseId}
            onChange={(e) => {
              const val = e.target.value;
              if (val === 'NEW') loadCourseIntoForm(undefined);
              else loadCourseIntoForm(editableCourses.find((c) => c.id === val));
            }}
            className="min-w-[220px] flex-1 max-w-md rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
          >
            <option value="NEW">+ Create New Course</option>
            {editableCourses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title} ({c.status})
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!restrictToInstructorUid && (
            <button
              type="button"
              onClick={() => loadCourseIntoForm(undefined)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
            >
              <Plus className="h-3.5 w-3.5" />
              New Course
            </button>
          )}
          {activeCourse && (
            <>
              <button
                type="button"
                onClick={() => onNavigate({ page: 'lecture', courseId: activeCourse.id })}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
              >
                <Eye className="h-3.5 w-3.5 text-emerald-500" />
                Preview Course
              </button>
              {!restrictToInstructorUid && (
                <>
                  <button
                    type="button"
                    onClick={handleDuplicateCourse}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
                  >
                    <Copy className="h-3.5 w-3.5" />
                    Duplicate
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteCourse}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/30 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-500/10 dark:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Delete
                  </button>
                </>
              )}
            </>
          )}
        </div>
      </div>

      {/* Step 1: Course Details Form */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-[#263449]">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              {activeCourse ? '1. Edit Course Details' : '1. Create New Course'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Configure metadata, pricing, thumbnails, and publish visibility.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={savingCourse}
              onClick={() => handleSaveCourse('draft')}
              className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
            >
              Save Draft
            </button>
            <button
              type="button"
              disabled={savingCourse}
              onClick={() => handleSaveCourse('published')}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
            >
              <Save className="h-3.5 w-3.5" />
              {savingCourse ? 'Saving...' : 'Publish Course'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Course Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (!activeCourse) setSlug(slugify(e.target.value));
              }}
              placeholder="e.g. HSC Physics 1st Paper"
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Course Slug
            </label>
            <input
              type="text"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="hsc-physics-1st-paper"
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Category
            </label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Level
              </label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as CourseLevel)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              >
                <option value="HSC">HSC</option>
                <option value="Admission">Admission</option>
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Language
              </label>
              <input
                type="text"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Instructor Name
            </label>
            <input
              type="text"
              value={instructorName}
              onChange={(e) => setInstructorName(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Duration Text
            </label>
            <input
              type="text"
              value={durationText}
              onChange={(e) => setDurationText(e.target.value)}
              placeholder="e.g. 4h 30m"
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Thumbnail URL
            </label>
            <input
              type="text"
              value={thumbnailUrl}
              onChange={(e) => setThumbnailUrl(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {PRESET_THUMBNAILS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    setThumbnailUrl(p.url);
                    setBannerUrl(p.url);
                  }}
                  className="rounded border border-slate-200 px-2 py-0.5 text-[11px] text-slate-600 hover:border-emerald-500 dark:border-[#263449] dark:text-slate-300"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Pricing Model
              </label>
              <select
                value={isFree ? 'free' : 'paid'}
                onChange={(e) => setIsFree(e.target.value === 'free')}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              >
                <option value="free">Free Course</option>
                <option value="paid">Paid Course (BDT)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Price (BDT)
              </label>
              <input
                type="number"
                min={0}
                disabled={isFree}
                value={isFree ? 0 : price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 disabled:opacity-50 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Course Description
          </label>
          <textarea
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Course Requirements (one per line)
            </label>
            <textarea
              rows={3}
              value={requirementsText}
              onChange={(e) => setRequirementsText(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              What Students Will Learn (one per line)
            </label>
            <textarea
              rows={3}
              value={outcomesText}
              onChange={(e) => setOutcomesText(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
        </div>

        <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
          <input
            type="checkbox"
            checked={isFeatured}
            onChange={(e) => setIsFeatured(e.target.checked)}
            className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
          />
          Feature this course on the Homepage
        </label>
      </section>

      {/* Step 2 & 3: Chapter & Lesson Hierarchy Builder */}
      {activeCourse && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-6">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              2. Chapters & Lessons Builder
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Course → Chapter → Lesson hierarchy. Drag and drop lessons to reorder within any
              chapter.
            </p>
          </div>

          {/* Add Chapter Form */}
          <form
            onSubmit={handleAddChapter}
            className="grid grid-cols-1 md:grid-cols-12 gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-[#263449] dark:bg-[#0B1120]"
          >
            <input
              type="text"
              required
              value={newChapterTitle}
              onChange={(e) => setNewChapterTitle(e.target.value)}
              placeholder="New Chapter Title (e.g. Chapter 1: ভৌত জগৎ ও পরিমাপ)"
              className="md:col-span-5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
            />
            <input
              type="text"
              value={newChapterDesc}
              onChange={(e) => setNewChapterDesc(e.target.value)}
              placeholder="Chapter description (optional)"
              className="md:col-span-5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
            />
            <button
              type="submit"
              className="md:col-span-2 inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
            >
              <Plus className="h-4 w-4" />
              Add Chapter
            </button>
          </form>

          {/* Chapters List */}
          <div className="space-y-4">
            {courseChapters.length === 0 ? (
              <p className="py-8 text-center text-sm text-slate-500">
                No chapters yet. Add your first chapter above to start adding video lectures.
              </p>
            ) : (
              courseChapters.map((ch, chIdx) => {
                const chLessons = courseLessons.filter((l) => l.chapterId === ch.id);
                const open = expandedChapters[ch.id] ?? true;

                return (
                  <div
                    key={ch.id}
                    className="overflow-hidden rounded-xl border border-slate-200 dark:border-[#263449]"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 px-4 py-3 dark:bg-[#0B1120]">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedChapters((prev) => ({ ...prev, [ch.id]: !open }))
                        }
                        className="flex items-center gap-2 text-left min-w-0 flex-1"
                      >
                        {open ? (
                          <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                        )}
                        <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {ch.title}
                        </span>
                        <span className="font-mono-tabular text-xs text-slate-400 shrink-0">
                          ({chLessons.length})
                        </span>
                      </button>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => openLessonModal(ch.id)}
                          className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                        >
                          <Plus className="h-3.5 w-3.5" />
                          Add Lesson
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingChapter(ch)}
                          className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:border-[#263449] dark:text-slate-300"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          aria-label="Move chapter up"
                          disabled={chIdx === 0}
                          onClick={() => handleMoveChapter(chIdx, -1)}
                          className="rounded-lg p-1.5 text-slate-400 hover:text-slate-700 disabled:opacity-30"
                        >
                          <ArrowUp className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          aria-label="Move chapter down"
                          disabled={chIdx === courseChapters.length - 1}
                          onClick={() => handleMoveChapter(chIdx, 1)}
                          className="rounded-lg p-1.5 text-slate-400 hover:text-slate-700 disabled:opacity-30"
                        >
                          <ArrowDown className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          aria-label="Delete chapter"
                          onClick={() => handleDeleteChapter(ch)}
                          className="rounded-lg p-1.5 text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>

                    {editingChapter?.id === ch.id && (
                      <div className="flex flex-wrap gap-2 border-t border-slate-200 bg-white p-3 dark:border-[#263449] dark:bg-[#172033]">
                        <input
                          type="text"
                          value={editingChapter.title}
                          onChange={(e) =>
                            setEditingChapter({ ...editingChapter, title: e.target.value })
                          }
                          className="flex-1 rounded-lg border border-slate-200 px-3 py-1.5 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={handleSaveChapterEdit}
                          className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingChapter(null)}
                          className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs dark:border-[#263449]"
                        >
                          Cancel
                        </button>
                      </div>
                    )}

                    {open && (
                      <div className="divide-y divide-slate-100 bg-white dark:divide-[#263449] dark:bg-[#172033]">
                        {chLessons.length === 0 ? (
                          <p className="px-4 py-4 text-xs text-slate-400">
                            No lessons in this chapter yet.
                          </p>
                        ) : (
                          chLessons.map((les) => (
                            <div
                              key={les.id}
                              draggable
                              onDragStart={() => setDraggedLessonId(les.id)}
                              onDragOver={(e) => e.preventDefault()}
                              onDrop={() => {
                                if (draggedLessonId) {
                                  handleReorderLessonsInChapter(ch.id, draggedLessonId, les.id);
                                  setDraggedLessonId(null);
                                }
                              }}
                              className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-[#1e2940]/60 transition-colors"
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <GripVertical className="h-4 w-4 text-slate-400 cursor-grab shrink-0" />
                                <Video className="h-4 w-4 text-emerald-500 shrink-0" />
                                <div className="min-w-0">
                                  <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                                    {les.title}
                                  </p>
                                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-tabular">
                                    Lec {String(les.lessonNumber).padStart(2, '0')} ·{' '}
                                    {les.durationText || 'Video'} · {les.status}
                                    {les.isFreePreview ? ' · Free Preview' : ''}
                                  </p>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() =>
                                    onNavigate({
                                      page: 'lecture',
                                      courseId: activeCourse.id,
                                      lessonId: les.id,
                                    })
                                  }
                                  className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-emerald-600 dark:border-[#263449] dark:text-slate-300"
                                >
                                  Preview
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openLessonModal(ch.id, les)}
                                  className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
                                >
                                  Edit
                                </button>
                                <button
                                  type="button"
                                  aria-label="Delete lesson"
                                  onClick={() => handleDeleteLesson(les)}
                                  className="rounded-lg p-1.5 text-slate-400 hover:text-rose-500"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </section>
      )}

      {/* Lesson Builder Modal */}
      {lessonModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-xs"
        >
          <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-[#263449] dark:bg-[#172033]">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-[#263449]">
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {lessonModal.editingLesson ? 'Edit Lesson' : 'Create New Lesson'}
              </h3>
              <button
                type="button"
                onClick={() => setLessonModal(null)}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleSaveLesson} className="mt-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Lesson Title
                  </label>
                  <input
                    type="text"
                    required
                    value={lTitle}
                    onChange={(e) => setLTitle(e.target.value)}
                    placeholder="e.g. Lecture 01: Vector Addition & Parallelogram Law"
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Video Duration
                  </label>
                  <input
                    type="text"
                    value={lDuration}
                    onChange={(e) => setLDuration(e.target.value)}
                    placeholder="48:20"
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
              </div>

              {/* YouTube Unlisted URL */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-[#263449] dark:bg-[#0B1120] space-y-2">
                <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200">
                  YouTube Unlisted Video URL (Auto-extracts Video ID)
                </label>
                <input
                  type="text"
                  value={lYoutubeUrl}
                  onChange={(e) => setLYoutubeUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=... or https://youtu.be/..."
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
                />
                {previewExtractedId ? (
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-mono-tabular">
                    Extracted Video ID: {previewExtractedId}
                  </p>
                ) : lYoutubeUrl.trim() ? (
                  <p className="text-xs text-rose-500">Could not recognize a valid YouTube ID.</p>
                ) : null}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Lesson Description
                </label>
                <textarea
                  rows={2}
                  value={lDesc}
                  onChange={(e) => setLDesc(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                />
              </div>

              {/* PDFs & Attachments */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Class Slides PDF URL
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={lSlidesUrl}
                      onChange={(e) => setLSlidesUrl(e.target.value)}
                      placeholder="/api/resources/pdf?... or https://..."
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const url = `/api/resources/pdf?title=${encodeURIComponent(
                          lTitle || 'Class Slides'
                        )}&course=${encodeURIComponent(activeCourse?.title || 'Course Hub')}`;
                        setLSlidesUrl(url);
                        setLSlidesName('Class_Slides.pdf');
                      }}
                      className="rounded-lg border border-slate-200 px-2.5 py-1 text-[11px] font-medium dark:border-[#263449]"
                      title="Generate downloadable PDF link"
                    >
                      <FileText className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Lecture Notes PDF URL
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={lNotesPdfUrl}
                      onChange={(e) => setLNotesPdfUrl(e.target.value)}
                      placeholder="/api/resources/pdf?... or https://..."
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const url = `/api/resources/pdf?title=${encodeURIComponent(
                          `${lTitle || 'Lecture'} Notes`
                        )}&course=${encodeURIComponent(activeCourse?.title || 'Course Hub')}`;
                        setLNotesPdfUrl(url);
                        setLNotesPdfName('Lecture_Notes.pdf');
                      }}
                      className="rounded-lg border border-slate-200 px-2.5 py-1 text-[11px] font-medium dark:border-[#263449]"
                      title="Generate downloadable PDF link"
                    >
                      <FileText className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Additional Attachment URL
                  </label>
                  <input
                    type="text"
                    value={lAttachUrl}
                    onChange={(e) => setLAttachUrl(e.target.value)}
                    placeholder="Optional worksheet or code zip URL"
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Linked Exam / Quiz
                  </label>
                  <select
                    value={lQuizId}
                    onChange={(e) => setLQuizId(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  >
                    <option value="">None</option>
                    {exams
                      .filter((ex) => ex.courseId === activeCourse?.id)
                      .map((ex) => (
                        <option key={ex.id} value={ex.id}>
                          {ex.title}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Instructor Summary Notes & Key Points
                </label>
                <textarea
                  rows={3}
                  value={lNotesMd}
                  onChange={(e) => setLNotesMd(e.target.value)}
                  placeholder="Key formulas, definitions, and board tips..."
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Learning Objectives (one per line)
                  </label>
                  <textarea
                    rows={2}
                    value={lObjectivesText}
                    onChange={(e) => setLObjectivesText(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Assignment Prompt
                  </label>
                  <textarea
                    rows={2}
                    value={lAssignment}
                    onChange={(e) => setLAssignment(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={lFreePreview}
                    onChange={(e) => setLFreePreview(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  Free Preview Lesson
                </label>

                <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={lDownloadsEnabled}
                    onChange={(e) => setLDownloadsEnabled(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  Enable PDF Downloads
                </label>

                <select
                  value={lStatus}
                  onChange={(e) => setLStatus(e.target.value as PublishStatus)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                >
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 border-t border-slate-100 pt-4 dark:border-[#263449]">
                <button
                  type="button"
                  onClick={() => setLessonModal(null)}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 dark:border-[#263449] dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingLesson}
                  className="rounded-lg bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {savingLesson ? 'Saving...' : 'Save Lesson'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
