import React, { useState } from 'react';
import {
  Home,
  Compass,
  GraduationCap,
  Video,
  ClipboardCheck,
  FileText,
  MessageSquare,
  Bookmark,
  History,
  Bell,
  User,
  Settings,
  ShieldCheck,
  Briefcase,
  Search,
  Sun,
  Moon,
  Menu,
  X,
  LogOut,
  LogIn,
  ChevronDown,
  BookOpenCheck,
} from 'lucide-react';
import { AppRoute } from '../../types/lms';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useToast } from '../../contexts/ToastContext';

interface AppShellProps {
  route: AppRoute;
  onNavigate: (route: AppRoute) => void;
  children: React.ReactNode;
}

export function AppShell({ route, onNavigate, children }: AppShellProps) {
  const { theme, toggleTheme } = useTheme();
  const { firebaseUser, profile, isAdmin, isInstructor, logout } = useAuth();
  const { notifications, markNotificationRead, siteSettings, isUsingDemoPreview } = useLmsData();
  const { showToast } = useToast();

  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const navItems: Array<{
    id: AppRoute['page'];
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'explore', label: 'Explore Courses', icon: Compass },
    { id: 'dashboard', label: 'My Learning', icon: GraduationCap },
    { id: 'live-classes', label: 'Live Classes', icon: Video },
    { id: 'exams', label: 'Exams', icon: ClipboardCheck },
    { id: 'materials', label: 'Study Materials', icon: FileText },
    { id: 'community', label: 'Community', icon: MessageSquare },
    { id: 'bookmarks', label: 'Bookmarks', icon: Bookmark },
    { id: 'history', label: 'Learning History', icon: History },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (page: AppRoute['page']) => {
    setMobileDrawerOpen(false);
    setNotifDropdownOpen(false);
    setProfileDropdownOpen(false);
    if (page === 'home') onNavigate({ page: 'home' });
    else if (page === 'explore') onNavigate({ page: 'explore' });
    else if (page === 'dashboard') onNavigate({ page: 'dashboard' });
    else if (page === 'live-classes') onNavigate({ page: 'live-classes' });
    else if (page === 'exams') onNavigate({ page: 'exams' });
    else if (page === 'materials') onNavigate({ page: 'materials' });
    else if (page === 'community') onNavigate({ page: 'community' });
    else if (page === 'bookmarks') onNavigate({ page: 'bookmarks' });
    else if (page === 'history') onNavigate({ page: 'history' });
    else if (page === 'notifications') onNavigate({ page: 'notifications' });
    else if (page === 'profile') onNavigate({ page: 'profile' });
    else if (page === 'settings') onNavigate({ page: 'settings' });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate({ page: 'explore', query: searchInput.trim() });
  };

  const handleLogout = async () => {
    setProfileDropdownOpen(false);
    await logout();
    showToast('Signed out', 'You have been signed out of Course Hub.', 'info');
    onNavigate({ page: 'home' });
  };

  const renderSidebarContent = () => (
    <div className="flex h-full flex-col justify-between py-4">
      <div className="space-y-1 px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = route.page === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavClick(item.id)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                active
                  ? 'bg-emerald-500/12 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-[#172033] dark:hover:text-slate-100'
              }`}
            >
              <span className="flex items-center gap-3 min-w-0">
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </span>
              {typeof item.badge === 'number' && item.badge > 0 && (
                <span className="font-mono-tabular text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {(isInstructor || isAdmin) && (
          <div className="mt-4 border-t border-slate-200 pt-4 dark:border-[#263449] space-y-1">
            <p className="px-3 pb-1 text-xs font-medium text-slate-400 dark:text-slate-500">
              Management
            </p>
            {isInstructor && (
              <button
                type="button"
                onClick={() => {
                  setMobileDrawerOpen(false);
                  onNavigate({ page: 'instructor' });
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  route.page === 'instructor'
                    ? 'bg-emerald-500/12 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-[#172033] dark:hover:text-slate-100'
                }`}
              >
                <Briefcase className="h-4 w-4 shrink-0" />
                <span>Instructor Panel</span>
              </button>
            )}
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setMobileDrawerOpen(false);
                  onNavigate({ page: 'admin', tab: 'overview' });
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  route.page === 'admin'
                    ? 'bg-emerald-500/12 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-[#172033] dark:hover:text-slate-100'
                }`}
              >
                <ShieldCheck className="h-4 w-4 shrink-0" />
                <span>Admin Panel</span>
              </button>
            )}
          </div>
        )}
      </div>

      <div className="px-4 pt-4 border-t border-slate-200 dark:border-[#263449]">
        {isUsingDemoPreview && (
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Previewing demo curriculum. Sign in as admin to seed or publish courses.
          </p>
        )}
        <p className="mt-2 text-xs text-slate-400 dark:text-slate-500">
          {siteSettings.tagline || 'Learn • Grow • Achieve'}
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] dark:bg-[#0B1120] dark:text-[#F8FAFC] flex flex-col">
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 h-16 border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-[#263449] dark:bg-[#111827]/95">
        <div className="flex h-full items-center justify-between gap-4 px-4 lg:px-6">
          {/* Left: Hamburger + Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileDrawerOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-[#172033]"
            >
              <Menu className="h-5 w-5" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate({ page: 'home' })}
              className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-white">
                <BookOpenCheck className="h-4 w-4" />
              </span>
              <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                {siteSettings.siteName || 'Course Hub'}
              </span>
            </button>
          </div>

          {/* Center: Global Search */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="search"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search courses, lectures, materials, instructors..."
                aria-label="Search Course Hub"
                className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100 dark:focus:bg-[#172033]"
              />
            </div>
          </form>

          {/* Right: Notifications, Theme Toggle, Profile */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'explore' })}
              aria-label="Search courses"
              className="md:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-[#172033]"
            >
              <Search className="h-5 w-5" />
            </button>

            {/* Theme Toggle */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#172033] transition-colors"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setNotifDropdownOpen((v) => !v);
                  setProfileDropdownOpen(false);
                }}
                aria-label="Notifications"
                className="relative rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#172033] transition-colors"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white font-mono-tabular">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-200 bg-white p-3 shadow-xl dark:border-[#263449] dark:bg-[#172033] z-50">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 dark:border-[#263449]">
                    <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Notifications
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setNotifDropdownOpen(false);
                        onNavigate({ page: 'notifications' });
                      }}
                      className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
                    >
                      View all
                    </button>
                  </div>
                  <div className="mt-2 max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-[#263449]">
                    {notifications.length === 0 ? (
                      <p className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
                        No notifications yet.
                      </p>
                    ) : (
                      notifications.slice(0, 5).map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => {
                            if (!n.read) markNotificationRead(n.id);
                            setNotifDropdownOpen(false);
                            onNavigate({ page: 'notifications' });
                          }}
                          className="w-full py-2.5 text-left hover:bg-slate-50 dark:hover:bg-[#111827]/60 px-2 rounded-lg transition-colors"
                        >
                          <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                            {n.title}
                          </p>
                          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                            {n.message}
                          </p>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Account */}
            {firebaseUser ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setProfileDropdownOpen((v) => !v);
                    setNotifDropdownOpen(false);
                  }}
                  className="flex items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#172033] transition-colors whitespace-nowrap shrink-0"
                >
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs font-bold text-white uppercase overflow-hidden">
                    {profile?.photoURL ? (
                      <img
                        src={profile.photoURL}
                        alt={profile.displayName}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      (profile?.displayName || firebaseUser.email || 'U').charAt(0)
                    )}
                  </span>
                  <span className="hidden sm:inline max-w-[120px] truncate">
                    {profile?.displayName || 'Account'}
                  </span>
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 bg-white p-2 shadow-xl dark:border-[#263449] dark:bg-[#172033] z-50">
                    <div className="border-b border-slate-100 px-3 py-2 dark:border-[#263449]">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {profile?.displayName || 'Student'}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {firebaseUser.email}
                      </p>
                    </div>
                    <div className="py-1">
                      <button
                        type="button"
                        onClick={() => handleNavClick('dashboard')}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-[#111827]"
                      >
                        <GraduationCap className="h-4 w-4" />
                        My Learning
                      </button>
                      <button
                        type="button"
                        onClick={() => handleNavClick('profile')}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-[#111827]"
                      >
                        <User className="h-4 w-4" />
                        Profile
                      </button>
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate({ page: 'admin', tab: 'overview' });
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-emerald-600 hover:bg-emerald-500/10 dark:text-emerald-400"
                        >
                          <ShieldCheck className="h-4 w-4" />
                          Admin Panel
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={handleLogout}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose-600 hover:bg-rose-500/10 dark:text-rose-400"
                      >
                        <LogOut className="h-4 w-4" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate({ page: 'auth', mode: 'login' })}
                className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
              >
                <LogIn className="h-4 w-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Body with Desktop Sidebar */}
      <div className="flex flex-1 min-h-0">
        <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 bg-white dark:border-[#263449] dark:bg-[#111827]">
          <div className="sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
            {renderSidebarContent()}
          </div>
        </aside>

        {/* Mobile Drawer */}
        {mobileDrawerOpen && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
              onClick={() => setMobileDrawerOpen(false)}
            />
            <aside className="relative z-10 flex w-72 max-w-[85vw] flex-col border-r border-slate-200 bg-white dark:border-[#263449] dark:bg-[#111827] h-full overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-200 px-4 py-4 dark:border-[#263449]">
                <span className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  {siteSettings.siteName || 'Course Hub'}
                </span>
                <button
                  type="button"
                  onClick={() => setMobileDrawerOpen(false)}
                  aria-label="Close navigation menu"
                  className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-[#172033]"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              {renderSidebarContent()}
            </aside>
          </div>
        )}

        {/* Content Viewport */}
        <main className="flex-1 min-w-0 pb-20 lg:pb-8">{children}</main>
      </div>

      {/* Mobile Bottom Navigation (Compact, < 15% viewport height) */}
      <nav
        aria-label="Mobile navigation"
        className="fixed bottom-0 inset-x-0 z-30 flex h-14 items-center justify-around border-t border-slate-200 bg-white/95 backdrop-blur-md dark:border-[#263449] dark:bg-[#111827]/95 lg:hidden"
      >
        {[
          { id: 'home' as const, label: 'Home', icon: Home },
          { id: 'explore' as const, label: 'Explore', icon: Compass },
          { id: 'dashboard' as const, label: 'Learning', icon: GraduationCap },
          { id: 'exams' as const, label: 'Exams', icon: ClipboardCheck },
          { id: 'profile' as const, label: 'Profile', icon: User },
        ].map((item) => {
          const Icon = item.icon;
          const active = route.page === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavClick(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium ${
                active
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
