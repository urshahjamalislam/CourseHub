export function CourseCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-[#263449] bg-white dark:bg-[#172033] animate-pulse">
      <div className="aspect-[4/3] w-full bg-slate-200 dark:bg-slate-800" />
      <div className="p-5 space-y-3">
        <div className="h-3 w-24 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="h-5 w-3/4 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="h-4 w-1/2 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="pt-2 flex items-center justify-between">
          <div className="h-4 w-16 rounded bg-slate-200 dark:bg-slate-800" />
          <div className="h-8 w-24 rounded-lg bg-slate-200 dark:bg-slate-800" />
        </div>
      </div>
    </div>
  );
}
