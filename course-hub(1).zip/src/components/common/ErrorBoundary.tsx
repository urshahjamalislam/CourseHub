import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
  isPermissionError: boolean;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, errorMessage: '', isPermissionError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    let msg = error.message || 'An unexpected error occurred.';
    let isPerm = false;
    try {
      const parsed = JSON.parse(msg);
      if (parsed && parsed.operationType) {
        isPerm = true;
        msg = `${parsed.error} (Operation: ${parsed.operationType}, Path: ${parsed.path || 'unknown'})`;
      }
    } catch {
      // Not JSON
    }
    return { hasError: true, errorMessage: msg, isPermissionError: isPerm };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('Course Hub ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] dark:bg-[#0B1120] p-6">
          <div className="max-w-lg w-full rounded-2xl border border-slate-200 dark:border-[#263449] bg-white dark:bg-[#172033] p-8 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-rose-500/10 text-rose-500">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <h2 className="mt-4 text-xl font-bold text-slate-900 dark:text-slate-50">
              {this.state.isPermissionError ? 'Access or Database Sync Issue' : 'Something Went Wrong'}
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 break-words leading-relaxed">
              {this.state.errorMessage}
            </p>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, errorMessage: '', isPermissionError: false });
                window.location.reload();
              }}
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700 transition-colors"
            >
              <RotateCcw className="h-4 w-4" />
              Reload Platform
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
