import { useState } from 'react';
import { BookOpen } from 'lucide-react';

interface CourseThumbnailProps {
  src?: string;
  alt: string;
  title?: string;
  className?: string;
}

export function CourseThumbnail({ src, alt, title, className = '' }: CourseThumbnailProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-[#172033] to-emerald-950/70 text-slate-200 p-4 text-center ${className}`}
      >
        <BookOpen className="h-8 w-8 text-emerald-400 mb-2" />
        {title && (
          <span className="text-xs font-medium text-slate-300 line-clamp-2 max-w-[180px]">
            {title}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`object-cover ${className}`}
    />
  );
}
