import React, { useState } from 'react';
import { BookOpenCheck, CheckCircle2, Mail, RefreshCw, ShieldCheck } from 'lucide-react';
import { AppRoute } from '../../types/lms';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';

interface AuthPageProps {
  initialMode?: 'login' | 'signup' | 'forgot';
  onNavigate: (route: AppRoute) => void;
}

export function AuthPage({ initialMode = 'login', onNavigate }: AuthPageProps) {
  const {
    firebaseUser,
    isVerified,
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    sendResetEmail,
    resendVerificationEmail,
    refreshUser,
    logout,
  } = useAuth();
  const { showToast } = useToast();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [educationLevel, setEducationLevel] = useState('HSC');
  const [institution, setInstitution] = useState('');
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [providerNotice, setProviderNotice] = useState(false);

  if (firebaseUser && !isVerified) {
    return (
      <div className="mx-auto max-w-md px-4 py-16">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-[#263449] dark:bg-[#172033] space-y-5">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/15 text-amber-500">
            <Mail className="h-6 w-6" />
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Verify Your Email Address
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            A verification link was sent to <strong>{firebaseUser.email}</strong>. Please click the
            link in your inbox, then refresh below to unlock your student dashboard.
          </p>
          <div className="space-y-2.5 pt-2">
            <button
              type="button"
              onClick={async () => {
                setBusy(true);
                await refreshUser();
                setBusy(false);
                showToast('Status Checked', 'If verified, your dashboard is now unlocked.', 'info');
              }}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700"
            >
              <RefreshCw className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} />
              I Verified My Email — Continue
            </button>
            <button
              type="button"
              onClick={async () => {
                await resendVerificationEmail();
                showToast('Sent', 'Verification email re-sent.', 'success');
              }}
              className="w-full rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#111827]"
            >
              Resend Verification Email
            </button>
            <button
              type="button"
              onClick={() => logout()}
              className="w-full text-xs text-slate-500 hover:text-rose-500 pt-2"
            >
              Sign out and use another account
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (firebaseUser && isVerified) {
    return (
      <div className="mx-auto max-w-md px-4 py-16">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-500" />
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            You Are Signed In
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">{firebaseUser.email}</p>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'dashboard' })}
            className="w-full rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700"
          >
            Go to Student Dashboard
          </button>
        </div>
      </div>
    );
  }

  const handleGoogle = async () => {
    setBusy(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      showToast('Welcome to Course Hub', 'Signed in with Google.', 'success');
      onNavigate({ page: 'dashboard' });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErrorMsg(null);
    setProviderNotice(false);
    try {
      if (mode === 'login') {
        await signInWithEmail(email, password);
        showToast('Signed In', 'Welcome back to Course Hub.', 'success');
        onNavigate({ page: 'dashboard' });
      } else if (mode === 'signup') {
        if (!displayName.trim()) throw new Error('Full name is required.');
        await signUpWithEmail(email, password, displayName, {
          phone,
          educationLevel,
          institution,
        });
        showToast(
          'Account Created',
          'Check your email inbox to verify your account before accessing protected features.',
          'success'
        );
      } else {
        await sendResetEmail(email);
        showToast('Password Reset Sent', 'Check your inbox for the reset link.', 'success');
        setMode('login');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication error.';
      if (msg.includes('operation-not-allowed')) {
        setProviderNotice(true);
      }
      setErrorMsg(msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-[#263449] dark:bg-[#172033] space-y-6">
        <div className="text-center space-y-2">
          <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white">
            <BookOpenCheck className="h-5 w-5" />
          </span>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            {mode === 'login'
              ? 'Sign in to Course Hub'
              : mode === 'signup'
              ? 'Create Student Account'
              : 'Reset Your Password'}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Learn • Grow • Achieve
          </p>
        </div>

        {/* Google Sign-In */}
        {mode !== 'forgot' && (
          <div className="space-y-4">
            <button
              type="button"
              disabled={busy}
              onClick={handleGoogle}
              className="flex w-full items-center justify-center gap-2.5 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100 dark:hover:bg-[#111827] transition-colors"
            >
              <ShieldCheck className="h-4 w-4 text-emerald-500" />
              <span>Continue with Google</span>
            </button>

            <div className="relative flex items-center justify-center">
              <div className="w-full border-t border-slate-200 dark:border-[#263449]" />
              <span className="bg-white px-3 text-xs text-slate-400 dark:bg-[#172033]">
                or use email
              </span>
              <div className="w-full border-t border-slate-200 dark:border-[#263449]" />
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Nusrat Jahan"
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Education Level
                  </label>
                  <select
                    value={educationLevel}
                    onChange={(e) => setEducationLevel(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  >
                    <option value="SSC">SSC</option>
                    <option value="HSC">HSC</option>
                    <option value="Admission">Admission</option>
                    <option value="Undergraduate">Undergraduate</option>
                    <option value="Skill Track">Skill Track</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+880 17..."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Institution
                </label>
                <input
                  type="text"
                  value={institution}
                  onChange={(e) => setInstitution(e.target.value)}
                  placeholder="College or University name"
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="student@example.com"
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          {mode !== 'forgot' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Password
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              />
            </div>
          )}

          {errorMsg && (
            <p className="text-xs text-rose-600 dark:text-rose-400 leading-relaxed">{errorMsg}</p>
          )}

          {providerNotice && (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-800 dark:text-amber-200 leading-relaxed">
              Email/Password sign-in is not yet enabled in your Firebase project. Enable it in{' '}
              <strong>Firebase Console → Authentication → Sign-in method → Email/Password</strong>,
              or use <strong>Continue with Google</strong> above.
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 transition-colors"
          >
            {busy
              ? 'Please wait...'
              : mode === 'login'
              ? 'Sign In'
              : mode === 'signup'
              ? 'Create Account'
              : 'Send Reset Link'}
          </button>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-[#263449]">
          {mode === 'login' ? (
            <>
              <button
                type="button"
                onClick={() => setMode('forgot')}
                className="hover:text-emerald-600 dark:hover:text-emerald-400"
              >
                Forgot Password?
              </button>
              <button
                type="button"
                onClick={() => setMode('signup')}
                className="font-semibold text-emerald-600 hover:underline dark:text-emerald-400"
              >
                Create an Account
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => setMode('login')}
              className="font-semibold text-emerald-600 hover:underline dark:text-emerald-400"
            >
              Back to Sign In
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
