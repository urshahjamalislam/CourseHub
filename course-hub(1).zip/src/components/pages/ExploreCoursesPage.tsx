import { useMemo, useState } from 'react';
import { Search, Play, FileText, User, BookOpen } from 'lucide-react';
import { AppRoute } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { CourseCard } from './HomePage';

interface ExploreCoursesPageProps {
  initialQuery?: string;
  initialCategoryId?: string;
  onNavigate: (route: AppRoute) => void;
}

export function ExploreCoursesPage({
  initialQuery = '',
  initialCategoryId = 'all',
  onNavigate,
}: ExploreCoursesPageProps) {
  const { courses, categories, lessons, studyMaterials } = useLmsData();

  const [queryText, setQueryText] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState(initialCategoryId);
  const [priceFilter, setPriceFilter] = useState<'all' | 'free' | 'paid'>('all');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'title'>('latest');
  const [searchScope, setSearchScope] = useState<'courses' | 'lessons' | 'materials' | 'instructors'>('courses');

  const publishedCourses = courses.filter((c) => c.status === 'published');
  const qLower = queryText.trim().toLowerCase();

  const filteredCourses = useMemo(() => {
    return publishedCourses
      .filter((c) => {
        if (selectedCategory !== 'all' && c.categoryId !== selectedCategory) return false;
        if (priceFilter === 'free' && !c.isFree) return false;
        if (priceFilter === 'paid' && c.isFree) return false;
        if (levelFilter !== 'all' && c.level !== levelFilter) return false;
        if (qLower) {
          const matches =
            c.title.toLowerCase().includes(qLower) ||
            (c.description || '').toLowerCase().includes(qLower) ||
            (c.instructorName || '').toLowerCase().includes(qLower) ||
            (c.categoryName || '').toLowerCase().includes(qLower);
          if (!matches) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      });
  }, [publishedCourses, selectedCategory, priceFilter, levelFilter, qLower, sortBy]);

  const filteredLessons = useMemo(() => {
    return lessons
      .filter((l) => l.status === 'published')
      .filter((l) => {
        if (!qLower) return true;
        return l.title.toLowerCase().includes(qLower);
      })
      .slice(0, 24);
  }, [lessons, qLower]);

  const filteredMaterials = useMemo(() => {
    return studyMaterials.filter((m) => {
      if (!qLower) return true;
      return (
        m.title.toLowerCase().includes(qLower) ||
        (m.courseTitle || '').toLowerCase().includes(qLower)
      );
    });
  }, [studyMaterials, qLower]);

  const instructors = useMemo(() => {
    const map = new Map<string, { id: string; name: string; title: string; coursesCount: number }>();
    for (const c of publishedCourses) {
      const key = c.instructorId || c.instructorName || 'inst';
      const existing = map.get(key);
      if (existing) {
        existing.coursesCount += 1;
      } else {
        map.set(key, {
          id: key,
          name: c.instructorName || 'Course Hub Instructor',
          title: c.instructorTitle || 'Educator',
          coursesCount: 1,
        });
      }
    }
    return Array.from(map.values()).filter((i) =>
      qLower ? i.name.toLowerCase().includes(qLower) || i.title.toLowerCase().includes(qLower) : true
    );
  }, [publishedCourses, qLower]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div className="space-y-2">
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          Explore Catalog
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Search across courses, individual lectures, instructors, and downloadable study materials.
        </p>
      </div>

      {/* Search & Scope Tabs */}
      <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              placeholder="Search Physics, Vectors, Chemistry, Calculus, ICT..."
              className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-4 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-[#0B1120]">
            {[
              { id: 'courses' as const, label: `Courses (${filteredCourses.length})` },
              { id: 'lessons' as const, label: `Lessons (${filteredLessons.length})` },
              { id: 'materials' as const, label: `Materials (${filteredMaterials.length})` },
              { id: 'instructors' as const, label: `Instructors (${instructors.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSearchScope(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  searchScope === tab.id
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-[#172033] dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Course Filters */}
        {searchScope === 'courses' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-[#263449]">
            <select
              aria-label="Filter by category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="all">All Categories</option>
              {categories
                .filter((c) => c.isVisible)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
            </select>

            <select
              aria-label="Filter by pricing"
              value={priceFilter}
              onChange={(e) => setPriceFilter(e.target.value as 'all' | 'free' | 'paid')}
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="all">All Pricing (Free & Paid)</option>
              <option value="free">Free Courses Only</option>
              <option value="paid">Paid Courses Only</option>
            </select>

            <select
              aria-label="Filter by level"
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value)}
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="all">All Levels</option>
              <option value="HSC">HSC</option>
              <option value="Admission">Admission</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>

            <select
              aria-label="Sort courses"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'latest' | 'title')}
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="latest">Sort: Latest</option>
              <option value="title">Sort: Alphabetical</option>
            </select>
          </div>
        )}
      </div>

      {/* Results View */}
      {searchScope === 'courses' && (
        filteredCourses.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
            <BookOpen className="mx-auto h-8 w-8 text-slate-400" />
            <h3 className="mt-3 text-base font-semibold text-slate-900 dark:text-white">
              No matching courses found
            </h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Try clearing filters or searching for Physics, Chemistry, Math, or ICT.
            </p>
            <button
              type="button"
              onClick={() => {
                setQueryText('');
                setSelectedCategory('all');
                setPriceFilter('all');
                setLevelFilter('all');
              }}
              className="mt-4 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} course={course} onNavigate={onNavigate} />
            ))}
          </div>
        )
      )}

      {searchScope === 'lessons' && (
        <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
          {filteredLessons.length === 0 ? (
            <p className="p-8 text-center text-sm text-slate-500">No lectures match your search.</p>
          ) : (
            filteredLessons.map((lesson) => {
              const parentCourse = courses.find((c) => c.id === lesson.courseId);
              return (
                <button
                  key={lesson.id}
                  type="button"
                  onClick={() =>
                    onNavigate({ page: 'lecture', courseId: lesson.courseId, lessonId: lesson.id })
                  }
                  className="flex w-full items-center justify-between gap-4 p-4 text-left hover:bg-slate-50 dark:hover:bg-[#1e2940] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      <Play className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {lesson.title}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {parentCourse?.title || 'Course'} · {lesson.durationText || 'Video Lecture'}
                        {lesson.isFreePreview ? ' · Free Preview' : ''}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 shrink-0">
                    Watch
                  </span>
                </button>
              );
            })
          )}
        </div>
      )}

      {searchScope === 'materials' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredMaterials.length === 0 ? (
            <p className="col-span-full p-8 text-center text-sm text-slate-500">
              No study materials match your search.
            </p>
          ) : (
            filteredMaterials.map((mat) => (
              <div
                key={mat.id}
                className="flex items-start justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <FileText className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                      {mat.title}
                    </h3>
                    <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                      {mat.courseTitle || 'Study Resource'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate({ page: 'materials' })}
                  className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827] shrink-0"
                >
                  Open Library
                </button>
              </div>
            ))
          )}
        </div>
      )}

      {searchScope === 'instructors' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {instructors.map((inst) => (
            <div
              key={inst.id}
              className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <User className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                  {inst.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{inst.title}</p>
                <p className="mt-1 font-mono-tabular text-xs text-emerald-600 dark:text-emerald-400">
                  {inst.coursesCount} {inst.coursesCount === 1 ? 'Course' : 'Courses'}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
