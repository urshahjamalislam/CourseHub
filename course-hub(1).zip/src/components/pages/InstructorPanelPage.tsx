import { useEffect, useState } from 'react';
import { BookOpen, ShieldAlert, TrendingUp, Users } from 'lucide-react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { AppRoute, Enrollment } from '../../types/lms';
import { useAuth } from '../../contexts/AuthContext';
import { useLmsData } from '../../contexts/LmsDataContext';
import { db } from '../../lib/firebase';
import { CourseBuilder } from '../admin/CourseBuilder';

export function InstructorPanelPage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { firebaseUser, profile, isInstructor, isAdmin } = useAuth();
  const { courses, lessons } = useLmsData();

  const [tab, setTab] = useState<'overview' | 'builder' | 'students'>('overview');
  const [courseEnrollments, setCourseEnrollments] = useState<Enrollment[]>([]);

  const assignedCourses = isAdmin
    ? courses
    : courses.filter((c) => c.instructorId === firebaseUser?.uid);

  useEffect(() => {
    if (!firebaseUser || assignedCourses.length === 0) {
      setCourseEnrollments([]);
      return;
    }
    const firstCourseId = assignedCourses[0].id;
    const unsub = onSnapshot(
      query(collection(db, 'enrollments'), where('courseId', '==', firstCourseId)),
      (snap) => setCourseEnrollments(snap.docs.map((d) => d.data() as Enrollment)),
      () => {
        // Ignore if demo preview course doesn't exist in Firestore
      }
    );
    return () => unsub();
  }, [firebaseUser?.uid, assignedCourses.length]);

  if (!firebaseUser || !isInstructor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 dark:border-[#263449] dark:bg-[#172033]">
          <ShieldAlert className="mx-auto h-10 w-10 text-rose-500" />
          <h1 className="mt-4 font-display text-2xl font-bold text-slate-900 dark:text-white">
            Instructor Access Restricted
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            This workspace is restricted to authorized instructors and administrators.
          </p>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'home' })}
            className="mt-6 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white"
          >
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
            Instructor Workspace · {profile?.displayName}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Instructor Panel
          </h1>
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-[#172033]">
          {[
            { id: 'overview' as const, label: 'Assigned Courses' },
            { id: 'builder' as const, label: 'Manage Lessons & Notes' },
            { id: 'students' as const, label: 'Student Progress' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === t.id
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-[#0B1120] dark:text-white'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
              <BookOpen className="h-5 w-5 text-emerald-500" />
              <p className="mt-3 text-xs text-slate-500">Assigned Courses</p>
              <p className="font-mono-tabular text-2xl font-bold text-slate-900 dark:text-white">
                {assignedCourses.length}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
              <TrendingUp className="h-5 w-5 text-emerald-500" />
              <p className="mt-3 text-xs text-slate-500">Total Lessons</p>
              <p className="font-mono-tabular text-2xl font-bold text-slate-900 dark:text-white">
                {
                  lessons.filter((l) => assignedCourses.some((c) => c.id === l.courseId)).length
                }
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
              <Users className="h-5 w-5 text-emerald-500" />
              <p className="mt-3 text-xs text-slate-500">Enrolled Students (Primary Course)</p>
              <p className="font-mono-tabular text-2xl font-bold text-slate-900 dark:text-white">
                {courseEnrollments.length}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assignedCourses.length === 0 ? (
              <p className="col-span-full rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500 dark:border-[#263449]">
                No courses assigned to your instructor account yet.
              </p>
            ) : (
              assignedCourses.map((c) => (
                <div
                  key={c.id}
                  className="flex items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
                >
                  <div>
                    <p className="text-xs text-emerald-600 dark:text-emerald-400">
                      {c.categoryName} · {c.status}
                    </p>
                    <h3 className="mt-1 font-display text-base font-bold text-slate-900 dark:text-white">
                      {c.title}
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setTab('builder')}
                    className="rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                  >
                    Manage Lessons
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {tab === 'builder' && (
        <CourseBuilder
          onNavigate={onNavigate}
          restrictToInstructorUid={isAdmin ? undefined : firebaseUser.uid}
        />
      )}

      {tab === 'students' && (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449] dark:text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Student ID</th>
                <th className="px-4 py-3 font-medium">Course</th>
                <th className="px-4 py-3 font-medium text-right">Completed</th>
                <th className="px-4 py-3 font-medium text-right">Progress</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
              {courseEnrollments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-xs text-slate-500">
                    No student enrollments recorded yet.
                  </td>
                </tr>
              ) : (
                courseEnrollments.map((enr) => (
                  <tr key={enr.id}>
                    <td className="px-4 py-3 font-mono-tabular text-xs">{enr.userId}</td>
                    <td className="px-4 py-3 text-xs">{enr.courseTitle}</td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-xs">
                      {enr.completedLessonsCount}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-xs font-semibold text-emerald-600">
                      {enr.progressPercent}%
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
