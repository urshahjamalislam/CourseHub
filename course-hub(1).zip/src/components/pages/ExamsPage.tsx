import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Play,
  XCircle,
} from 'lucide-react';
import { collection, doc, getDoc, getDocs, query, setDoc, updateDoc, where } from 'firebase/firestore';
import { AppRoute, Exam, ExamResult, Question, QuestionAnswer } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { DEMO_QUESTIONS, DEMO_QUESTION_ANSWERS } from '../../data/demoCurriculum';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';

interface ExamsPageProps {
  initialExamId?: string;
  onNavigate: (route: AppRoute) => void;
}

export function ExamsPage({ initialExamId, onNavigate }: ExamsPageProps) {
  const { exams, examResults, isUsingDemoPreview } = useLmsData();
  const { firebaseUser, isVerified } = useAuth();
  const { showToast } = useToast();

  const [activeExam, setActiveExam] = useState<Exam | null>(() =>
    initialExamId ? exams.find((e) => e.id === initialExamId) || null : null
  );
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answerKeyMap, setAnswerKeyMap] = useState<Record<string, QuestionAnswer>>({});
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const [submittedResult, setSubmittedResult] = useState<ExamResult | null>(null);
  const [loadingExam, setLoadingExam] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const startExam = async (exam: Exam) => {
    setActiveExam(exam);
    setSelectedAnswers({});
    setAnswerKeyMap({});
    setSubmittedResult(null);
    setSecondsLeft(exam.durationMinutes * 60);
    setLoadingExam(true);

    try {
      let qList: Question[] = [];
      if (isUsingDemoPreview) {
        qList = DEMO_QUESTIONS.filter((q) => q.examId === exam.id).sort((a, b) => a.order - b.order);
      } else {
        const snap = await getDocs(query(collection(db, 'questions'), where('examId', '==', exam.id)));
        qList = snap.docs.map((d) => d.data() as Question).sort((a, b) => a.order - b.order);
      }
      setQuestions(qList);

      // Check if user already submitted this exam
      const existingResult = examResults.find((r) => r.examId === exam.id);
      if (existingResult) {
        setSubmittedResult(existingResult);
        setSelectedAnswers(existingResult.answers || {});
        await loadAnswerKeys(qList);
      } else if (exam.practiceMode) {
        // Practice mode permits viewing answer keys immediately for self-check
        await loadAnswerKeys(qList);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'questions');
    } finally {
      setLoadingExam(false);
    }
  };

  const loadAnswerKeys = async (qList: Question[]) => {
    if (isUsingDemoPreview) {
      const map: Record<string, QuestionAnswer> = {};
      for (const q of qList) {
        const ans = DEMO_QUESTION_ANSWERS.find((a) => a.id === q.id);
        if (ans) map[q.id] = ans;
      }
      setAnswerKeyMap(map);
      return map;
    }

    const map: Record<string, QuestionAnswer> = {};
    for (const q of qList) {
      try {
        const snap = await getDoc(doc(db, 'question_answers', q.id));
        if (snap.exists()) {
          map[q.id] = snap.data() as QuestionAnswer;
        }
      } catch {
        // Only readable once exam_results exists or practiceMode == true
      }
    }
    setAnswerKeyMap(map);
    return map;
  };

  // Countdown Timer
  useEffect(() => {
    if (!activeExam || submittedResult || secondsLeft <= 0) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [activeExam?.id, submittedResult, secondsLeft]);

  const handleSubmitExam = async () => {
    if (!activeExam || submitting) return;
    if (!isUsingDemoPreview && (!firebaseUser || !isVerified)) {
      showToast('Sign In Required', 'Sign in with a verified account to submit exams.', 'info');
      onNavigate({ page: 'auth', mode: 'login' });
      return;
    }

    setSubmitting(true);
    try {
      const now = new Date().toISOString();

      if (isUsingDemoPreview) {
        const keys = await loadAnswerKeys(questions);
        let score = 0;
        let totalMarks = 0;
        for (const q of questions) {
          totalMarks += q.marks;
          if (keys[q.id] && selectedAnswers[q.id] === keys[q.id].correctIndex) {
            score += q.marks;
          }
        }
        const pct = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 0;
        setSubmittedResult({
          id: `demo_${activeExam.id}`,
          userId: firebaseUser?.uid || 'demo',
          examId: activeExam.id,
          courseId: activeExam.courseId,
          examTitle: activeExam.title,
          answers: selectedAnswers,
          score,
          totalMarks,
          percentage: pct,
          graded: true,
          submittedAt: now,
        });
        showToast('Exam Graded (Demo)', `Score: ${score}/${totalMarks} (${pct}%)`, 'success');
        setSubmitting(false);
        return;
      }

      const resultId = `${firebaseUser!.uid}_${activeExam.id}`;
      // Step 1: Create exam_results doc (unlocks question_answers reads under security rules)
      await setDoc(doc(db, 'exam_results', resultId), {
        id: resultId,
        userId: firebaseUser!.uid,
        examId: activeExam.id,
        courseId: activeExam.courseId,
        examTitle: activeExam.title,
        answers: selectedAnswers,
        graded: false,
        submittedAt: now,
      });

      // Step 2: Fetch answer keys & compute objective score
      const keys = await loadAnswerKeys(questions);
      let score = 0;
      let totalMarks = 0;
      for (const q of questions) {
        totalMarks += q.marks;
        if (keys[q.id] && selectedAnswers[q.id] === keys[q.id].correctIndex) {
          score += q.marks;
        }
      }
      const percentage = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 0;

      // Step 3: Lock graded score on exam_results
      await updateDoc(doc(db, 'exam_results', resultId), {
        score,
        totalMarks,
        percentage,
        graded: true,
      });

      setSubmittedResult({
        id: resultId,
        userId: firebaseUser!.uid,
        examId: activeExam.id,
        courseId: activeExam.courseId,
        examTitle: activeExam.title,
        answers: selectedAnswers,
        score,
        totalMarks,
        percentage,
        graded: true,
        submittedAt: now,
      });
      showToast('Exam Submitted', `You scored ${score}/${totalMarks} (${percentage}%)`, 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `exam_results`);
    } finally {
      setSubmitting(false);
    }
  };

  if (activeExam) {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;

    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => setActiveExam(null)}
            className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-emerald-600 dark:text-slate-400"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Exams
          </button>

          {!submittedResult && (
            <div className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-mono-tabular font-semibold text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-emerald-400">
              <Clock className="h-4 w-4" />
              <span>
                {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
              </span>
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-2">
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
            {activeExam.courseTitle} · {activeExam.practiceMode ? 'Practice Mode' : 'Timed Exam'}
          </p>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            {activeExam.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {activeExam.practiceMode
              ? 'Practice mode: Instant answer check is enabled.'
              : 'Strict mode: Correct answers remain hidden until submission.'}
          </p>
        </div>

        {submittedResult && (
          <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                Exam Result
              </p>
              <h2 className="mt-1 font-display text-2xl font-bold text-slate-900 dark:text-white font-mono-tabular">
                {submittedResult.score} / {submittedResult.totalMarks} ({submittedResult.percentage}%)
              </h2>
            </div>
            <span className="text-xs text-slate-600 dark:text-slate-300">
              Submitted {new Date(submittedResult.submittedAt).toLocaleString()}
            </span>
          </div>
        )}

        {loadingExam ? (
          <p className="py-12 text-center text-sm text-slate-500">Loading questions...</p>
        ) : questions.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 p-10 text-center dark:border-[#263449]">
            <p className="text-sm text-slate-500">No questions have been added to this exam yet.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {questions.map((q, idx) => {
              const chosen = selectedAnswers[q.id];
              const ansKey = answerKeyMap[q.id];
              const showKey = Boolean(submittedResult) || activeExam.practiceMode;
              return (
                <div
                  key={q.id}
                  className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4"
                >
                  <div className="flex items-start justify-between gap-4">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">
                      {idx + 1}. {q.prompt}
                    </p>
                    <span className="font-mono-tabular text-xs text-slate-500 shrink-0">
                      {q.marks} pts
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = chosen === optIdx;
                      const isCorrect = showKey && ansKey && ansKey.correctIndex === optIdx;
                      const isWrongSelected =
                        submittedResult && isSelected && ansKey && ansKey.correctIndex !== optIdx;

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          disabled={Boolean(submittedResult)}
                          onClick={() =>
                            setSelectedAnswers((prev) => ({ ...prev, [q.id]: optIdx }))
                          }
                          className={`flex items-center justify-between rounded-lg border px-4 py-2.5 text-left text-sm transition-colors ${
                            isCorrect && (submittedResult || isSelected)
                              ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                              : isWrongSelected
                              ? 'border-rose-500 bg-rose-500/15 text-rose-700 dark:text-rose-300'
                              : isSelected
                              ? 'border-emerald-500 bg-emerald-500/10 text-slate-900 dark:text-white'
                              : 'border-slate-200 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]'
                          }`}
                        >
                          <span>{opt}</span>
                          {isCorrect && (submittedResult || isSelected) && (
                            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                          )}
                          {isWrongSelected && <XCircle className="h-4 w-4 text-rose-500 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {showKey && ansKey?.explanation && (submittedResult || chosen !== undefined) && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 border-t border-slate-100 pt-2.5 dark:border-[#263449]">
                      Explanation: {ansKey.explanation}
                    </p>
                  )}
                </div>
              );
            })}

            {!submittedResult && (
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={handleSubmitExam}
                  className="rounded-lg bg-emerald-600 px-6 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {submitting ? 'Submitting...' : 'Submit Exam'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          Online Exams & Practice Quizzes
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Chapter assessments, practice quizzes, and instant objective grading.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {exams
          .filter((e) => e.status === 'published')
          .map((exam) => {
            const pastResult = examResults.find((r) => r.examId === exam.id);
            return (
              <div
                key={exam.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <div className="space-y-2">
                  <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    {exam.courseTitle || 'Course'} · {exam.practiceMode ? 'Practice Quiz' : 'Timed Exam'}
                  </p>
                  <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                    {exam.title}
                  </h3>
                  {exam.description && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {exam.description}
                    </p>
                  )}
                </div>

                <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4 dark:border-[#263449]">
                  <div className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400">
                    {exam.durationMinutes} min · {exam.totalMarks} marks
                    {pastResult ? ` · Scored ${pastResult.percentage}%` : ''}
                  </div>
                  <button
                    type="button"
                    onClick={() => startExam(exam)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                  >
                    <Play className="h-3.5 w-3.5" />
                    {pastResult ? 'Review Result' : 'Start Exam'}
                  </button>
                </div>
              </div>
            );
          })}
      </div>

      {examResults.length > 0 && (
        <div className="space-y-4">
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5 text-emerald-500" />
            My Result History
          </h2>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449] dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Exam</th>
                  <th className="px-4 py-3 font-medium text-right">Score</th>
                  <th className="px-4 py-3 font-medium text-right">Percentage</th>
                  <th className="px-4 py-3 font-medium text-right">Submitted</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                {examResults.map((r) => (
                  <tr key={r.id}>
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                      {r.examTitle || r.examId}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular">
                      {r.score ?? 0}/{r.totalMarks ?? 0}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular font-semibold text-emerald-600 dark:text-emerald-400">
                      {r.percentage ?? 0}%
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-xs text-slate-500">
                      {new Date(r.submittedAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
