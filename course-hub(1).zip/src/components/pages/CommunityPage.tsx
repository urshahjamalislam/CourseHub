import { useEffect, useState } from 'react';
import { EyeOff, Flag, MessageSquare, Send, Trash2 } from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { CommentItem } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import {
  clampStr,
  db,
  generateDocId,
  handleFirestoreError,
  OperationType,
} from '../../lib/firebase';

export function CommunityPage({ initialCourseId }: { initialCourseId?: string }) {
  const { courses, isUsingDemoPreview } = useLmsData();
  const { firebaseUser, profile, isAdmin, isVerified } = useAuth();
  const { showToast, confirm } = useToast();

  const [selectedCourseId, setSelectedCourseId] = useState(
    initialCourseId || courses[0]?.id || ''
  );
  const [threads, setThreads] = useState<CommentItem[]>([]);
  const [newPost, setNewPost] = useState('');
  const [replyTarget, setReplyTarget] = useState<string | null>(null);
  const [replyInput, setReplyInput] = useState('');
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    if (!selectedCourseId && courses.length > 0) {
      setSelectedCourseId(courses[0].id);
    }
  }, [courses, selectedCourseId]);

  useEffect(() => {
    if (!selectedCourseId || isUsingDemoPreview) {
      setThreads([]);
      return;
    }

    const q = isAdmin
      ? query(collection(db, 'comments'), where('courseId', '==', selectedCourseId))
      : query(
          collection(db, 'comments'),
          where('courseId', '==', selectedCourseId),
          where('status', '==', 'visible')
        );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as CommentItem)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setThreads(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'comments')
    );

    return () => unsub();
  }, [selectedCourseId, isUsingDemoPreview, isAdmin]);

  const handlePost = async (parentComment?: CommentItem) => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in with a verified account to participate.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to Firestore to post discussions.', 'info');
      return;
    }
    const content = (parentComment ? replyInput : newPost).trim();
    if (!content || !selectedCourseId) return;

    setPosting(true);
    const id = generateDocId('post');
    const now = new Date().toISOString();
    try {
      await setDoc(doc(db, 'comments', id), {
        id,
        courseId: selectedCourseId,
        lessonId: parentComment?.lessonId || '',
        userId: firebaseUser.uid,
        authorName: clampStr(profile?.displayName || firebaseUser.displayName || 'Student', 120),
        authorPhoto: clampStr(profile?.photoURL || '', 500),
        parentId: parentComment?.id || '',
        content: clampStr(content, 2000),
        status: 'visible',
        reportCount: 0,
        createdAt: now,
        updatedAt: now,
      });

      // Notify parent author on reply
      if (parentComment && parentComment.userId !== firebaseUser.uid) {
        const notifId = generateDocId('notif');
        await setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: parentComment.userId,
          type: 'reply',
          title: 'New Reply to Your Question',
          message: `${profile?.displayName || 'A learner'} replied: "${clampStr(content, 100)}"`,
          link: `course:${selectedCourseId}`,
          read: false,
          createdAt: now,
        });
      }

      if (parentComment) {
        setReplyInput('');
        setReplyTarget(null);
      } else {
        setNewPost('');
      }
      showToast('Posted', 'Your discussion message is live.', 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `comments/${id}`);
    } finally {
      setPosting(false);
    }
  };

  const rootThreads = threads.filter((t) => !t.parentId);
  const getReplies = (pid: string) => threads.filter((t) => t.parentId === pid);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Learning Community
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Ask conceptual questions, discuss board problems, and collaborate by course.
          </p>
        </div>

        <select
          aria-label="Select course forum"
          value={selectedCourseId}
          onChange={(e) => setSelectedCourseId(e.target.value)}
          className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
        >
          {courses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.title}
            </option>
          ))}
        </select>
      </div>

      {/* Composer */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-3">
        <textarea
          rows={3}
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
          placeholder="Ask a question about this course..."
          className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
        />
        <div className="flex justify-end">
          <button
            type="button"
            disabled={posting || !newPost.trim()}
            onClick={() => handlePost()}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
            Post Question
          </button>
        </div>
      </div>

      {/* Thread List */}
      <div className="space-y-4">
        {rootThreads.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
            <MessageSquare className="mx-auto h-8 w-8 text-slate-400" />
            <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
              {isUsingDemoPreview
                ? 'Community posts activate once courses are seeded to Firestore'
                : 'No discussions in this course yet'}
            </p>
          </div>
        ) : (
          rootThreads.map((t) => {
            const replies = getReplies(t.id);
            return (
              <div
                key={t.id}
                className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      {t.authorName}{' '}
                      <span className="font-normal text-slate-400">
                        · {new Date(t.createdAt).toLocaleString()}
                      </span>
                    </p>
                    <p className="mt-1.5 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {t.content}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs text-slate-500">
                  <button
                    type="button"
                    onClick={() => setReplyTarget(replyTarget === t.id ? null : t.id)}
                    className="font-medium hover:text-emerald-600 dark:hover:text-emerald-400"
                  >
                    Reply ({replies.length})
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser || !isVerified) return;
                      await updateDoc(doc(db, 'comments', t.id), {
                        reportCount: (t.reportCount || 0) + 1,
                        status: 'reported',
                        updatedAt: new Date().toISOString(),
                      });
                      showToast('Reported', 'Flagged for moderation.', 'info');
                    }}
                    className="inline-flex items-center gap-1 hover:text-amber-500"
                  >
                    <Flag className="h-3 w-3" />
                    Report
                  </button>
                  {isAdmin && (
                    <>
                      <button
                        type="button"
                        onClick={async () => {
                          await updateDoc(doc(db, 'comments', t.id), {
                            status: t.status === 'hidden' ? 'visible' : 'hidden',
                            updatedAt: new Date().toISOString(),
                          });
                        }}
                        className="inline-flex items-center gap-1 hover:text-sky-500"
                      >
                        <EyeOff className="h-3 w-3" />
                        {t.status === 'hidden' ? 'Unhide' : 'Hide'}
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          const ok = await confirm({
                            title: 'Delete Post',
                            message: 'Permanently remove this discussion post?',
                            destructive: true,
                          });
                          if (ok) await deleteDoc(doc(db, 'comments', t.id));
                        }}
                        className="inline-flex items-center gap-1 hover:text-rose-500"
                      >
                        <Trash2 className="h-3 w-3" />
                        Delete
                      </button>
                    </>
                  )}
                </div>

                {replyTarget === t.id && (
                  <div className="flex gap-2 pt-2">
                    <input
                      type="text"
                      value={replyInput}
                      onChange={(e) => setReplyInput(e.target.value)}
                      placeholder="Write a helpful reply..."
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={() => handlePost(t)}
                      className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white"
                    >
                      Reply
                    </button>
                  </div>
                )}

                {replies.length > 0 && (
                  <div className="ml-4 space-y-2 border-l border-slate-200 pl-4 pt-2 dark:border-[#263449]">
                    {replies.map((r) => (
                      <div key={r.id} className="text-xs">
                        <p className="font-semibold text-slate-900 dark:text-white">
                          {r.authorName}{' '}
                          <span className="font-normal text-slate-400">
                            · {new Date(r.createdAt).toLocaleDateString()}
                          </span>
                        </p>
                        <p className="mt-0.5 text-slate-600 dark:text-slate-300">{r.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
