import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  BookOpen,
  Briefcase,
  CheckCircle2,
  ClipboardCheck,
  CreditCard,
  Database,
  FileText,
  FolderTree,
  GraduationCap,
  Layers,
  LayoutDashboard,
  Megaphone,
  MessageSquare,
  Plus,
  Settings,
  ShieldAlert,
  Trash2,
  Users,
  Video,
  Wrench,
} from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  AdminTab,
  AppRoute,
  CommentItem,
  Enrollment,
  ExamResult,
  ExamType,
  MaterialType,
  PaymentGateway,
  PaymentRecord,
  UserProfile,
} from '../../types/lms';
import { useAuth } from '../../contexts/AuthContext';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useToast } from '../../contexts/ToastContext';
import { seedDemoCurriculumToFirestore } from '../../data/demoCurriculum';
import {
  clampStr,
  db,
  generateDocId,
  handleFirestoreError,
  OperationType,
  slugify,
} from '../../lib/firebase';
import { CourseBuilder } from '../admin/CourseBuilder';

interface AdminPanelPageProps {
  initialTab?: AdminTab;
  onNavigate: (route: AppRoute) => void;
}

interface GatewayStatus {
  id: PaymentGateway;
  name: string;
  configured: boolean;
  requiredEnvVars: string[];
}

export function AdminPanelPage({ initialTab = 'overview', onNavigate }: AdminPanelPageProps) {
  const { firebaseUser, isAdmin, profile } = useAuth();
  const {
    courses,
    categories,
    chapters,
    lessons,
    studyMaterials,
    liveClasses,
    exams,
    announcements,
    siteSettings,
    isUsingDemoPreview,
  } = useLmsData();
  const { showToast, confirm } = useToast();

  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab);
  const [builderCourseId, setBuilderCourseId] = useState<string | undefined>(undefined);
  const [seeding, setSeeding] = useState(false);

  // Admin-only collections
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [allEnrollments, setAllEnrollments] = useState<Enrollment[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRecord[]>([]);
  const [allComments, setAllComments] = useState<CommentItem[]>([]);
  const [allExamResults, setAllExamResults] = useState<ExamResult[]>([]);
  const [gatewayStatuses, setGatewayStatuses] = useState<GatewayStatus[]>([]);

  // Forms state
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');
  const [catIcon, setCatIcon] = useState('Atom');

  const [liveCourseId, setLiveCourseId] = useState(courses[0]?.id || '');
  const [liveTitle, setLiveTitle] = useState('');
  const [liveInstructor, setLiveInstructor] = useState(profile?.displayName || '');
  const [liveDate, setLiveDate] = useState('');
  const [liveUrl, setLiveUrl] = useState('');
  const [liveRecordingUrl, setLiveRecordingUrl] = useState('');

  const [examCourseId, setExamCourseId] = useState(courses[0]?.id || '');
  const [examTitle, setExamTitle] = useState('');
  const [examType, setExamType] = useState<ExamType>('mcq');
  const [examDuration, setExamDuration] = useState(20);
  const [examPractice, setExamPractice] = useState(false);
  const [selectedExamForQ, setSelectedExamForQ] = useState('');
  const [qPrompt, setQPrompt] = useState('');
  const [qOpts, setQOpts] = useState(['', '', '', '']);
  const [qCorrect, setQCorrect] = useState(0);
  const [qMarks, setQMarks] = useState(2);
  const [qExplain, setQExplain] = useState('');

  const [matCourseId, setMatCourseId] = useState(courses[0]?.id || '');
  const [matTitle, setMatTitle] = useState('');
  const [matType, setMatType] = useState<MaterialType>('pdf_notes');
  const [matUrl, setMatUrl] = useState('');
  const [matDesc, setMatDesc] = useState('');

  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annCourseId, setAnnCourseId] = useState('all');

  const [enrollUserUid, setEnrollUserUid] = useState('');
  const [enrollCourseId, setEnrollCourseId] = useState(courses[0]?.id || '');

  const [settingsForm, setSettingsForm] = useState(siteSettings);

  useEffect(() => {
    setSettingsForm(siteSettings);
  }, [siteSettings]);

  useEffect(() => {
    if (!isAdmin) return;

    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => setAllUsers(snap.docs.map((d) => d.data() as UserProfile)),
      () => {}
    );
    const unsubEnroll = onSnapshot(
      collection(db, 'enrollments'),
      (snap) => setAllEnrollments(snap.docs.map((d) => d.data() as Enrollment)),
      () => {}
    );
    const unsubPay = onSnapshot(
      collection(db, 'payments'),
      (snap) => setAllPayments(snap.docs.map((d) => d.data() as PaymentRecord)),
      () => {}
    );
    const unsubComm = onSnapshot(
      collection(db, 'comments'),
      (snap) => setAllComments(snap.docs.map((d) => d.data() as CommentItem)),
      () => {}
    );
    const unsubResults = onSnapshot(
      collection(db, 'exam_results'),
      (snap) => setAllExamResults(snap.docs.map((d) => d.data() as ExamResult)),
      () => {}
    );

    fetch('/api/payments/gateways')
      .then((r) => r.json())
      .then((d) => setGatewayStatuses(d.gateways || []))
      .catch(() => {});

    return () => {
      unsubUsers();
      unsubEnroll();
      unsubPay();
      unsubComm();
      unsubResults();
    };
  }, [isAdmin]);

  if (!firebaseUser || !isAdmin) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 dark:border-[#263449] dark:bg-[#172033]">
          <ShieldAlert className="mx-auto h-10 w-10 text-rose-500" />
          <h1 className="mt-4 font-display text-2xl font-bold text-slate-900 dark:text-white">
            Administrator Authorization Required
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Students cannot access administrative routes. Sign in with an authorized administrator
            account.
          </p>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'home' })}
            className="mt-6 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white"
          >
            Return Home
          </button>
        </div>
      </div>
    );
  }

  const handleSeedDemo = async () => {
    setSeeding(true);
    try {
      await seedDemoCurriculumToFirestore();
      showToast(
        'Demo Curriculum Seeded',
        'HSC Physics, Chemistry, Biology, Higher Math, and ICT demo data saved to Firestore.',
        'success'
      );
    } catch (err) {
      showToast('Seeding Failed', err instanceof Error ? err.message : 'Error seeding demo data', 'error');
    } finally {
      setSeeding(false);
    }
  };

  const studentsList = allUsers.filter((u) => u.role === 'student');
  const instructorsList = allUsers.filter((u) => u.role === 'instructor' || u.role === 'admin');
  const verifiedRevenue = allPayments
    .filter((p) => p.status === 'verified')
    .reduce((sum, p) => sum + (p.amount || 0), 0);

  const adminSidebarItems: Array<{
    id: AdminTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'builder', label: 'Course Builder', icon: Wrench },
    { id: 'categories', label: 'Categories', icon: FolderTree },
    { id: 'instructors', label: 'Instructors', icon: Briefcase },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'enrollments', label: 'Enrollments', icon: GraduationCap },
    { id: 'live_classes', label: 'Live Classes', icon: Video },
    { id: 'exams', label: 'Exams & Quizzes', icon: ClipboardCheck },
    { id: 'materials', label: 'Study Materials', icon: FileText },
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'comments', label: 'Comments', icon: MessageSquare },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Admin Navigation Rail */}
        <aside className="lg:w-60 shrink-0">
          <div className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-[#263449] dark:bg-[#172033]">
            <p className="px-3 pb-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              Admin Console
            </p>
            <div className="flex lg:flex-col gap-1 overflow-x-auto pb-1 lg:pb-0">
              {adminSidebarItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      active
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-[#111827]'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Admin Content */}
        <div className="flex-1 min-w-0 space-y-6">
          {/* 1. Overview */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033]">
                <div>
                  <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                    Platform Administration
                  </h1>
                  <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                    Manage courses, chapters, YouTube lectures, exams, payments, and permissions.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={seeding}
                    onClick={handleSeedDemo}
                    className="inline-flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-300"
                  >
                    <Database className="h-4 w-4" />
                    {seeding ? 'Seeding Demo Data...' : 'Seed Demo HSC Curriculum'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setBuilderCourseId(undefined);
                      setActiveTab('builder');
                    }}
                    className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                  >
                    <Plus className="h-4 w-4" />
                    Create Course
                  </button>
                </div>
              </div>

              {isUsingDemoPreview && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-800 dark:text-amber-200">
                  Firestore currently has 0 courses. Click{' '}
                  <strong>Seed Demo HSC Curriculum</strong> above to write the sample Physics,
                  Chemistry, Biology, Higher Math, and ICT courses into Firestore so students can
                  enroll and edit progress.
                </div>
              )}

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { label: 'Students', value: studentsList.length },
                  { label: 'Instructors', value: instructorsList.length },
                  { label: 'Courses', value: courses.length },
                  { label: 'Lessons', value: lessons.length },
                  { label: 'Enrollments', value: allEnrollments.length },
                  { label: 'Revenue (BDT)', value: `৳${verifiedRevenue.toLocaleString()}` },
                ].map((m) => (
                  <div
                    key={m.label}
                    className="rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]"
                  >
                    <p className="text-xs text-slate-500 dark:text-slate-400">{m.label}</p>
                    <p className="mt-2 font-mono-tabular text-xl font-bold text-slate-900 dark:text-white">
                      {m.value}
                    </p>
                  </div>
                ))}
              </div>

              {/* Recent Registrations & Enrollments */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
                  <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                    Recent Registrations
                  </h2>
                  <div className="mt-3 divide-y divide-slate-100 dark:divide-[#263449]">
                    {allUsers.length === 0 ? (
                      <p className="py-4 text-xs text-slate-500">No registrations yet.</p>
                    ) : (
                      allUsers.slice(0, 5).map((u) => (
                        <div key={u.uid} className="py-2.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-semibold text-slate-900 dark:text-white">
                              {u.displayName}
                            </p>
                            <p className="text-slate-500">{u.email}</p>
                          </div>
                          <span className="text-slate-400">{u.role}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]">
                  <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                    Recent Enrollments
                  </h2>
                  <div className="mt-3 divide-y divide-slate-100 dark:divide-[#263449]">
                    {allEnrollments.length === 0 ? (
                      <p className="py-4 text-xs text-slate-500">No enrollments yet.</p>
                    ) : (
                      allEnrollments.slice(0, 5).map((e) => (
                        <div key={e.id} className="py-2.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-semibold text-slate-900 dark:text-white">
                              {e.courseTitle || e.courseId}
                            </p>
                            <p className="text-slate-500 font-mono-tabular">User: {e.userId}</p>
                          </div>
                          <span className="font-mono-tabular text-emerald-500">{e.status}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. Courses Table */}
          {activeTab === 'courses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  All Courses ({courses.length})
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    setBuilderCourseId(undefined);
                    setActiveTab('builder');
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  <Plus className="h-4 w-4" />
                  Create Course
                </button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">Course</th>
                      <th className="px-4 py-3 font-medium">Category</th>
                      <th className="px-4 py-3 font-medium">Price</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {courses.map((c) => (
                      <tr key={c.id}>
                        <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                          {c.title}
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-500">{c.categoryName}</td>
                        <td className="px-4 py-3 font-mono-tabular text-xs">
                          {c.isFree ? 'Free' : `৳${c.price}`}
                        </td>
                        <td className="px-4 py-3 text-xs">{c.status}</td>
                        <td className="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setBuilderCourseId(c.id);
                              setActiveTab('builder');
                            }}
                            className="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium dark:border-[#263449]"
                          >
                            Edit Builder
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'courses', c.id), {
                                status: c.status === 'published' ? 'draft' : 'published',
                                updatedAt: new Date().toISOString(),
                              });
                              showToast('Updated Status', c.title, 'success');
                            }}
                            className="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium dark:border-[#263449]"
                          >
                            {c.status === 'published' ? 'Unpublish' : 'Publish'}
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              const ok = await confirm({
                                title: 'Delete Course',
                                message: `Delete "${c.title}"?`,
                                destructive: true,
                              });
                              if (ok) await deleteDoc(doc(db, 'courses', c.id));
                            }}
                            className="rounded border border-rose-500/30 px-2.5 py-1 text-xs font-medium text-rose-500"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 3. Course -> Chapter -> Lesson Builder */}
          {activeTab === 'builder' && (
            <CourseBuilder initialCourseId={builderCourseId} onNavigate={onNavigate} />
          )}

          {/* 4. Categories */}
          {activeTab === 'categories' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Course Categories
              </h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!catName.trim()) return;
                  const id = generateDocId('cat');
                  const now = new Date().toISOString();
                  await setDoc(doc(db, 'categories', id), {
                    id,
                    name: clampStr(catName, 80),
                    slug: slugify(catName),
                    description: clampStr(catDesc, 300),
                    iconName: catIcon,
                    isVisible: true,
                    order: categories.length + 1,
                    createdAt: now,
                    updatedAt: now,
                  });
                  setCatName('');
                  setCatDesc('');
                  showToast('Category Created', undefined, 'success');
                }}
                className="grid grid-cols-1 sm:grid-cols-4 gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]"
              >
                <input
                  type="text"
                  required
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  placeholder="Category Name"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="text"
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  placeholder="Short description"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <select
                  value={catIcon}
                  onChange={(e) => setCatIcon(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  <option value="Atom">Science (Atom)</option>
                  <option value="Sigma">Math (Sigma)</option>
                  <option value="Cpu">ICT (Cpu)</option>
                  <option value="BookOpen">English (Book)</option>
                  <option value="GraduationCap">Admission (Cap)</option>
                  <option value="Compass">Skills (Compass)</option>
                </select>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Add Category
                </button>
              </form>

              <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
                {categories.map((cat) => (
                  <div key={cat.id} className="flex items-center justify-between gap-4 p-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {cat.name}{' '}
                        <span className="text-xs font-normal text-slate-400">
                          ({cat.isVisible ? 'Visible' : 'Hidden'})
                        </span>
                      </p>
                      <p className="text-xs text-slate-500">{cat.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          await updateDoc(doc(db, 'categories', cat.id), {
                            isVisible: !cat.isVisible,
                            updatedAt: new Date().toISOString(),
                          });
                        }}
                        className="rounded-lg border border-slate-200 px-3 py-1 text-xs dark:border-[#263449]"
                      >
                        {cat.isVisible ? 'Hide' : 'Show'}
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteDoc(doc(db, 'categories', cat.id));
                          showToast('Category Deleted', undefined, 'info');
                        }}
                        className="rounded-lg p-1.5 text-rose-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. Instructors & Permissions */}
          {activeTab === 'instructors' && (
            <div className="space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Instructors & Role Permissions
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Promote registered users to Instructor or Student and control permissions.
              </p>
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">Name</th>
                      <th className="px-4 py-3 font-medium">Email</th>
                      <th className="px-4 py-3 font-medium">Role</th>
                      <th className="px-4 py-3 font-medium text-right">Change Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {allUsers.map((u) => (
                      <tr key={u.uid}>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                          {u.displayName}
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-500">{u.email}</td>
                        <td className="px-4 py-3 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                          {u.role}
                        </td>
                        <td className="px-4 py-3 text-right space-x-2">
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'users', u.uid), {
                                role: u.role === 'instructor' ? 'student' : 'instructor',
                                updatedAt: new Date().toISOString(),
                              });
                              await updateDoc(doc(db, 'public_profiles', u.uid), {
                                role: u.role === 'instructor' ? 'student' : 'instructor',
                                updatedAt: new Date().toISOString(),
                              });
                              showToast('Role Updated', u.displayName, 'success');
                            }}
                            className="rounded border border-slate-200 px-3 py-1 text-xs font-medium dark:border-[#263449]"
                          >
                            {u.role === 'instructor' ? 'Set Student' : 'Promote Instructor'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 6. Students */}
          {activeTab === 'students' && (
            <div className="space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Registered Students ({studentsList.length})
              </h2>
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">Name</th>
                      <th className="px-4 py-3 font-medium">Email</th>
                      <th className="px-4 py-3 font-medium">Level</th>
                      <th className="px-4 py-3 font-medium">Institution</th>
                      <th className="px-4 py-3 font-medium">UID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {studentsList.map((s) => (
                      <tr key={s.uid}>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                          {s.displayName}
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-500">{s.email}</td>
                        <td className="px-4 py-3 text-xs">{s.educationLevel || '—'}</td>
                        <td className="px-4 py-3 text-xs">{s.institution || '—'}</td>
                        <td className="px-4 py-3 font-mono-tabular text-[11px] text-slate-400">
                          {s.uid}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 7. Enrollments */}
          {activeTab === 'enrollments' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Enrollments Management
              </h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!enrollUserUid || !enrollCourseId) return;
                  const course = courses.find((c) => c.id === enrollCourseId);
                  const id = `${enrollUserUid}_${enrollCourseId}`;
                  const now = new Date().toISOString();
                  await setDoc(doc(db, 'enrollments', id), {
                    id,
                    userId: enrollUserUid,
                    courseId: enrollCourseId,
                    courseTitle: course?.title || '',
                    status: 'active',
                    progressPercent: 0,
                    completedLessonsCount: 0,
                    enrolledAt: now,
                    updatedAt: now,
                  });
                  showToast('Enrollment Granted', undefined, 'success');
                }}
                className="grid grid-cols-1 sm:grid-cols-3 gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]"
              >
                <select
                  value={enrollUserUid}
                  onChange={(e) => setEnrollUserUid(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  <option value="">Select User...</option>
                  {allUsers.map((u) => (
                    <option key={u.uid} value={u.uid}>
                      {u.displayName} ({u.email})
                    </option>
                  ))}
                </select>
                <select
                  value={enrollCourseId}
                  onChange={(e) => setEnrollCourseId(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Grant Course Access
                </button>
              </form>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">User UID</th>
                      <th className="px-4 py-3 font-medium">Course</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium text-right">Progress</th>
                      <th className="px-4 py-3 font-medium text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {allEnrollments.map((enr) => (
                      <tr key={enr.id}>
                        <td className="px-4 py-3 font-mono-tabular text-xs">{enr.userId}</td>
                        <td className="px-4 py-3 text-xs font-medium">{enr.courseTitle}</td>
                        <td className="px-4 py-3 text-xs">{enr.status}</td>
                        <td className="px-4 py-3 text-right font-mono-tabular text-xs">
                          {enr.progressPercent}%
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'enrollments', enr.id), {
                                status: enr.status === 'active' ? 'revoked' : 'active',
                                updatedAt: new Date().toISOString(),
                              });
                            }}
                            className="rounded border border-slate-200 px-2.5 py-1 text-xs dark:border-[#263449]"
                          >
                            {enr.status === 'active' ? 'Revoke' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 8. Live Classes */}
          {activeTab === 'live_classes' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Live Class Schedule Management
              </h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!liveTitle.trim() || !liveDate) return;
                  const id = generateDocId('live');
                  const now = new Date().toISOString();
                  const c = courses.find((x) => x.id === liveCourseId);
                  await setDoc(doc(db, 'live_classes', id), {
                    id,
                    courseId: liveCourseId || courses[0]?.id || 'general',
                    courseTitle: c?.title || 'Course',
                    title: clampStr(liveTitle, 200),
                    instructorName: clampStr(liveInstructor || 'Instructor', 120),
                    scheduledAt: new Date(liveDate).toISOString(),
                    durationMinutes: 60,
                    meetingUrl: clampStr(liveUrl, 500),
                    recordingUrl: clampStr(liveRecordingUrl, 500),
                    status: 'scheduled',
                    createdAt: now,
                    updatedAt: now,
                  });
                  setLiveTitle('');
                  setLiveUrl('');
                  showToast('Live Class Scheduled', undefined, 'success');
                }}
                className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <select
                  value={liveCourseId}
                  onChange={(e) => setLiveCourseId(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={liveTitle}
                  onChange={(e) => setLiveTitle(e.target.value)}
                  placeholder="Class Title"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="datetime-local"
                  required
                  value={liveDate}
                  onChange={(e) => setLiveDate(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="text"
                  value={liveInstructor}
                  onChange={(e) => setLiveInstructor(e.target.value)}
                  placeholder="Instructor Name"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="url"
                  value={liveUrl}
                  onChange={(e) => setLiveUrl(e.target.value)}
                  placeholder="Live Meeting URL (Zoom/Meet)"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Schedule Live Class
                </button>
              </form>

              <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
                {liveClasses.map((lc) => (
                  <div key={lc.id} className="flex flex-wrap items-center justify-between gap-4 p-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {lc.title}
                      </p>
                      <p className="text-xs text-slate-500 font-mono-tabular">
                        {lc.courseTitle} · {new Date(lc.scheduledAt).toLocaleString()} · {lc.status}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          const next =
                            lc.status === 'scheduled'
                              ? 'live'
                              : lc.status === 'live'
                              ? 'completed'
                              : 'scheduled';
                          await updateDoc(doc(db, 'live_classes', lc.id), {
                            status: next,
                            updatedAt: new Date().toISOString(),
                          });
                        }}
                        className="rounded border border-slate-200 px-2.5 py-1 text-xs dark:border-[#263449]"
                      >
                        Cycle Status
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteDoc(doc(db, 'live_classes', lc.id));
                        }}
                        className="text-rose-500 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 9. Exams & Questions */}
          {activeTab === 'exams' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Exam & Question Bank Builder
              </h2>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!examTitle.trim()) return;
                  const id = generateDocId('exam');
                  const now = new Date().toISOString();
                  const c = courses.find((x) => x.id === examCourseId);
                  await setDoc(doc(db, 'exams', id), {
                    id,
                    courseId: examCourseId || courses[0]?.id || 'general',
                    courseTitle: c?.title || 'Course',
                    title: clampStr(examTitle, 200),
                    examType,
                    durationMinutes: Number(examDuration) || 20,
                    totalMarks: 10,
                    practiceMode: examPractice,
                    status: 'published',
                    createdAt: now,
                    updatedAt: now,
                  });
                  setSelectedExamForQ(id);
                  setExamTitle('');
                  showToast('Exam Created', 'Now add MCQ questions below.', 'success');
                }}
                className="grid grid-cols-1 md:grid-cols-5 gap-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <select
                  value={examCourseId}
                  onChange={(e) => setExamCourseId(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={examTitle}
                  onChange={(e) => setExamTitle(e.target.value)}
                  placeholder="Exam Title"
                  className="md:col-span-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="number"
                  min={1}
                  value={examDuration}
                  onChange={(e) => setExamDuration(Number(e.target.value))}
                  placeholder="Minutes"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <div className="flex items-center gap-2">
                  <label className="inline-flex items-center gap-1.5 text-xs">
                    <input
                      type="checkbox"
                      checked={examPractice}
                      onChange={(e) => setExamPractice(e.target.checked)}
                    />
                    Practice
                  </label>
                  <button
                    type="submit"
                    className="flex-1 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white"
                  >
                    Create Exam
                  </button>
                </div>
              </form>

              {/* Add Question to Exam */}
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const targetExam = exams.find((x) => x.id === (selectedExamForQ || exams[0]?.id));
                  if (!targetExam || !qPrompt.trim()) return;
                  const qId = generateDocId('q');
                  const now = new Date().toISOString();
                  await setDoc(doc(db, 'questions', qId), {
                    id: qId,
                    examId: targetExam.id,
                    courseId: targetExam.courseId,
                    prompt: clampStr(qPrompt, 1500),
                    options: qOpts.map((o) => clampStr(o || 'Option', 300)),
                    marks: Number(qMarks) || 2,
                    order: Date.now(),
                    createdAt: now,
                  });
                  await setDoc(doc(db, 'question_answers', qId), {
                    id: qId,
                    examId: targetExam.id,
                    courseId: targetExam.courseId,
                    correctIndex: Number(qCorrect),
                    explanation: clampStr(qExplain, 1500),
                  });
                  setQPrompt('');
                  setQOpts(['', '', '', '']);
                  setQExplain('');
                  showToast('Question Added', targetExam.title, 'success');
                }}
                className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-3"
              >
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Add MCQ Question
                </h3>
                <select
                  value={selectedExamForQ || exams[0]?.id || ''}
                  onChange={(e) => setSelectedExamForQ(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  {exams.map((ex) => (
                    <option key={ex.id} value={ex.id}>
                      {ex.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={qPrompt}
                  onChange={(e) => setQPrompt(e.target.value)}
                  placeholder="Question prompt..."
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {qOpts.map((opt, idx) => (
                    <input
                      key={idx}
                      type="text"
                      required
                      value={opt}
                      onChange={(e) => {
                        const copy = [...qOpts];
                        copy[idx] = e.target.value;
                        setQOpts(copy);
                      }}
                      placeholder={`Option ${idx + 1}`}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                    />
                  ))}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <select
                    value={qCorrect}
                    onChange={(e) => setQCorrect(Number(e.target.value))}
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  >
                    <option value={0}>Correct: Option 1</option>
                    <option value={1}>Correct: Option 2</option>
                    <option value={2}>Correct: Option 3</option>
                    <option value={3}>Correct: Option 4</option>
                  </select>
                  <input
                    type="number"
                    min={1}
                    value={qMarks}
                    onChange={(e) => setQMarks(Number(e.target.value))}
                    placeholder="Marks"
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                  <input
                    type="text"
                    value={qExplain}
                    onChange={(e) => setQExplain(e.target.value)}
                    placeholder="Solution explanation (optional)"
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                </div>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Question
                </button>
              </form>
            </div>
          )}

          {/* 10. Study Materials */}
          {activeTab === 'materials' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Study Materials Manager
              </h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!matTitle.trim()) return;
                  const id = generateDocId('mat');
                  const now = new Date().toISOString();
                  const c = courses.find((x) => x.id === matCourseId);
                  const url =
                    matUrl.trim() ||
                    `/api/resources/pdf?title=${encodeURIComponent(
                      matTitle
                    )}&course=${encodeURIComponent(c?.title || 'Course Hub')}&summary=${encodeURIComponent(
                      matDesc || matTitle
                    )}`;
                  await setDoc(doc(db, 'study_materials', id), {
                    id,
                    courseId: matCourseId || courses[0]?.id || 'general',
                    courseTitle: c?.title || 'Course',
                    title: clampStr(matTitle, 200),
                    type: matType,
                    description: clampStr(matDesc, 1000),
                    fileUrl: clampStr(url, 600),
                    fileName: `${slugify(matTitle)}.pdf`,
                    downloadsEnabled: true,
                    uploadedBy: firebaseUser.uid,
                    createdAt: now,
                    updatedAt: now,
                  });
                  setMatTitle('');
                  setMatUrl('');
                  setMatDesc('');
                  showToast('Study Material Uploaded', undefined, 'success');
                }}
                className="grid grid-cols-1 md:grid-cols-2 gap-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <select
                  value={matCourseId}
                  onChange={(e) => setMatCourseId(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <select
                  value={matType}
                  onChange={(e) => setMatType(e.target.value as MaterialType)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                >
                  <option value="pdf_notes">PDF Notes</option>
                  <option value="slides">Class Slides</option>
                  <option value="worksheet">Worksheet</option>
                  <option value="book">Book / Guide</option>
                  <option value="assignment">Assignment</option>
                </select>
                <input
                  type="text"
                  required
                  value={matTitle}
                  onChange={(e) => setMatTitle(e.target.value)}
                  placeholder="Material Title"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="text"
                  value={matUrl}
                  onChange={(e) => setMatUrl(e.target.value)}
                  placeholder="PDF URL (leave blank to auto-generate study PDF)"
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <input
                  type="text"
                  value={matDesc}
                  onChange={(e) => setMatDesc(e.target.value)}
                  placeholder="Description"
                  className="md:col-span-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <button
                  type="submit"
                  className="md:col-span-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Publish Study Material
                </button>
              </form>

              <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
                {studyMaterials.map((m) => (
                  <div key={m.id} className="flex items-center justify-between gap-4 p-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {m.title}
                      </p>
                      <p className="text-xs text-slate-500">
                        {m.courseTitle} · {m.type} · Downloads{' '}
                        {m.downloadsEnabled ? 'Enabled' : 'Disabled'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          await updateDoc(doc(db, 'study_materials', m.id), {
                            downloadsEnabled: !m.downloadsEnabled,
                            updatedAt: new Date().toISOString(),
                          });
                        }}
                        className="rounded border border-slate-200 px-2.5 py-1 text-xs dark:border-[#263449]"
                      >
                        {m.downloadsEnabled ? 'Disable Download' : 'Enable Download'}
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteDoc(doc(db, 'study_materials', m.id));
                        }}
                        className="text-rose-500 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 11. Announcements */}
          {activeTab === 'announcements' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Announcements
              </h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!annTitle.trim() || !annContent.trim()) return;
                  const id = generateDocId('ann');
                  const now = new Date().toISOString();
                  const c = courses.find((x) => x.id === annCourseId);
                  await setDoc(doc(db, 'announcements', id), {
                    id,
                    courseId: annCourseId,
                    courseTitle: annCourseId === 'all' ? 'All Courses' : c?.title || 'Course',
                    title: clampStr(annTitle, 180),
                    content: clampStr(annContent, 2500),
                    authorName: clampStr(profile?.displayName || 'Administrator', 120),
                    createdAt: now,
                    updatedAt: now,
                  });
                  setAnnTitle('');
                  setAnnContent('');
                  showToast('Announcement Published', undefined, 'success');
                }}
                className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-3"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    value={annTitle}
                    onChange={(e) => setAnnTitle(e.target.value)}
                    placeholder="Announcement Title"
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                  <select
                    value={annCourseId}
                    onChange={(e) => setAnnCourseId(e.target.value)}
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  >
                    <option value="all">Platform-Wide (All Students)</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>
                <textarea
                  rows={3}
                  required
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  placeholder="Announcement details..."
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Publish Announcement
                </button>
              </form>

              <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
                {announcements.map((a) => (
                  <div key={a.id} className="flex items-start justify-between gap-4 p-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {a.title}
                      </p>
                      <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">{a.content}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => deleteDoc(doc(db, 'announcements', a.id))}
                      className="text-rose-500 p-1 shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 12. Comments Moderation */}
          {activeTab === 'comments' && (
            <div className="space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Comments Moderation ({allComments.length})
              </h2>
              <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
                {allComments.length === 0 ? (
                  <p className="p-8 text-center text-xs text-slate-500">No comments yet.</p>
                ) : (
                  allComments.map((c) => (
                    <div key={c.id} className="flex items-start justify-between gap-4 p-4">
                      <div>
                        <p className="text-xs font-semibold text-slate-900 dark:text-white">
                          {c.authorName} · Status: {c.status} · Reports: {c.reportCount}
                        </p>
                        <p className="mt-1 text-sm text-slate-700 dark:text-slate-300">
                          {c.content}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            updateDoc(doc(db, 'comments', c.id), {
                              status: c.status === 'hidden' ? 'visible' : 'hidden',
                              updatedAt: new Date().toISOString(),
                            })
                          }
                          className="rounded border border-slate-200 px-2.5 py-1 text-xs dark:border-[#263449]"
                        >
                          {c.status === 'hidden' ? 'Restore' : 'Hide'}
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteDoc(doc(db, 'comments', c.id))}
                          className="text-rose-500 p-1"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 13. Payments & Bangladesh Gateways */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Payments & Bangladesh Gateways
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {gatewayStatuses.map((gw) => (
                  <div
                    key={gw.id}
                    className="rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]"
                  >
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{gw.name}</p>
                    <p
                      className={`mt-1 text-xs font-semibold ${
                        gw.configured ? 'text-emerald-500' : 'text-amber-500'
                      }`}
                    >
                      {gw.configured ? 'Configured' : 'Needs Env Credentials'}
                    </p>
                    <p className="mt-2 font-mono-tabular text-[11px] text-slate-400 break-words">
                      {gw.requiredEnvVars.join(', ')}
                    </p>
                  </div>
                ))}
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">Transaction Ref</th>
                      <th className="px-4 py-3 font-medium">Course</th>
                      <th className="px-4 py-3 font-medium">Gateway</th>
                      <th className="px-4 py-3 font-medium text-right">Amount</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium text-right">Verify</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {allPayments.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-xs text-slate-500">
                          No payment records submitted yet.
                        </td>
                      </tr>
                    ) : (
                      allPayments.map((p) => (
                        <tr key={p.id}>
                          <td className="px-4 py-3 font-mono-tabular text-xs">
                            {p.transactionRef || p.id}
                          </td>
                          <td className="px-4 py-3 text-xs">{p.courseTitle}</td>
                          <td className="px-4 py-3 text-xs uppercase">{p.gateway}</td>
                          <td className="px-4 py-3 text-right font-mono-tabular text-xs">
                            ৳{p.amount}
                          </td>
                          <td className="px-4 py-3 text-xs font-semibold">{p.status}</td>
                          <td className="px-4 py-3 text-right space-x-2">
                            {p.status === 'pending' && (
                              <button
                                type="button"
                                onClick={async () => {
                                  const now = new Date().toISOString();
                                  await updateDoc(doc(db, 'payments', p.id), {
                                    status: 'verified',
                                    verifiedAt: now,
                                  });
                                  const enrId = `${p.userId}_${p.courseId}`;
                                  await setDoc(doc(db, 'enrollments', enrId), {
                                    id: enrId,
                                    userId: p.userId,
                                    courseId: p.courseId,
                                    courseTitle: p.courseTitle || '',
                                    status: 'active',
                                    paymentId: p.id,
                                    progressPercent: 0,
                                    completedLessonsCount: 0,
                                    enrolledAt: now,
                                    updatedAt: now,
                                  });
                                  showToast(
                                    'Payment Verified & Enrolled',
                                    p.transactionRef,
                                    'success'
                                  );
                                }}
                                className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2.5 py-1 text-xs font-semibold text-white"
                              >
                                <CheckCircle2 className="h-3.5 w-3.5" />
                                Verify & Enroll
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 14. Reports */}
          {activeTab === 'reports' && (
            <div className="space-y-6">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Exam & Academic Reports
              </h2>
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-xs text-slate-500 dark:border-[#263449]">
                    <tr>
                      <th className="px-4 py-3 font-medium">Student UID</th>
                      <th className="px-4 py-3 font-medium">Exam</th>
                      <th className="px-4 py-3 font-medium text-right">Score</th>
                      <th className="px-4 py-3 font-medium text-right">Percent</th>
                      <th className="px-4 py-3 font-medium text-right">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {allExamResults.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-xs text-slate-500">
                          No exam submissions yet.
                        </td>
                      </tr>
                    ) : (
                      allExamResults.map((er) => (
                        <tr key={er.id}>
                          <td className="px-4 py-3 font-mono-tabular text-xs">{er.userId}</td>
                          <td className="px-4 py-3 text-xs">{er.examTitle || er.examId}</td>
                          <td className="px-4 py-3 text-right font-mono-tabular text-xs">
                            {er.score}/{er.totalMarks}
                          </td>
                          <td className="px-4 py-3 text-right font-mono-tabular text-xs text-emerald-500 font-semibold">
                            {er.percentage}%
                          </td>
                          <td className="px-4 py-3 text-right font-mono-tabular text-xs text-slate-400">
                            {new Date(er.submittedAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 15. Site Settings */}
          {activeTab === 'settings' && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await setDoc(doc(db, 'site_settings', 'global'), {
                  ...settingsForm,
                  id: 'global',
                  updatedAt: new Date().toISOString(),
                });
                showToast('Settings Saved', 'Platform configuration updated.', 'success');
              }}
              className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-4"
            >
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Platform Settings & Homepage Configuration
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-1">Website Name</label>
                  <input
                    type="text"
                    value={settingsForm.siteName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, siteName: e.target.value })}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Tagline</label>
                  <input
                    type="text"
                    value={settingsForm.tagline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Hero Headline</label>
                  <input
                    type="text"
                    value={settingsForm.heroTitle || ''}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroTitle: e.target.value })}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Contact Email</label>
                  <input
                    type="email"
                    value={settingsForm.contactEmail || ''}
                    onChange={(e) =>
                      setSettingsForm({ ...settingsForm, contactEmail: e.target.value })
                    }
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium mb-1">Hero Subtitle</label>
                <textarea
                  rows={2}
                  value={settingsForm.heroSubtitle || ''}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, heroSubtitle: e.target.value })
                  }
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm dark:border-[#263449] dark:bg-[#0B1120] dark:text-white"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  Save Platform Settings
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
