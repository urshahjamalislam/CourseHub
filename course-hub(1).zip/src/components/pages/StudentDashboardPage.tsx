import {
  BookOpen,
  Calendar,
  ClipboardCheck,
  FileText,
  Megaphone,
  Play,
  TrendingUp,
} from 'lucide-react';
import { AppRoute, Course } from '../../types/lms';
import { useAuth } from '../../contexts/AuthContext';
import { useLmsData } from '../../contexts/LmsDataContext';
import { CourseThumbnail } from '../common/CourseThumbnail';

interface StudentDashboardPageProps {
  onNavigate: (route: AppRoute) => void;
}

export function StudentDashboardPage({ onNavigate }: StudentDashboardPageProps) {
  const { firebaseUser, profile, isVerified } = useAuth();
  const {
    courses,
    lessons,
    enrollments,
    lessonProgress,
    liveClasses,
    exams,
    announcements,
    studyMaterials,
  } = useLmsData();

  if (!firebaseUser || !isVerified) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 dark:border-[#263449] dark:bg-[#172033]">
          <BookOpen className="mx-auto h-10 w-10 text-emerald-500" />
          <h1 className="mt-4 font-display text-2xl font-bold text-slate-900 dark:text-white">
            Sign In to View Your Learning Dashboard
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Track enrolled courses, lecture completion, personal notes, and exam results.
          </p>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'auth', mode: 'login' })}
            className="mt-6 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700"
          >
            Sign In / Create Account
          </button>
        </div>
      </div>
    );
  }

  const activeEnrollments = enrollments.filter((e) => e.status === 'active');
  const enrolledCourses = activeEnrollments
    .map((enr) => ({
      enrollment: enr,
      course: courses.find((c) => c.id === enr.courseId),
    }))
    .filter((item): item is { enrollment: typeof activeEnrollments[number]; course: Course } =>
      Boolean(item.course)
    );

  const avgProgress =
    activeEnrollments.length > 0
      ? Math.round(
          activeEnrollments.reduce((acc, e) => acc + (e.progressPercent || 0), 0) /
            activeEnrollments.length
        )
      : 0;

  const recentWatched = [...lessonProgress]
    .filter((p) => Boolean(p.lastWatchedAt))
    .sort((a, b) => (b.lastWatchedAt || '').localeCompare(a.lastWatchedAt || ''))
    .slice(0, 5)
    .map((p) => ({
      progress: p,
      lesson: lessons.find((l) => l.id === p.lessonId),
      course: courses.find((c) => c.id === p.courseId),
    }))
    .filter((x) => Boolean(x.lesson && x.course));

  const upcomingLive = liveClasses.filter((lc) => lc.status !== 'completed').slice(0, 4);
  const upcomingExams = exams.filter((ex) => ex.status === 'published').slice(0, 4);
  const latestAnnouncements = announcements.slice(0, 3);
  const recentMaterials = studyMaterials.slice(0, 4);
  const completedTotal = lessonProgress.filter((p) => p.completed).length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033]">
        <div>
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
            Student Dashboard · {profile?.educationLevel || 'Learner'}
          </p>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Welcome back, {profile?.displayName || 'Student'}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {profile?.institution
              ? `${profile.institution} · `
              : ''}
            Keep up your momentum across your enrolled courses.
          </p>
        </div>

        <div className="flex items-center gap-6">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Enrolled</p>
            <p className="font-mono-tabular text-xl font-bold text-slate-900 dark:text-white">
              {enrolledCourses.length}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Completed Lectures</p>
            <p className="font-mono-tabular text-xl font-bold text-slate-900 dark:text-white">
              {completedTotal}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Overall Progress</p>
            <p className="font-mono-tabular text-xl font-bold text-emerald-600 dark:text-emerald-400">
              {avgProgress}%
            </p>
          </div>
        </div>
      </div>

      {/* Enrolled Courses / Continue Learning */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            My Enrolled Courses
          </h2>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'explore' })}
            className="text-xs font-semibold text-emerald-600 hover:underline dark:text-emerald-400"
          >
            Browse more courses
          </button>
        </div>

        {enrolledCourses.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center dark:border-[#263449]">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              You have not enrolled in any courses yet.
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Explore our catalog and enroll in a free course to begin tracking progress.
            </p>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'explore' })}
              className="mt-4 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
            >
              Explore Courses
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {enrolledCourses.map(({ enrollment, course }) => (
              <div
                key={enrollment.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <div className="flex items-start gap-4">
                  <CourseThumbnail
                    src={course.thumbnailUrl}
                    alt={course.title}
                    title={course.title}
                    className="h-16 w-20 rounded-lg shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {course.categoryName || 'Course'}
                    </p>
                    <h3 className="mt-0.5 text-sm font-semibold text-slate-900 dark:text-white line-clamp-2">
                      {course.title}
                    </h3>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 dark:text-slate-400">
                      {enrollment.completedLessonsCount} completed
                    </span>
                    <span className="font-mono-tabular font-semibold text-emerald-600 dark:text-emerald-400">
                      {enrollment.progressPercent}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-[#0B1120]">
                    <div
                      className="h-full rounded-full bg-emerald-500"
                      style={{ width: `${enrollment.progressPercent}%` }}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({
                        page: 'lecture',
                        courseId: course.id,
                        lessonId: enrollment.lastLessonId,
                      })
                    }
                    className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                  >
                    <Play className="h-3.5 w-3.5" />
                    Continue Learning
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Activity Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recently Watched Lectures */}
        <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              Recently Watched Lectures
            </h3>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'history' })}
              className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
            >
              History
            </button>
          </div>
          {recentWatched.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
              Your recently watched lectures will appear here.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-[#263449]">
              {recentWatched.map(({ progress, lesson, course }) => (
                <button
                  key={progress.id}
                  type="button"
                  onClick={() =>
                    onNavigate({ page: 'lecture', courseId: course!.id, lessonId: lesson!.id })
                  }
                  className="flex w-full items-center justify-between gap-3 py-3 text-left hover:bg-slate-50 dark:hover:bg-[#111827]/50 px-2 rounded-lg"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {lesson!.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {course!.title} · {progress.completed ? 'Completed' : 'In Progress'}
                    </p>
                  </div>
                  <Play className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Live Classes */}
        <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="h-4 w-4 text-emerald-500" />
              Upcoming Live Classes
            </h3>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'live-classes' })}
              className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
            >
              View Schedule
            </button>
          </div>
          {upcomingLive.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
              No upcoming live classes scheduled.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-[#263449]">
              {upcomingLive.map((lc) => (
                <div key={lc.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {lc.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono-tabular">
                      {new Date(lc.scheduledAt).toLocaleString()} · {lc.instructorName}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate({ page: 'live-classes' })}
                    className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 dark:border-[#263449] dark:text-slate-200 shrink-0"
                  >
                    Details
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Exams */}
        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ClipboardCheck className="h-4 w-4 text-emerald-500" />
              Available Exams
            </h3>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'exams' })}
              className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
            >
              All Exams
            </button>
          </div>
          <div className="space-y-3">
            {upcomingExams.map((ex) => (
              <button
                key={ex.id}
                type="button"
                onClick={() => onNavigate({ page: 'exams', examId: ex.id })}
                className="w-full rounded-lg border border-slate-100 p-3 text-left hover:border-emerald-500/50 dark:border-[#263449]"
              >
                <p className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1">
                  {ex.title}
                </p>
                <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 font-mono-tabular">
                  {ex.durationMinutes} min · {ex.totalMarks} marks
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Announcements */}
        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Megaphone className="h-4 w-4 text-emerald-500" />
            Latest Announcements
          </h3>
          <div className="space-y-3">
            {latestAnnouncements.length === 0 ? (
              <p className="text-xs text-slate-500">No announcements.</p>
            ) : (
              latestAnnouncements.map((ann) => (
                <div key={ann.id} className="border-b border-slate-100 pb-3 last:border-none dark:border-[#263449]">
                  <p className="text-xs font-semibold text-slate-900 dark:text-white">
                    {ann.title}
                  </p>
                  <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                    {ann.content}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Study Materials */}
        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="h-4 w-4 text-emerald-500" />
              Study Materials
            </h3>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'materials' })}
              className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
            >
              Library
            </button>
          </div>
          <div className="space-y-2.5">
            {recentMaterials.map((mat) => (
              <button
                key={mat.id}
                type="button"
                onClick={() => onNavigate({ page: 'materials' })}
                className="w-full rounded-lg border border-slate-100 p-3 text-left hover:border-emerald-500/50 dark:border-[#263449]"
              >
                <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                  {mat.title}
                </p>
                <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {mat.courseTitle}
                </p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
