import {
  ArrowRight,
  Atom,
  BookOpen,
  Compass,
  Cpu,
  Download,
  GraduationCap,
  Layers,
  Play,
  Sigma,
  TrendingUp,
  Video,
} from 'lucide-react';
import { AppRoute, Course } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { CourseThumbnail } from '../common/CourseThumbnail';
import { CourseCardSkeleton } from '../common/Skeletons';

interface HomePageProps {
  onNavigate: (route: AppRoute) => void;
}

function getCategoryIcon(iconName?: string) {
  switch (iconName) {
    case 'Atom':
      return Atom;
    case 'Sigma':
      return Sigma;
    case 'Cpu':
      return Cpu;
    case 'BookOpen':
      return BookOpen;
    case 'GraduationCap':
      return GraduationCap;
    default:
      return Compass;
  }
}

export function HomePage({ onNavigate }: HomePageProps) {
  const {
    courses,
    categories,
    enrollments,
    siteSettings,
    loadingCatalog,
    isUsingDemoPreview,
  } = useLmsData();
  const { firebaseUser } = useAuth();

  const publishedCourses = courses.filter((c) => c.status === 'published');
  const featuredCourses = publishedCourses.filter((c) => c.isFeatured).slice(0, 4);
  const latestCourses = publishedCourses.slice(0, 4);

  const activeEnrollments = enrollments.filter((e) => e.status === 'active');
  const continueLearningItems = activeEnrollments
    .map((enr) => ({
      enrollment: enr,
      course: courses.find((c) => c.id === enr.courseId),
    }))
    .filter((item): item is { enrollment: typeof activeEnrollments[number]; course: Course } => Boolean(item.course));

  const handleContinueAction = () => {
    if (continueLearningItems.length > 0) {
      const first = continueLearningItems[0];
      onNavigate({
        page: 'lecture',
        courseId: first.course.id,
        lessonId: first.enrollment.lastLessonId,
      });
    } else if (firebaseUser) {
      onNavigate({ page: 'dashboard' });
    } else if (publishedCourses.length > 0) {
      onNavigate({ page: 'lecture', courseId: publishedCourses[0].id });
    } else {
      onNavigate({ page: 'explore' });
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-16">
      {/* 1. Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
          <p className="text-xs font-semibold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
            {siteSettings.tagline || 'Learn • Grow • Achieve'}
            {isUsingDemoPreview ? ' · Demo Curriculum Preview' : ''}
          </p>
          <h1
            className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-slate-900 dark:text-white leading-[1.12]"
            style={{ textWrap: 'balance' }}
          >
            {siteSettings.heroTitle || 'Learn Without Limits.'}
          </h1>
          <p className="max-w-xl text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            {siteSettings.heroSubtitle ||
              'Discover courses, improve your skills, and achieve your goals.'}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'explore' })}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-3 text-sm font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap"
            >
              <span>Explore Courses</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleContinueAction}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100 dark:hover:bg-[#1e2940] transition-colors whitespace-nowrap"
            >
              <Play className="h-4 w-4 text-emerald-500" />
              <span>Continue Learning</span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="relative h-full min-h-[280px] overflow-hidden rounded-2xl border border-slate-200 dark:border-[#263449] bg-[#172033]">
            <img
              src="/src/assets/images/hero_learning_academy_1795451152199.jpg"
              alt="Course Hub quiet study workspace"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B1120]/85 via-[#0B1120]/20 to-transparent" />
            <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-center justify-between gap-4 text-white">
              <div>
                <p className="text-sm font-semibold">Structured Lecture Experience</p>
                <p className="text-xs text-slate-300">
                  Chapter outlines · Slide PDFs · Personal notes · Timed exams
                </p>
              </div>
              <span className="font-mono-tabular text-xs font-medium text-emerald-300">
                {publishedCourses.length} Courses Available
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Continue Learning (Authenticated / Enrolled) */}
      {continueLearningItems.length > 0 && (
        <section className="space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                Continue Learning
              </h2>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                Pick up right where you left off in your enrolled courses.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'dashboard' })}
              className="text-sm font-semibold text-emerald-600 hover:underline dark:text-emerald-400 whitespace-nowrap"
            >
              Open Dashboard
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {continueLearningItems.map(({ enrollment, course }) => (
              <div
                key={enrollment.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <div className="flex items-start gap-4">
                  <CourseThumbnail
                    src={course.thumbnailUrl}
                    alt={course.title}
                    title={course.title}
                    className="h-16 w-20 rounded-lg shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {course.categoryName || 'Course'}
                    </p>
                    <h3 className="mt-0.5 text-sm font-semibold text-slate-900 dark:text-slate-100 line-clamp-2">
                      {course.title}
                    </h3>
                  </div>
                </div>

                <div className="mt-5 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 dark:text-slate-400">Progress</span>
                    <span className="font-mono-tabular font-semibold text-emerald-600 dark:text-emerald-400">
                      {enrollment.progressPercent}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-[#0B1120]">
                    <div
                      className="h-full rounded-full bg-emerald-500 transition-all"
                      style={{ width: `${enrollment.progressPercent}%` }}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({
                        page: 'lecture',
                        courseId: course.id,
                        lessonId: enrollment.lastLessonId,
                      })
                    }
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors"
                  >
                    <Play className="h-3.5 w-3.5" />
                    Continue Lecture
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. Featured Courses */}
      <section className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Featured Courses
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              Curated academic tracks structured by chapter and lecture.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'explore' })}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-600 hover:underline dark:text-emerald-400 whitespace-nowrap"
          >
            <span>Browse all courses</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {loadingCatalog ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[1, 2, 3, 4].map((i) => (
              <CourseCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {(featuredCourses.length > 0 ? featuredCourses : latestCourses).map((course) => (
              <CourseCard key={course.id} course={course} onNavigate={onNavigate} />
            ))}
          </div>
        )}
      </section>

      {/* 4. Popular Categories */}
      <section className="space-y-6">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Popular Categories
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Select a subject area to filter courses and study materials.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories
            .filter((c) => c.isVisible)
            .map((cat) => {
              const Icon = getCategoryIcon(cat.iconName);
              const count = publishedCourses.filter((c) => c.categoryId === cat.id).length;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => onNavigate({ page: 'explore', categoryId: cat.id })}
                  className="flex items-start gap-4 rounded-xl border border-slate-200 bg-white p-5 text-left hover:border-emerald-500/60 transition-colors dark:border-[#263449] dark:bg-[#172033] dark:hover:border-emerald-500/50"
                >
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {cat.name}
                      </h3>
                      <span className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400 shrink-0">
                        {count} {count === 1 ? 'course' : 'courses'}
                      </span>
                    </div>
                    {cat.description && (
                      <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                        {cat.description}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
        </div>
      </section>

      {/* 5. Why Choose Course Hub */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-[#263449] dark:bg-[#172033]">
        <div className="max-w-2xl">
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Why Choose Course Hub
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Engineered around distraction-free lecture viewing and measurable academic progress.
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Video,
              title: 'Quality Lessons',
              desc: 'Focused 16:9 lecture playback with clear instructor explanations and chapter sequence.',
            },
            {
              icon: Layers,
              title: 'Organized Learning',
              desc: 'Clean course → chapter → lesson structure so you always know what comes next.',
            },
            {
              icon: Download,
              title: 'Downloadable Materials',
              desc: 'Access class slides, formula sheets, and lecture PDFs directly below each video.',
            },
            {
              icon: TrendingUp,
              title: 'Progress Tracking',
              desc: 'Mark lectures complete, store personal notes per lesson, and review exam scores.',
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.title} className="space-y-2.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. Latest Courses */}
      <section className="space-y-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Latest Courses
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              Recently published programs and foundational modules.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {latestCourses.map((course) => (
            <CourseCard key={`latest_${course.id}`} course={course} onNavigate={onNavigate} />
          ))}
        </div>
      </section>

      {/* 7. Student Testimonials */}
      <section className="space-y-6">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Student Perspectives
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            How structured chapters, personal lecture notes, and chapter tests help learners stay consistent.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              name: 'Nusrat Jahan',
              role: 'HSC Science Student · Notre Dame / Viqarunnisa Batch',
              quote:
                'Having the chapter sidebar, lecture slides PDF, and personal notes tab right beneath each Physics class saved me hours when revising Vectors before board exams.',
            },
            {
              name: 'Sadia Afrin',
              role: 'Admission Candidate · Dhaka',
              quote:
                'The chapter-wise MCQ exams hide answers until submission, which makes practicing Chemistry and Higher Math genuinely realistic under timed conditions.',
            },
            {
              name: 'Rafiqul Islam',
              role: 'HSC ICT Learner · Chattogram',
              quote:
                'Every lecture in the ICT track flows cleanly from binary conversions to logic gate circuits, and marking lessons completed keeps my weekly study schedule clear.',
            },
          ].map((t) => (
            <div
              key={t.name}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033]"
            >
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                “{t.quote}”
              </p>
              <div className="mt-5 border-t border-slate-100 pt-4 dark:border-[#263449]">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">{t.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="border-t border-slate-200 pt-8 pb-4 dark:border-[#263449]">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="font-display text-base font-bold text-slate-900 dark:text-white">
              {siteSettings.siteName || 'Course Hub'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {siteSettings.tagline || 'Learn • Grow • Achieve'} · {siteSettings.contactAddress || 'Dhaka, Bangladesh'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-5 text-xs font-medium text-slate-600 dark:text-slate-400">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'info', section: 'about' })}
              className="hover:text-emerald-600 dark:hover:text-emerald-400"
            >
              About
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'info', section: 'contact' })}
              className="hover:text-emerald-600 dark:hover:text-emerald-400"
            >
              Contact
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'info', section: 'privacy' })}
              className="hover:text-emerald-600 dark:hover:text-emerald-400"
            >
              Privacy Policy
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'info', section: 'terms' })}
              className="hover:text-emerald-600 dark:hover:text-emerald-400"
            >
              Terms & Conditions
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function CourseCard({
  course,
  onNavigate,
}: {
  course: Course;
  onNavigate: (route: AppRoute) => void;
}) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white transition-colors hover:border-emerald-500/60 dark:border-[#263449] dark:bg-[#172033] dark:hover:border-emerald-500/50">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
        <CourseThumbnail
          src={course.thumbnailUrl}
          alt={course.title}
          title={course.title}
          className="h-full w-full transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </div>

      <div className="flex flex-1 flex-col justify-between p-5">
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {course.categoryName || 'General'}
            {course.level ? ` · ${course.level}` : ''}
            {course.isDemo ? ' · Demo' : ''}
          </p>
          <h3 className="mt-1.5 font-display text-base font-semibold text-slate-900 dark:text-white line-clamp-2">
            {course.title}
          </h3>
          <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 truncate">
            {course.instructorName || 'Course Hub Instructor'}
          </p>
        </div>

        <div className="mt-4 space-y-3 border-t border-slate-100 pt-3 dark:border-[#263449]">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono-tabular">
            <span>{course.totalLessons || 0} lessons</span>
            <span>{course.durationText || 'Self-paced'}</span>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="font-mono-tabular text-sm font-bold text-emerald-600 dark:text-emerald-400">
              {course.isFree ? 'Free' : `৳${course.price.toLocaleString()}`}
            </span>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'course', courseId: course.id })}
              className="rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-600 dark:bg-[#0B1120] dark:hover:bg-emerald-600 transition-colors whitespace-nowrap"
            >
              View Course
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
