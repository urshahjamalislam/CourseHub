import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Bookmark,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Download,
  FileText,
  Flag,
  Heart,
  Info,
  ListVideo,
  Lock,
  MessageSquare,
  Play,
  Save,
  Share2,
  Sparkles,
  StickyNote,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  User,
  EyeOff,
  X,
} from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  AppRoute,
  CommentItem,
  LessonContent,
  Reaction,
  ReactionType,
} from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { DEMO_LESSON_CONTENTS } from '../../data/demoCurriculum';
import {
  clampStr,
  db,
  generateDocId,
  handleFirestoreError,
  OperationType,
} from '../../lib/firebase';
import { CourseThumbnail } from '../common/CourseThumbnail';

interface LectureViewerPageProps {
  courseId: string;
  lessonId?: string;
  onNavigate: (route: AppRoute) => void;
}

type LectureTab = 'info' | 'reactions' | 'comments' | 'notes' | 'download';

export function LectureViewerPage({ courseId, lessonId, onNavigate }: LectureViewerPageProps) {
  const {
    courses,
    chapters,
    lessons,
    enrollments,
    lessonProgress,
    bookmarks,
    isUsingDemoPreview,
    recordLessonVisit,
    toggleLessonCompleted,
    savePersonalNotes,
    toggleBookmark,
    enrollInFreeCourse,
  } = useLmsData();
  const { firebaseUser, profile, isAdmin, isVerified } = useAuth();
  const { showToast, confirm } = useToast();

  const course = courses.find((c) => c.id === courseId);
  const courseChapters = useMemo(
    () => chapters.filter((ch) => ch.courseId === courseId).sort((a, b) => a.order - b.order),
    [chapters, courseId]
  );
  const courseLessons = useMemo(
    () =>
      lessons
        .filter((l) => l.courseId === courseId && (l.status === 'published' || isAdmin))
        .sort((a, b) => a.order - b.order),
    [lessons, courseId, isAdmin]
  );

  const activeLesson =
    courseLessons.find((l) => l.id === lessonId) || courseLessons[0] || null;
  const activeChapter = activeLesson
    ? courseChapters.find((ch) => ch.id === activeLesson.chapterId)
    : undefined;

  const enrollment = enrollments.find((e) => e.courseId === courseId && e.status === 'active');
  const isEnrolled = Boolean(enrollment) || isAdmin;
  const hasLessonAccess = Boolean(
    activeLesson && (isEnrolled || activeLesson.isFreePreview || isUsingDemoPreview)
  );

  const [activeTab, setActiveTab] = useState<LectureTab>('info');
  const [expandedChapters, setExpandedChapters] = useState<Record<string, boolean>>({});
  const [mobileCurriculumOpen, setMobileCurriculumOpen] = useState(false);

  const [lessonContent, setLessonContent] = useState<LessonContent | null>(null);
  const [contentLoading, setContentLoading] = useState(false);
  const [contentError, setContentError] = useState<string | null>(null);

  const [comments, setComments] = useState<CommentItem[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [personalNotesInput, setPersonalNotesInput] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [togglingComplete, setTogglingComplete] = useState(false);

  // Keep active chapter expanded
  useEffect(() => {
    if (activeChapter) {
      setExpandedChapters((prev) => ({ ...prev, [activeChapter.id]: true }));
    }
  }, [activeChapter?.id]);

  // Sync personal notes from lesson_progress
  useEffect(() => {
    if (!activeLesson) return;
    const prog = lessonProgress.find((p) => p.lessonId === activeLesson.id);
    setPersonalNotesInput(prog?.personalNotes || '');
  }, [activeLesson?.id, lessonProgress]);

  // Record visit in Firestore for authenticated students
  useEffect(() => {
    if (activeLesson && hasLessonAccess && firebaseUser && isVerified && !isUsingDemoPreview) {
      recordLessonVisit(courseId, activeLesson.id);
    }
  }, [activeLesson?.id, hasLessonAccess, firebaseUser?.uid, isVerified, isUsingDemoPreview]);

  // Load protected lesson content
  useEffect(() => {
    if (!activeLesson) return;
    setContentError(null);

    if (isUsingDemoPreview) {
      const demo = DEMO_LESSON_CONTENTS.find((lc) => lc.id === activeLesson.id) || null;
      setLessonContent(demo);
      return;
    }

    if (!hasLessonAccess) {
      setLessonContent(null);
      return;
    }

    let cancelled = false;
    setContentLoading(true);
    getDoc(doc(db, 'lesson_contents', activeLesson.id))
      .then((snap) => {
        if (cancelled) return;
        if (snap.exists()) {
          setLessonContent(snap.data() as LessonContent);
        } else {
          setLessonContent(null);
        }
        setContentLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setContentLoading(false);
        setContentError(
          err instanceof Error ? err.message : 'Unable to load lecture media. Ensure you are enrolled.'
        );
      });

    return () => {
      cancelled = true;
    };
  }, [activeLesson?.id, hasLessonAccess, isUsingDemoPreview]);

  // Subscribe to comments & reactions for active lesson
  useEffect(() => {
    if (!activeLesson || isUsingDemoPreview) {
      setComments([]);
      setReactions([]);
      return;
    }

    const commentsQuery = isAdmin
      ? query(collection(db, 'comments'), where('lessonId', '==', activeLesson.id))
      : query(
          collection(db, 'comments'),
          where('lessonId', '==', activeLesson.id),
          where('status', '==', 'visible')
        );

    const unsubComments = onSnapshot(
      commentsQuery,
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as CommentItem)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setComments(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'comments')
    );

    const unsubReactions = onSnapshot(
      query(collection(db, 'reactions'), where('lessonId', '==', activeLesson.id)),
      (snap) => {
        setReactions(snap.docs.map((d) => d.data() as Reaction));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'reactions')
    );

    return () => {
      unsubComments();
      unsubReactions();
    };
  }, [activeLesson?.id, isUsingDemoPreview, isAdmin]);

  if (!course) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Course Not Found
        </h2>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'explore' })}
          className="mt-4 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Browse Courses
        </button>
      </div>
    );
  }

  if (!activeLesson) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          No Lectures Published Yet
        </h2>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          This course currently has no published lessons.
        </p>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'course', courseId: course.id })}
          className="mt-4 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Back to Course Overview
        </button>
      </div>
    );
  }

  const currentIdx = courseLessons.findIndex((l) => l.id === activeLesson.id);
  const prevLesson = currentIdx > 0 ? courseLessons[currentIdx - 1] : null;
  const nextLesson =
    currentIdx >= 0 && currentIdx < courseLessons.length - 1 ? courseLessons[currentIdx + 1] : null;

  const isCompleted = lessonProgress.some(
    (p) => p.lessonId === activeLesson.id && p.completed
  );
  const isBookmarked = bookmarks.some(
    (b) => b.itemType === 'lesson' && b.itemId === activeLesson.id
  );
  const userReaction = firebaseUser
    ? reactions.find((r) => r.userId === firebaseUser.uid)
    : undefined;

  const reactionCounts = {
    like: reactions.filter((r) => r.type === 'like').length,
    helpful: reactions.filter((r) => r.type === 'helpful').length,
    love: reactions.filter((r) => r.type === 'love').length,
    dislike: reactions.filter((r) => r.type === 'dislike').length,
  };

  const completedCount = courseLessons.filter((l) =>
    lessonProgress.some((p) => p.lessonId === l.id && p.completed)
  ).length;
  const courseProgressPct =
    courseLessons.length > 0 ? Math.round((completedCount / courseLessons.length) * 100) : 0;

  const handleToggleCompleted = async () => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in with a verified account to track progress.', 'info');
      onNavigate({ page: 'auth', mode: 'login' });
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Sign in as admin and seed demo courses to persist progress.', 'info');
      return;
    }
    setTogglingComplete(true);
    try {
      await toggleLessonCompleted(course.id, activeLesson.id, !isCompleted);
      showToast(
        !isCompleted ? 'Lecture Completed' : 'Marked Incomplete',
        activeLesson.title,
        'success'
      );
    } catch (err) {
      showToast('Error', err instanceof Error ? err.message : 'Unable to update progress', 'error');
    } finally {
      setTogglingComplete(false);
    }
  };

  const handleBookmarkToggle = async () => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to bookmark lectures.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to Firestore to save bookmarks.', 'info');
      return;
    }
    try {
      const added = await toggleBookmark({
        itemType: 'lesson',
        itemId: activeLesson.id,
        courseId: course.id,
        title: activeLesson.title,
        subtitle: `${course.title} · ${activeChapter?.title || 'Chapter'}`,
      });
      showToast(added ? 'Bookmarked' : 'Bookmark Removed', activeLesson.title, 'success');
    } catch (err) {
      showToast('Error', err instanceof Error ? err.message : 'Bookmark failed', 'error');
    }
  };

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}/?course=${course.id}&lesson=${activeLesson.id}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('Link Copied', 'Lecture link copied to clipboard.', 'success');
    } catch {
      showToast('Share Lecture', shareUrl, 'info');
    }
  };

  const handleReaction = async (type: ReactionType) => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to react to lectures.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to Firestore to save reactions.', 'info');
      return;
    }
    const id = `${firebaseUser.uid}_${activeLesson.id}`;
    try {
      if (userReaction?.type === type) {
        await deleteDoc(doc(db, 'reactions', id));
      } else {
        await setDoc(doc(db, 'reactions', id), {
          id,
          userId: firebaseUser.uid,
          courseId: course.id,
          lessonId: activeLesson.id,
          type,
          createdAt: new Date().toISOString(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `reactions/${id}`);
    }
  };

  const handleAddComment = async (parentId?: string) => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to post comments.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to Firestore to post comments.', 'info');
      return;
    }
    const text = (parentId ? replyText : newCommentText).trim();
    if (!text) return;

    setSubmittingComment(true);
    const id = generateDocId('cmt');
    const now = new Date().toISOString();
    try {
      await setDoc(doc(db, 'comments', id), {
        id,
        courseId: course.id,
        lessonId: activeLesson.id,
        userId: firebaseUser.uid,
        authorName: clampStr(profile?.displayName || firebaseUser.displayName || 'Student', 120),
        authorPhoto: clampStr(profile?.photoURL || firebaseUser.photoURL || '', 500),
        parentId: parentId || '',
        content: clampStr(text, 2000),
        status: 'visible',
        reportCount: 0,
        createdAt: now,
        updatedAt: now,
      });
      if (parentId) {
        setReplyText('');
        setReplyToId(null);
      } else {
        setNewCommentText('');
      }
      showToast('Posted', 'Your comment has been added.', 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `comments/${id}`);
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleReportComment = async (c: CommentItem) => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to report comments.', 'info');
      return;
    }
    try {
      await updateDoc(doc(db, 'comments', c.id), {
        reportCount: (c.reportCount || 0) + 1,
        status: 'reported',
        updatedAt: new Date().toISOString(),
      });
      showToast('Reported', 'Comment flagged for administrator review.', 'info');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `comments/${c.id}`);
    }
  };

  const handleModerateComment = async (c: CommentItem, action: 'hide' | 'delete') => {
    if (!isAdmin) return;
    if (action === 'delete') {
      const ok = await confirm({
        title: 'Delete Comment',
        message: 'Permanently delete this student comment?',
        confirmLabel: 'Delete',
        destructive: true,
      });
      if (!ok) return;
      await deleteDoc(doc(db, 'comments', c.id));
      showToast('Comment Deleted', undefined, 'info');
    } else {
      await updateDoc(doc(db, 'comments', c.id), {
        status: c.status === 'hidden' ? 'visible' : 'hidden',
        updatedAt: new Date().toISOString(),
      });
      showToast('Moderation Updated', undefined, 'success');
    }
  };

  const handleSaveNotes = async () => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to save personal lecture notes.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to Firestore to save personal notes.', 'info');
      return;
    }
    setSavingNotes(true);
    try {
      await savePersonalNotes(course.id, activeLesson.id, personalNotesInput);
      showToast('Notes Saved', 'Personal notes synced to your account.', 'success');
    } catch (err) {
      showToast('Error', err instanceof Error ? err.message : 'Unable to save notes', 'error');
    } finally {
      setSavingNotes(false);
    }
  };

  const renderSidebarCurriculum = () => (
    <div className="flex flex-col h-full">
      <div className="border-b border-slate-200 p-4 dark:border-[#263449]">
        <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">Course Outline</p>
        <h2 className="mt-1 font-display text-base font-bold text-slate-900 dark:text-white line-clamp-2">
          {course.title}
        </h2>
        <div className="mt-3 space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Course Progress</span>
            <span className="font-mono-tabular font-semibold text-emerald-600 dark:text-emerald-400">
              {completedCount}/{courseLessons.length} ({courseProgressPct}%)
            </span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-[#0B1120]">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all"
              style={{ width: `${courseProgressPct}%` }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-[#263449]">
        {courseChapters.map((ch) => {
          const chLessons = courseLessons.filter((l) => l.chapterId === ch.id);
          const expanded = Boolean(expandedChapters[ch.id]);
          return (
            <div key={ch.id}>
              <button
                type="button"
                onClick={() =>
                  setExpandedChapters((prev) => ({ ...prev, [ch.id]: !prev[ch.id] }))
                }
                className="flex w-full items-center justify-between gap-2 px-4 py-3 text-left hover:bg-slate-50 dark:hover:bg-[#1e2940] transition-colors"
              >
                <div className="flex items-center gap-2 min-w-0">
                  {expanded ? (
                    <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                  )}
                  <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 line-clamp-2">
                    {ch.title}
                  </span>
                </div>
                <span className="font-mono-tabular text-[11px] text-slate-400 shrink-0">
                  {chLessons.length}
                </span>
              </button>

              {expanded && (
                <div className="bg-slate-50/70 dark:bg-[#0B1120]/50 py-1">
                  {chLessons.map((les) => {
                    const isActive = les.id === activeLesson.id;
                    const lesDone = lessonProgress.some(
                      (p) => p.lessonId === les.id && p.completed
                    );
                    const lesUnlocked = isEnrolled || les.isFreePreview || isUsingDemoPreview;
                    return (
                      <button
                        key={les.id}
                        type="button"
                        onClick={() => {
                          setMobileCurriculumOpen(false);
                          onNavigate({ page: 'lecture', courseId: course.id, lessonId: les.id });
                        }}
                        className={`flex w-full items-start gap-3 px-4 py-2.5 text-left transition-colors ${
                          isActive
                            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-[#172033]'
                        }`}
                      >
                        <span className="mt-0.5 shrink-0">
                          {lesDone ? (
                            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                          ) : lesUnlocked ? (
                            <Play
                              className={`h-4 w-4 ${
                                isActive ? 'text-emerald-500' : 'text-slate-400'
                              }`}
                            />
                          ) : (
                            <Lock className="h-4 w-4 text-slate-400" />
                          )}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium leading-snug line-clamp-2">
                            {les.title}
                          </p>
                          <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 font-mono-tabular">
                            Lec {String(les.lessonNumber).padStart(2, '0')} · {les.durationText || 'Video'}
                            {les.isFreePreview && !isEnrolled ? ' · Preview' : ''}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const rootComments = comments.filter((c) => !c.parentId);
  const getReplies = (parentId: string) => comments.filter((c) => c.parentId === parentId);

  return (
    <div className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6 lg:px-8">
      {/* Top Breadcrumb + Mobile Chapter Drawer Trigger */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => onNavigate({ page: 'course', courseId: course.id })}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-600 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-400"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>{course.title}</span>
        </button>

        <button
          type="button"
          onClick={() => setMobileCurriculumOpen(true)}
          className="xl:hidden inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-200"
        >
          <ListVideo className="h-4 w-4 text-emerald-500" />
          <span>Course Chapters ({courseLessons.length})</span>
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Main Lecture Content Area */}
        <div className="xl:col-span-8 space-y-6 min-w-0">
          {/* 16:9 Video Player Container */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-black dark:border-[#263449]">
            <div className="relative aspect-video w-full bg-[#070B14]">
              {!hasLessonAccess ? (
                <div className="flex h-full flex-col items-center justify-center p-6 text-center text-white">
                  <Lock className="h-10 w-10 text-emerald-400" />
                  <h3 className="mt-3 font-display text-lg font-bold">
                    Enroll to Watch This Lecture
                  </h3>
                  <p className="mt-1 max-w-md text-xs text-slate-300 leading-relaxed">
                    This lecture is part of the full course curriculum. Enroll in {course.title} to
                    unlock all video lectures, notes, and downloadable slide PDFs.
                  </p>
                  <button
                    type="button"
                    onClick={async () => {
                      if (course.isFree && firebaseUser && isVerified) {
                        await enrollInFreeCourse(course);
                        showToast('Enrolled!', 'Lecture unlocked.', 'success');
                      } else {
                        onNavigate({ page: 'course', courseId: course.id });
                      }
                    }}
                    className="mt-4 rounded-lg bg-emerald-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700"
                  >
                    {course.isFree && firebaseUser ? 'Enroll Free & Unlock' : 'Go to Course Enrollment'}
                  </button>
                </div>
              ) : contentLoading ? (
                <div className="flex h-full items-center justify-center text-sm text-slate-400">
                  Loading lecture player...
                </div>
              ) : contentError ? (
                <div className="flex h-full flex-col items-center justify-center p-6 text-center text-slate-200">
                  <AlertCircle className="h-9 w-9 text-amber-400" />
                  <p className="mt-3 text-sm font-semibold">Video Unavailable</p>
                  <p className="mt-1 max-w-md text-xs text-slate-400">{contentError}</p>
                </div>
              ) : lessonContent?.youtubeVideoId ? (
                <iframe
                  title={activeLesson.title}
                  src={`https://www.youtube-nocookie.com/embed/${lessonContent.youtubeVideoId}?rel=0&modestbranding=1`}
                  className="h-full w-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              ) : (
                <div className="flex h-full flex-col items-center justify-center p-6 text-center text-slate-300">
                  <AlertCircle className="h-9 w-9 text-slate-500" />
                  <p className="mt-3 text-sm font-semibold">Video Unavailable</p>
                  <p className="mt-1 text-xs text-slate-400">
                    No YouTube video has been attached to this lesson yet.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Below Video Header & Actions */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 dark:border-[#263449] dark:bg-[#172033] space-y-5">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
              <div className="space-y-1.5 min-w-0">
                <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                  {activeChapter?.title || 'Chapter'} · Lecture {String(activeLesson.lessonNumber).padStart(2, '0')}
                </p>
                <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {activeLesson.title}
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {course.instructorName || 'Instructor'} · {course.title} · Uploaded{' '}
                  {new Date(activeLesson.createdAt).toLocaleDateString()}
                  {typeof activeLesson.viewsCount === 'number'
                    ? ` · ${activeLesson.viewsCount.toLocaleString()} views`
                    : ''}
                </p>
              </div>

              <button
                type="button"
                disabled={togglingComplete}
                onClick={handleToggleCompleted}
                className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  isCompleted
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                    : 'border border-slate-200 bg-slate-50 text-slate-800 hover:bg-emerald-50 hover:border-emerald-500 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100 dark:hover:bg-[#1e2940]'
                }`}
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>{isCompleted ? 'Completed' : 'Mark as Completed'}</span>
              </button>
            </div>

            {/* Action Buttons Row */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-[#263449]">
              <button
                type="button"
                onClick={() => handleReaction('like')}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                  userReaction?.type === 'like'
                    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#111827]'
                }`}
              >
                <ThumbsUp className="h-3.5 w-3.5" />
                <span>Like</span>
                <span className="font-mono-tabular">
                  ({(activeLesson.likesCount || 0) + reactionCounts.like})
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleReaction('dislike')}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                  userReaction?.type === 'dislike'
                    ? 'border-rose-500 bg-rose-500/15 text-rose-600 dark:text-rose-400'
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#111827]'
                }`}
              >
                <ThumbsDown className="h-3.5 w-3.5" />
                <span>Dislike</span>
              </button>

              <button
                type="button"
                onClick={handleBookmarkToggle}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                  isBookmarked
                    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#111827]'
                }`}
              >
                <Bookmark className="h-3.5 w-3.5" />
                <span>{isBookmarked ? 'Bookmarked' : 'Bookmark'}</span>
              </button>

              <button
                type="button"
                onClick={handleShare}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-300 dark:hover:bg-[#111827]"
              >
                <Share2 className="h-3.5 w-3.5" />
                <span>Share</span>
              </button>
            </div>
          </div>

          {/* ACS-Style Tabs */}
          <div className="rounded-2xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
            <div className="flex overflow-x-auto border-b border-slate-200 px-3 pt-2 dark:border-[#263449] gap-1">
              {[
                { id: 'info' as const, label: 'Info', icon: Info },
                { id: 'reactions' as const, label: 'Reactions', icon: Heart },
                { id: 'comments' as const, label: `Comments (${comments.length})`, icon: MessageSquare },
                { id: 'notes' as const, label: 'Notes', icon: StickyNote },
                { id: 'download' as const, label: 'Download', icon: Download },
              ].map((tab) => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`inline-flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      active
                        ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                        : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="p-5 sm:p-6">
              {/* Tab 1: Info */}
              {activeTab === 'info' && (
                <div className="space-y-5">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                      Lecture Overview
                    </h3>
                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {lessonContent?.description ||
                        'Detailed concept lecture structured for systematic comprehension.'}
                    </p>
                  </div>

                  {lessonContent?.learningObjectives &&
                    lessonContent.learningObjectives.length > 0 && (
                      <div>
                        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                          Learning Objectives
                        </h3>
                        <ul className="mt-2 space-y-2">
                          {lessonContent.learningObjectives.map((obj, idx) => (
                            <li
                              key={idx}
                              className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300"
                            >
                              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                              <span>{obj}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100 pt-4 dark:border-[#263449]">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                        <User className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="text-sm font-semibold text-slate-900 dark:text-white">
                          {course.instructorName}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {course.instructorTitle || 'Course Instructor'}
                        </p>
                      </div>
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                      <p>Chapter: {activeChapter?.title || 'Core Module'}</p>
                      <p>Duration: {activeLesson.durationText || 'Self-paced'}</p>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 dark:text-slate-500 border-t border-slate-100 pt-3 dark:border-[#263449]">
                    Note: Embedded Unlisted YouTube lectures are accessible to enrolled students within
                    Course Hub; embedding alone does not constitute DRM protection against direct link
                    sharing.
                  </p>
                </div>
              )}

              {/* Tab 2: Reactions */}
              {activeTab === 'reactions' && (
                <div className="space-y-5">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                      How did you find this lecture?
                    </h3>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                      Your reaction helps instructors measure clarity and pacing.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { type: 'like' as const, label: 'Like', icon: ThumbsUp, count: reactionCounts.like },
                      { type: 'helpful' as const, label: 'Helpful', icon: Sparkles, count: reactionCounts.helpful },
                      { type: 'love' as const, label: 'Love', icon: Heart, count: reactionCounts.love },
                      { type: 'dislike' as const, label: 'Needs Clarity', icon: ThumbsDown, count: reactionCounts.dislike },
                    ].map((r) => {
                      const Icon = r.icon;
                      const active = userReaction?.type === r.type;
                      return (
                        <button
                          key={r.type}
                          type="button"
                          onClick={() => handleReaction(r.type)}
                          className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-4 transition-colors ${
                            active
                              ? 'border-emerald-500 bg-emerald-500/12 text-emerald-600 dark:text-emerald-400'
                              : 'border-slate-200 hover:bg-slate-50 dark:border-[#263449] dark:hover:bg-[#111827]'
                          }`}
                        >
                          <Icon className="h-5 w-5" />
                          <span className="text-xs font-semibold">{r.label}</span>
                          <span className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400">
                            {r.count}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 3: Comments */}
              {activeTab === 'comments' && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <textarea
                      rows={3}
                      value={newCommentText}
                      onChange={(e) => setNewCommentText(e.target.value)}
                      placeholder={
                        firebaseUser
                          ? 'Ask a question or share a takeaway from this lecture...'
                          : 'Sign in to post a question or comment...'
                      }
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                    />
                    <div className="flex justify-end">
                      <button
                        type="button"
                        disabled={submittingComment || !newCommentText.trim()}
                        onClick={() => handleAddComment()}
                        className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                      >
                        {submittingComment ? 'Posting...' : 'Post Comment'}
                      </button>
                    </div>
                  </div>

                  <div className="divide-y divide-slate-100 dark:divide-[#263449]">
                    {rootComments.length === 0 ? (
                      <p className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                        No comments on this lecture yet. Be the first to ask a question.
                      </p>
                    ) : (
                      rootComments.map((c) => {
                        const replies = getReplies(c.id);
                        return (
                          <div key={c.id} className="py-4 space-y-3">
                            <div className="flex items-start justify-between gap-3">
                              <div className="space-y-1 min-w-0">
                                <p className="text-xs font-semibold text-slate-900 dark:text-white">
                                  {c.authorName}{' '}
                                  <span className="font-normal text-slate-400">
                                    · {new Date(c.createdAt).toLocaleDateString()}
                                    {c.status !== 'visible' ? ` · [${c.status}]` : ''}
                                  </span>
                                </p>
                                <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                                  {c.content}
                                </p>
                                <div className="flex items-center gap-4 pt-1 text-xs text-slate-500">
                                  <button
                                    type="button"
                                    onClick={() => setReplyToId(replyToId === c.id ? null : c.id)}
                                    className="hover:text-emerald-600 dark:hover:text-emerald-400 font-medium"
                                  >
                                    Reply
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleReportComment(c)}
                                    className="inline-flex items-center gap-1 hover:text-amber-600"
                                  >
                                    <Flag className="h-3 w-3" />
                                    Report
                                  </button>
                                  {isAdmin && (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() => handleModerateComment(c, 'hide')}
                                        className="inline-flex items-center gap-1 hover:text-sky-500"
                                      >
                                        <EyeOff className="h-3 w-3" />
                                        {c.status === 'hidden' ? 'Unhide' : 'Hide'}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleModerateComment(c, 'delete')}
                                        className="inline-flex items-center gap-1 hover:text-rose-500"
                                      >
                                        <Trash2 className="h-3 w-3" />
                                        Delete
                                      </button>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            {replyToId === c.id && (
                              <div className="ml-6 flex gap-2">
                                <input
                                  type="text"
                                  value={replyText}
                                  onChange={(e) => setReplyText(e.target.value)}
                                  placeholder="Write a reply..."
                                  className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleAddComment(c.id)}
                                  className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white"
                                >
                                  Send
                                </button>
                              </div>
                            )}

                            {replies.length > 0 && (
                              <div className="ml-6 space-y-2 border-l border-slate-200 pl-4 dark:border-[#263449]">
                                {replies.map((r) => (
                                  <div key={r.id} className="text-xs">
                                    <p className="font-semibold text-slate-900 dark:text-white">
                                      {r.authorName}{' '}
                                      <span className="font-normal text-slate-400">
                                        · {new Date(r.createdAt).toLocaleDateString()}
                                      </span>
                                    </p>
                                    <p className="mt-0.5 text-slate-600 dark:text-slate-300">
                                      {r.content}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* Tab 4: Notes */}
              {activeTab === 'notes' && (
                <div className="space-y-6">
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-[#263449] dark:bg-[#0B1120]">
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                      Instructor Lecture Notes & Key Formulas
                    </h3>
                    <pre className="mt-2 whitespace-pre-wrap font-sans text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {lessonContent?.lectureNotesMarkdown ||
                        'No instructor summary notes uploaded for this lecture yet.'}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-semibold text-slate-900 dark:text-white">
                        My Personal Study Notes
                      </label>
                      <span className="text-xs text-slate-400">Private to your account</span>
                    </div>
                    <textarea
                      rows={5}
                      value={personalNotesInput}
                      onChange={(e) => setPersonalNotesInput(e.target.value)}
                      placeholder="Write formulas, timestamps, or questions to review before exams..."
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
                    />
                    <div className="flex justify-end">
                      <button
                        type="button"
                        disabled={savingNotes}
                        onClick={handleSaveNotes}
                        className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                      >
                        <Save className="h-3.5 w-3.5" />
                        <span>{savingNotes ? 'Saving...' : 'Save Notes'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 5: Download */}
              {activeTab === 'download' && (
                <div className="space-y-4">
                  {!hasLessonAccess ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Enroll in this course to access downloadable class slides and notes.
                    </p>
                  ) : !lessonContent?.downloadsEnabled ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Downloads are currently disabled by the instructor for this lecture.
                    </p>
                  ) : !lessonContent.slidesUrl &&
                    !lessonContent.notesPdfUrl &&
                    !lessonContent.attachmentUrl ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      No downloadable PDFs or attachments uploaded for this lecture.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {lessonContent.slidesUrl && (
                        <a
                          href={lessonContent.slidesUrl}
                          download={lessonContent.slidesName || 'lecture-slides.pdf'}
                          className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4 hover:border-emerald-500 transition-colors dark:border-[#263449] dark:bg-[#0B1120]"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <FileText className="h-5 w-5 text-emerald-500 shrink-0" />
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                                Class Slides PDF
                              </p>
                              <p className="text-xs text-slate-500 truncate">
                                {lessonContent.slidesName || 'Slides.pdf'}
                              </p>
                            </div>
                          </div>
                          <Download className="h-4 w-4 text-emerald-500 shrink-0" />
                        </a>
                      )}

                      {lessonContent.notesPdfUrl && (
                        <a
                          href={lessonContent.notesPdfUrl}
                          download={lessonContent.notesPdfName || 'lecture-notes.pdf'}
                          className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4 hover:border-emerald-500 transition-colors dark:border-[#263449] dark:bg-[#0B1120]"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <FileText className="h-5 w-5 text-emerald-500 shrink-0" />
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                                Lecture Notes PDF
                              </p>
                              <p className="text-xs text-slate-500 truncate">
                                {lessonContent.notesPdfName || 'Notes.pdf'}
                              </p>
                            </div>
                          </div>
                          <Download className="h-4 w-4 text-emerald-500 shrink-0" />
                        </a>
                      )}

                      {lessonContent.attachmentUrl && (
                        <a
                          href={lessonContent.attachmentUrl}
                          download={lessonContent.attachmentName || 'attachment.pdf'}
                          className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4 hover:border-emerald-500 transition-colors dark:border-[#263449] dark:bg-[#0B1120]"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <FileText className="h-5 w-5 text-emerald-500 shrink-0" />
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                                Additional Attachment
                              </p>
                              <p className="text-xs text-slate-500 truncate">
                                {lessonContent.attachmentName || 'Resource'}
                              </p>
                            </div>
                          </div>
                          <Download className="h-4 w-4 text-emerald-500 shrink-0" />
                        </a>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Related Lectures (Previous & Next) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {prevLesson ? (
              <RelatedLectureCard
                direction="Previous Lecture"
                lesson={prevLesson}
                chapterTitle={
                  courseChapters.find((c) => c.id === prevLesson.chapterId)?.title || 'Chapter'
                }
                completed={lessonProgress.some((p) => p.lessonId === prevLesson.id && p.completed)}
                onClick={() =>
                  onNavigate({ page: 'lecture', courseId: course.id, lessonId: prevLesson.id })
                }
              />
            ) : (
              <div />
            )}

            {nextLesson && (
              <RelatedLectureCard
                direction="Next Lecture"
                lesson={nextLesson}
                chapterTitle={
                  courseChapters.find((c) => c.id === nextLesson.chapterId)?.title || 'Chapter'
                }
                completed={lessonProgress.some((p) => p.lessonId === nextLesson.id && p.completed)}
                onClick={() =>
                  onNavigate({ page: 'lecture', courseId: course.id, lessonId: nextLesson.id })
                }
              />
            )}
          </div>
        </div>

        {/* Desktop Right Lecture Sidebar */}
        <aside className="hidden xl:block xl:col-span-4 sticky top-20 h-[calc(100vh-6rem)] overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
          {renderSidebarCurriculum()}
        </aside>
      </div>

      {/* Mobile Curriculum Slide-Over Drawer */}
      {mobileCurriculumOpen && (
        <div className="fixed inset-0 z-50 flex justify-end xl:hidden">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={() => setMobileCurriculumOpen(false)}
          />
          <div className="relative z-10 flex w-80 max-w-[90vw] flex-col bg-white dark:bg-[#172033] h-full border-l border-slate-200 dark:border-[#263449]">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 dark:border-[#263449]">
              <span className="text-sm font-semibold text-slate-900 dark:text-white">
                Chapters & Lessons
              </span>
              <button
                type="button"
                onClick={() => setMobileCurriculumOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-[#111827]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">{renderSidebarCurriculum()}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function RelatedLectureCard({
  direction,
  lesson,
  chapterTitle,
  completed,
  onClick,
}: {
  direction: string;
  lesson: { title: string; thumbnailUrl?: string; durationText?: string };
  chapterTitle: string;
  completed: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-3.5 text-left hover:border-emerald-500/60 transition-colors dark:border-[#263449] dark:bg-[#172033]"
    >
      <CourseThumbnail
        src={lesson.thumbnailUrl}
        alt={lesson.title}
        title={lesson.title}
        className="h-16 w-24 rounded-lg shrink-0"
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
          <span>{direction}</span>
          {direction.startsWith('Next') ? (
            <ArrowRight className="h-3.5 w-3.5" />
          ) : (
            <ArrowLeft className="h-3.5 w-3.5" />
          )}
        </div>
        <p className="mt-1 text-xs font-semibold text-slate-900 dark:text-white line-clamp-1">
          {lesson.title}
        </p>
        <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
          {chapterTitle} · {lesson.durationText || 'Video'}
          {completed ? ' · Completed' : ''}
        </p>
      </div>
    </button>
  );
}
