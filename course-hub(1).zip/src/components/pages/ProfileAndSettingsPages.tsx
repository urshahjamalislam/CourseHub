import React, { useState } from 'react';
import {
  Bell,
  Bookmark,
  CheckCheck,
  History,
  Play,
  Save,
  Sun,
  Moon,
  Trash2,
  User,
} from 'lucide-react';
import { AppRoute } from '../../types/lms';
import { useAuth } from '../../contexts/AuthContext';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useTheme } from '../../contexts/ThemeContext';
import { useToast } from '../../contexts/ToastContext';

export function ProfilePage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { firebaseUser, profile, isVerified, updateProfileData } = useAuth();
  const { showToast } = useToast();

  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [educationLevel, setEducationLevel] = useState(profile?.educationLevel || 'HSC');
  const [institution, setInstitution] = useState(profile?.institution || '');
  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [saving, setSaving] = useState(false);

  if (!firebaseUser || !isVerified) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Profile Requires Sign In
        </h1>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'auth', mode: 'login' })}
          className="mt-4 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Sign In
        </button>
      </div>
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfileData({
        displayName,
        phone,
        educationLevel,
        institution,
        photoURL,
      });
      showToast('Profile Updated', 'Your student profile has been saved.', 'success');
    } catch (err) {
      showToast('Update Failed', err instanceof Error ? err.message : 'Unable to save', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Student Profile
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Manage your personal academic details and account preferences.
        </p>
      </div>

      <form
        onSubmit={handleSave}
        className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-5"
      >
        <div className="flex items-center gap-4 border-b border-slate-100 pb-5 dark:border-[#263449]">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-600 text-xl font-bold text-white overflow-hidden">
            {photoURL ? (
              <img
                src={photoURL}
                alt={displayName}
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
            ) : (
              (displayName || 'S').charAt(0).toUpperCase()
            )}
          </div>
          <div>
            <p className="text-base font-semibold text-slate-900 dark:text-white">
              {profile?.displayName}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {profile?.email} · Role: {profile?.role}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Full Name
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Education Level
            </label>
            <select
              value={educationLevel}
              onChange={(e) => setEducationLevel(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="SSC">SSC</option>
              <option value="HSC">HSC</option>
              <option value="Admission">Admission</option>
              <option value="Undergraduate">Undergraduate</option>
              <option value="Skill Track">Skill Track</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Institution
            </label>
            <input
              type="text"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Profile Picture URL
          </label>
          <input
            type="url"
            value={photoURL}
            onChange={(e) => setPhotoURL(e.target.value)}
            placeholder="https://..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? 'Saving...' : 'Save Profile'}
          </button>
        </div>
      </form>
    </div>
  );
}

export function BookmarksPage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { bookmarks, toggleBookmark } = useLmsData();
  const { firebaseUser } = useAuth();
  const { showToast } = useToast();

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Saved Bookmarks
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Quickly return to saved lectures and study materials.
        </p>
      </div>

      {!firebaseUser ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center dark:border-[#263449] dark:bg-[#172033]">
          <p className="text-sm text-slate-600 dark:text-slate-400">Sign in to view your bookmarks.</p>
        </div>
      ) : bookmarks.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
          <Bookmark className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            No bookmarks yet
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Click the Bookmark icon on any lecture or study material to save it here.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
          {bookmarks.map((bm) => (
            <div key={bm.id} className="flex items-center justify-between gap-4 p-4">
              <button
                type="button"
                onClick={() => {
                  if (bm.itemType === 'lesson' && bm.courseId) {
                    onNavigate({ page: 'lecture', courseId: bm.courseId, lessonId: bm.itemId });
                  } else if (bm.itemType === 'course') {
                    onNavigate({ page: 'course', courseId: bm.itemId });
                  } else {
                    onNavigate({ page: 'materials' });
                  }
                }}
                className="text-left min-w-0 flex-1"
              >
                <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                  {bm.title}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                  {bm.itemType.toUpperCase()} · {bm.subtitle || 'Saved item'}
                </p>
              </button>
              <button
                type="button"
                aria-label="Remove bookmark"
                onClick={async () => {
                  await toggleBookmark({
                    itemType: bm.itemType,
                    itemId: bm.itemId,
                    courseId: bm.courseId,
                    title: bm.title,
                  });
                  showToast('Bookmark Removed', undefined, 'info');
                }}
                className="rounded-lg p-2 text-slate-400 hover:text-rose-500"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function LearningHistoryPage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { lessonProgress, lessons, courses } = useLmsData();
  const { firebaseUser } = useAuth();

  const items = [...lessonProgress]
    .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''))
    .map((p) => ({
      progress: p,
      lesson: lessons.find((l) => l.id === p.lessonId),
      course: courses.find((c) => c.id === p.courseId),
    }))
    .filter((x) => Boolean(x.lesson && x.course));

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Learning History
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Chronological record of lectures watched, completed, and annotated.
        </p>
      </div>

      {!firebaseUser ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center dark:border-[#263449] dark:bg-[#172033]">
          <p className="text-sm text-slate-500">Sign in to view your learning history.</p>
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
          <History className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            No learning history recorded yet
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
          {items.map(({ progress, lesson, course }) => (
            <button
              key={progress.id}
              type="button"
              onClick={() =>
                onNavigate({ page: 'lecture', courseId: course!.id, lessonId: lesson!.id })
              }
              className="flex w-full items-center justify-between gap-4 p-4 text-left hover:bg-slate-50 dark:hover:bg-[#1e2940]"
            >
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                  {lesson!.title}
                </p>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {course!.title} · {progress.completed ? 'Completed' : 'Watched'} ·{' '}
                  {new Date(progress.updatedAt).toLocaleString()}
                </p>
              </div>
              <Play className="h-4 w-4 text-emerald-500 shrink-0" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function NotificationsPage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useLmsData();
  const { firebaseUser } = useAuth();

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Notifications
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Enrollment confirmations, new lectures, live classes, and exam updates.
          </p>
        </div>
        {notifications.some((n) => !n.read) && (
          <button
            type="button"
            onClick={markAllNotificationsRead}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#172033]"
          >
            <CheckCheck className="h-4 w-4 text-emerald-500" />
            Mark all read
          </button>
        )}
      </div>

      {!firebaseUser ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center dark:border-[#263449] dark:bg-[#172033]">
          <p className="text-sm text-slate-500">Sign in to view notifications.</p>
        </div>
      ) : notifications.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
          <Bell className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            All caught up
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-[#263449] dark:border-[#263449] dark:bg-[#172033]">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`flex items-start justify-between gap-4 p-4 ${
                !n.read ? 'bg-emerald-500/5' : ''
              }`}
            >
              <div className="space-y-1">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">
                  {n.title} {!n.read && <span className="text-xs text-emerald-500">· Unread</span>}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-300">{n.message}</p>
                <p className="text-[11px] text-slate-400 font-mono-tabular">
                  {new Date(n.createdAt).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {!n.read && (
                  <button
                    type="button"
                    onClick={() => markNotificationRead(n.id)}
                    className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600 dark:border-[#263449] dark:text-slate-300"
                  >
                    Mark read
                  </button>
                )}
                {n.link?.startsWith('course:') && (
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({ page: 'course', courseId: n.link!.replace('course:', '') })
                    }
                    className="rounded-lg bg-emerald-600 px-2.5 py-1 text-xs font-semibold text-white"
                  >
                    Open
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function SettingsPage({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const { theme, setTheme } = useTheme();

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Preferences & Settings
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Customize your viewing experience on Course Hub.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033] space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">Appearance Theme</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Switch between Dark Navy and crisp Light Mode. Preference is saved automatically.
            </p>
          </div>
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-[#0B1120]">
            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold ${
                theme === 'dark'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-[#172033] dark:text-white'
                  : 'text-slate-500'
              }`}
            >
              <Moon className="h-3.5 w-3.5" />
              Dark
            </button>
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold ${
                theme === 'light'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-[#172033] dark:text-white'
                  : 'text-slate-500'
              }`}
            >
              <Sun className="h-3.5 w-3.5" />
              Light
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 border-t border-slate-100 pt-5 dark:border-[#263449]">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">Account Profile</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Update your display name, institution, or phone number.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'profile' })}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
          >
            <User className="h-3.5 w-3.5" />
            Edit Profile
          </button>
        </div>
      </div>
    </div>
  );
}

export function InfoPage({
  section,
  onNavigate,
}: {
  section: 'about' | 'contact' | 'privacy' | 'terms';
  onNavigate: (route: AppRoute) => void;
}) {
  const { siteSettings } = useLmsData();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-8 dark:border-[#263449] dark:bg-[#172033] space-y-4">
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white capitalize">
          {section === 'privacy'
            ? 'Privacy Policy'
            : section === 'terms'
            ? 'Terms & Conditions'
            : section === 'contact'
            ? 'Contact Course Hub'
            : `About ${siteSettings.siteName || 'Course Hub'}`}
        </h1>

        {section === 'about' && (
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Course Hub is a structured online learning management platform built around clarity,
            organized chapter-by-chapter video lectures, downloadable slides, interactive assessments,
            and verifiable progress tracking.
          </p>
        )}

        {section === 'contact' && (
          <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
            <p>Email: {siteSettings.contactEmail || 'support@coursehub.edu'}</p>
            <p>Phone: {siteSettings.contactPhone || '+880 1700-000000'}</p>
            <p>Address: {siteSettings.contactAddress || 'Dhaka, Bangladesh'}</p>
          </div>
        )}

        {section === 'privacy' && (
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Student email addresses, phone numbers, and academic institution details are stored
            securely in Firestore and isolated from public profiles. Course Hub never stores payment
            card numbers or mobile wallet PINs.
          </p>
        )}

        {section === 'terms' && (
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Enrolled students receive personal academic access to course lectures and study materials.
            Redistribution of paid resources or automated scraping is prohibited.
          </p>
        )}

        <div className="pt-4">
          <button
            type="button"
            onClick={() => onNavigate({ page: 'home' })}
            className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}
