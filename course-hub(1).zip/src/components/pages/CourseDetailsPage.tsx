import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  CreditCard,
  Globe,
  Lock,
  Play,
  ShieldAlert,
  User,
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { AppRoute, PaymentGateway } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { CourseThumbnail } from '../common/CourseThumbnail';
import { db, generateDocId, clampStr, handleFirestoreError, OperationType } from '../../lib/firebase';

interface CourseDetailsPageProps {
  courseId: string;
  onNavigate: (route: AppRoute) => void;
}

interface GatewayStatus {
  id: PaymentGateway;
  name: string;
  configured: boolean;
  requiredEnvVars: string[];
  description: string;
}

export function CourseDetailsPage({ courseId, onNavigate }: CourseDetailsPageProps) {
  const { courses, chapters, lessons, enrollments, enrollInFreeCourse, isUsingDemoPreview } =
    useLmsData();
  const { firebaseUser, isAdmin, isVerified } = useAuth();
  const { showToast } = useToast();

  const course = courses.find((c) => c.id === courseId);
  const courseChapters = chapters
    .filter((ch) => ch.courseId === courseId)
    .sort((a, b) => a.order - b.order);
  const courseLessons = lessons
    .filter((l) => l.courseId === courseId && (l.status === 'published' || isAdmin))
    .sort((a, b) => a.order - b.order);

  const [expandedChapters, setExpandedChapters] = useState<Record<string, boolean>>({});
  const [enrolling, setEnrolling] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [gateways, setGateways] = useState<GatewayStatus[]>([]);
  const [selectedGateway, setSelectedGateway] = useState<PaymentGateway>('bkash');
  const [transactionRef, setTransactionRef] = useState('');
  const [paymentMessage, setPaymentMessage] = useState<string | null>(null);
  const [submittingPayment, setSubmittingPayment] = useState(false);

  useEffect(() => {
    const initial: Record<string, boolean> = {};
    courseChapters.forEach((ch, idx) => {
      initial[ch.id] = idx === 0;
    });
    setExpandedChapters(initial);
  }, [courseId, courseChapters.length]);

  if (!course) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Course Not Found
        </h2>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          This course may have been unpublished or moved.
        </p>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'explore' })}
          className="mt-6 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          Back to Explore Courses
        </button>
      </div>
    );
  }

  const enrollment = enrollments.find((e) => e.courseId === course.id && e.status === 'active');
  const isEnrolled = Boolean(enrollment) || isAdmin;

  const openPaymentModal = async () => {
    setPaymentModalOpen(true);
    setPaymentMessage(null);
    try {
      const res = await fetch('/api/payments/gateways');
      if (res.ok) {
        const data = await res.json();
        setGateways(data.gateways || []);
      }
    } catch {
      // ignore fetch error
    }
  };

  const handleEnrollClick = async () => {
    if (!firebaseUser) {
      showToast('Sign In Required', 'Please sign in to enroll in this course.', 'info');
      onNavigate({ page: 'auth', mode: 'login' });
      return;
    }
    if (!isVerified) {
      showToast('Email Verification Required', 'Verify your email before enrolling.', 'warning');
      onNavigate({ page: 'auth', mode: 'login' });
      return;
    }

    if (course.isFree) {
      if (isUsingDemoPreview) {
        showToast(
          'Demo Preview Mode',
          'Previewing demo lectures directly! Sign in as admin to seed courses into Firestore for persistent enrollment.',
          'info'
        );
        onNavigate({ page: 'lecture', courseId: course.id });
        return;
      }
      setEnrolling(true);
      try {
        await enrollInFreeCourse(course);
        showToast('Enrolled Successfully', `Welcome to ${course.title}!`, 'success');
        onNavigate({ page: 'lecture', courseId: course.id });
      } catch (err) {
        showToast('Enrollment Failed', err instanceof Error ? err.message : 'Unable to enroll', 'error');
      } finally {
        setEnrolling(false);
      }
    } else {
      await openPaymentModal();
    }
  };

  const handlePaymentSubmit = async () => {
    if (!firebaseUser || !isVerified) return;
    if (isUsingDemoPreview) {
      setPaymentMessage(
        'Demo preview catalog is active. Seed courses to Firestore in the Admin Panel before creating payment records.'
      );
      return;
    }

    setSubmittingPayment(true);
    setPaymentMessage(null);
    try {
      const token = await firebaseUser.getIdToken();
      const res = await fetch('/api/payments/initiate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          gateway: selectedGateway,
          courseId: course.id,
          amount: course.price,
        }),
      });
      const payload = await res.json();

      if (res.status === 503 && payload.configured === false) {
        if (transactionRef.trim().length >= 4) {
          const paymentId = generateDocId('pay');
          const now = new Date().toISOString();
          await setDoc(doc(db, 'payments', paymentId), {
            id: paymentId,
            userId: firebaseUser.uid,
            courseId: course.id,
            courseTitle: clampStr(course.title, 160),
            amount: course.price,
            currency: 'BDT',
            gateway: selectedGateway,
            status: 'pending',
            transactionRef: clampStr(transactionRef, 128),
            createdAt: now,
          });
          showToast(
            'Payment Reference Submitted',
            'Your transaction is pending admin verification. Access unlocks once verified.',
            'info'
          );
          setPaymentModalOpen(false);
          setTransactionRef('');
          return;
        }
        setPaymentMessage(payload.message);
      } else if (res.ok) {
        setPaymentMessage(payload.message);
      } else {
        setPaymentMessage(payload.error || 'Unable to initiate payment.');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'payments');
    } finally {
      setSubmittingPayment(false);
    }
  };

  const selectedGwInfo = gateways.find((g) => g.id === selectedGateway);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-10">
      <button
        type="button"
        onClick={() => onNavigate({ page: 'explore' })}
        className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-400"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Courses
      </button>

      {/* Course Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 space-y-5">
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
            {course.categoryName || 'Course'} · {course.level || 'HSC'} · {course.language || 'Bangla & English'}
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white leading-tight">
            {course.title}
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {course.description}
          </p>

          <div className="flex flex-wrap items-center gap-6 pt-2 text-sm text-slate-600 dark:text-slate-400">
            <span className="flex items-center gap-2">
              <User className="h-4 w-4 text-emerald-500" />
              <span className="font-medium text-slate-900 dark:text-slate-200">
                {course.instructorName || 'Instructor'}
              </span>
            </span>
            <span className="flex items-center gap-2 font-mono-tabular">
              <BookOpen className="h-4 w-4 text-emerald-500" />
              {courseChapters.length} chapters · {courseLessons.length} lessons
            </span>
            <span className="flex items-center gap-2 font-mono-tabular">
              <Clock className="h-4 w-4 text-emerald-500" />
              {course.durationText || 'Self-paced'}
            </span>
            <span className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-emerald-500" />
              {course.language || 'Bangla & English'}
            </span>
          </div>

          {/* Learning Outcomes */}
          {course.outcomes && course.outcomes.length > 0 && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033]">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                What You Will Learn
              </h2>
              <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {course.outcomes.map((out, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{out}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Requirements */}
          {course.requirements && course.requirements.length > 0 && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-[#263449] dark:bg-[#172033]">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Course Requirements
              </h2>
              <ul className="mt-3 list-disc pl-5 space-y-1.5 text-sm text-slate-600 dark:text-slate-300">
                {course.requirements.map((req, i) => (
                  <li key={i}>{req}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Curriculum */}
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Course Curriculum
            </h2>
            <div className="space-y-3">
              {courseChapters.map((ch) => {
                const chLessons = courseLessons.filter((l) => l.chapterId === ch.id);
                const open = Boolean(expandedChapters[ch.id]);
                return (
                  <div
                    key={ch.id}
                    className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]"
                  >
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedChapters((prev) => ({ ...prev, [ch.id]: !prev[ch.id] }))
                      }
                      className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left hover:bg-slate-50 dark:hover:bg-[#1e2940] transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {open ? (
                          <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                            {ch.title}
                          </p>
                          {ch.description && (
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                              {ch.description}
                            </p>
                          )}
                        </div>
                      </div>
                      <span className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400 shrink-0">
                        {chLessons.length} lectures
                      </span>
                    </button>

                    {open && (
                      <div className="divide-y divide-slate-100 border-t border-slate-100 dark:divide-[#263449] dark:border-[#263449]">
                        {chLessons.map((lesson) => {
                          const canOpen = isEnrolled || lesson.isFreePreview;
                          return (
                            <button
                              key={lesson.id}
                              type="button"
                              onClick={() => {
                                if (canOpen) {
                                  onNavigate({
                                    page: 'lecture',
                                    courseId: course.id,
                                    lessonId: lesson.id,
                                  });
                                } else {
                                  showToast(
                                    'Enrollment Required',
                                    'Enroll in this course to unlock restricted lectures.',
                                    'info'
                                  );
                                }
                              }}
                              className="flex w-full items-center justify-between gap-4 px-5 py-3 text-left hover:bg-slate-50 dark:hover:bg-[#111827]/50 transition-colors"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                {canOpen ? (
                                  <Play className="h-4 w-4 text-emerald-500 shrink-0" />
                                ) : (
                                  <Lock className="h-4 w-4 text-slate-400 shrink-0" />
                                )}
                                <span className="text-sm text-slate-800 dark:text-slate-200 truncate">
                                  {lesson.title}
                                </span>
                              </div>
                              <div className="flex items-center gap-3 shrink-0 text-xs">
                                {lesson.isFreePreview && !isEnrolled && (
                                  <span className="font-medium text-emerald-600 dark:text-emerald-400">
                                    Free Preview
                                  </span>
                                )}
                                <span className="font-mono-tabular text-slate-500 dark:text-slate-400">
                                  {lesson.durationText || 'Video'}
                                </span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sticky Enrollment Card */}
        <div className="lg:col-span-4 lg:sticky lg:top-24">
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
            <div className="aspect-[16/10] w-full bg-slate-900">
              <CourseThumbnail
                src={course.bannerUrl || course.thumbnailUrl}
                alt={course.title}
                title={course.title}
                className="h-full w-full"
              />
            </div>
            <div className="p-6 space-y-5">
              <div className="flex items-baseline justify-between">
                <span className="font-mono-tabular text-2xl font-bold text-slate-900 dark:text-white">
                  {course.isFree ? 'Free' : `৳${course.price.toLocaleString()}`}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {course.isFree ? 'Open enrollment' : 'Full course access'}
                </span>
              </div>

              {isEnrolled ? (
                <button
                  type="button"
                  onClick={() =>
                    onNavigate({
                      page: 'lecture',
                      courseId: course.id,
                      lessonId: enrollment?.lastLessonId || courseLessons[0]?.id,
                    })
                  }
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-3 text-sm font-semibold text-white hover:bg-emerald-700 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  {enrollment ? `Continue Learning (${enrollment.progressPercent}%)` : 'Open Lecture Player'}
                </button>
              ) : (
                <div className="space-y-2.5">
                  <button
                    type="button"
                    disabled={enrolling}
                    onClick={handleEnrollClick}
                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60 transition-colors"
                  >
                    {course.isFree ? <BookOpen className="h-4 w-4" /> : <CreditCard className="h-4 w-4" />}
                    {enrolling ? 'Enrolling...' : course.isFree ? 'Enroll Now (Free)' : 'Enroll Now'}
                  </button>

                  {courseLessons.some((l) => l.isFreePreview) && (
                    <button
                      type="button"
                      onClick={() => {
                        const preview = courseLessons.find((l) => l.isFreePreview);
                        if (preview) {
                          onNavigate({ page: 'lecture', courseId: course.id, lessonId: preview.id });
                        }
                      }}
                      className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 px-5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827] transition-colors"
                    >
                      <Play className="h-4 w-4 text-emerald-500" />
                      Watch Free Preview
                    </button>
                  )}
                </div>
              )}

              <div className="border-t border-slate-100 pt-4 text-xs text-slate-500 dark:border-[#263449] dark:text-slate-400 space-y-1.5">
                <p>Instructor: {course.instructorName} ({course.instructorTitle || 'Faculty'})</p>
                <p>Includes chapter lecture notes & downloadable slide PDFs</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bangladesh Payment Gateway Checkout Modal */}
      {paymentModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-[#263449] dark:bg-[#172033] space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Course Enrollment Checkout
                </h3>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {course.title} · <span className="font-mono-tabular font-semibold">৳{course.price.toLocaleString()} BDT</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPaymentModalOpen(false)}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {(['bkash', 'nagad', 'rocket', 'sslcommerz'] as PaymentGateway[]).map((gw) => {
                const info = gateways.find((g) => g.id === gw);
                const active = selectedGateway === gw;
                return (
                  <button
                    key={gw}
                    type="button"
                    onClick={() => setSelectedGateway(gw)}
                    className={`rounded-xl border p-3 text-left transition-colors ${
                      active
                        ? 'border-emerald-500 bg-emerald-500/10'
                        : 'border-slate-200 hover:border-slate-300 dark:border-[#263449] dark:hover:border-slate-600'
                    }`}
                  >
                    <p className="text-sm font-semibold text-slate-900 dark:text-white uppercase">
                      {gw}
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                      {info?.configured ? 'Gateway Configured' : 'Manual / Needs API Keys'}
                    </p>
                  </button>
                );
              })}
            </div>

            {selectedGwInfo && !selectedGwInfo.configured && (
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs text-amber-800 dark:text-amber-200 space-y-1.5">
                <div className="flex items-center gap-2 font-semibold">
                  <ShieldAlert className="h-4 w-4 shrink-0" />
                  <span>Live {selectedGwInfo.name} API Credentials Not Configured</span>
                </div>
                <p>
                  Payments are never simulated. For automated verification, configure{' '}
                  <span className="font-mono-tabular">{selectedGwInfo.requiredEnvVars.join(', ')}</span>{' '}
                  on the server, or submit a verified Transaction Reference below for admin approval.
                </p>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Transaction Reference (TrxID) for Admin Verification
              </label>
              <input
                type="text"
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder="e.g. TRX9A8B7C6D"
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
              />
            </div>

            {paymentMessage && (
              <p className="text-xs text-rose-600 dark:text-rose-400 leading-relaxed">
                {paymentMessage}
              </p>
            )}

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setPaymentModalOpen(false)}
                className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 dark:border-[#263449] dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submittingPayment}
                onClick={handlePaymentSubmit}
                className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
              >
                {submittingPayment ? 'Processing...' : 'Submit Payment Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
