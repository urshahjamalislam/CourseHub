import { useMemo, useState } from 'react';
import { Bookmark, Download, Eye, FileText, Search, X } from 'lucide-react';
import { MaterialType, StudyMaterial } from '../../types/lms';
import { useLmsData } from '../../contexts/LmsDataContext';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';

export function StudyMaterialsPage() {
  const { studyMaterials, courses, bookmarks, toggleBookmark, isUsingDemoPreview } = useLmsData();
  const { firebaseUser, isVerified } = useAuth();
  const { showToast } = useToast();

  const [queryText, setQueryText] = useState('');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState<'all' | MaterialType>('all');
  const [previewMaterial, setPreviewMaterial] = useState<StudyMaterial | null>(null);

  const filtered = useMemo(() => {
    const q = queryText.trim().toLowerCase();
    return studyMaterials.filter((m) => {
      if (courseFilter !== 'all' && m.courseId !== courseFilter) return false;
      if (typeFilter !== 'all' && m.type !== typeFilter) return false;
      if (q) {
        const hit =
          m.title.toLowerCase().includes(q) ||
          (m.description || '').toLowerCase().includes(q) ||
          (m.courseTitle || '').toLowerCase().includes(q);
        if (!hit) return false;
      }
      return true;
    });
  }, [studyMaterials, queryText, courseFilter, typeFilter]);

  const handleBookmark = async (mat: StudyMaterial) => {
    if (!firebaseUser || !isVerified) {
      showToast('Sign In Required', 'Sign in to bookmark study materials.', 'info');
      return;
    }
    if (isUsingDemoPreview) {
      showToast('Demo Preview', 'Seed demo courses to save bookmarks.', 'info');
      return;
    }
    const added = await toggleBookmark({
      itemType: 'material',
      itemId: mat.id,
      courseId: mat.courseId,
      title: mat.title,
      subtitle: mat.courseTitle || 'Study Material',
    });
    showToast(added ? 'Bookmarked' : 'Bookmark Removed', mat.title, 'success');
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          Study Materials Library
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Preview and download PDF lecture notes, class slides, formula sheets, and worksheets.
        </p>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-[#263449] dark:bg-[#172033]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder="Search materials..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
          />
        </div>

        <select
          aria-label="Filter materials by course"
          value={courseFilter}
          onChange={(e) => setCourseFilter(e.target.value)}
          className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
        >
          <option value="all">All Courses</option>
          {courses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.title}
            </option>
          ))}
        </select>

        <select
          aria-label="Filter materials by type"
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value as 'all' | MaterialType)}
          className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 dark:border-[#263449] dark:bg-[#0B1120] dark:text-slate-100"
        >
          <option value="all">All Resource Types</option>
          <option value="pdf_notes">PDF Notes</option>
          <option value="slides">Class Slides</option>
          <option value="worksheet">Worksheets</option>
          <option value="book">Books & Guides</option>
          <option value="assignment">Assignments</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
          <FileText className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            No study materials found
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((mat) => {
            const bookmarked = bookmarks.some(
              (b) => b.itemType === 'material' && b.itemId === mat.id
            );
            return (
              <div
                key={mat.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                      {mat.type.replace('_', ' ').toUpperCase()} · {mat.courseTitle || 'Course'}
                    </span>
                    <button
                      type="button"
                      aria-label="Bookmark material"
                      onClick={() => handleBookmark(mat)}
                      className={`rounded-lg p-1 ${
                        bookmarked
                          ? 'text-emerald-500'
                          : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                      }`}
                    >
                      <Bookmark className="h-4 w-4" />
                    </button>
                  </div>
                  <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
                    {mat.title}
                  </h3>
                  {mat.description && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {mat.description}
                    </p>
                  )}
                </div>

                <div className="mt-5 flex items-center gap-2 border-t border-slate-100 pt-4 dark:border-[#263449]">
                  <button
                    type="button"
                    onClick={() => setPreviewMaterial(mat)}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
                  >
                    <Eye className="h-3.5 w-3.5" />
                    Preview PDF
                  </button>
                  {mat.downloadsEnabled && (
                    <a
                      href={mat.fileUrl}
                      download={mat.fileName || 'study-material.pdf'}
                      className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PDF Preview Modal */}
      {previewMaterial && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-xs"
        >
          <div className="flex h-[85vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-[#263449] dark:bg-[#172033]">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-[#263449]">
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {previewMaterial.title}
                </h3>
                <p className="text-xs text-slate-500 truncate">{previewMaterial.courseTitle}</p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewMaterial(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-[#111827]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 bg-slate-100 dark:bg-[#0B1120]">
              <iframe
                title={previewMaterial.title}
                src={previewMaterial.fileUrl}
                className="h-full w-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
