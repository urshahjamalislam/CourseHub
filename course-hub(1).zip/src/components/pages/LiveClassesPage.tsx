import { useState } from 'react';
import { Calendar, Clock, ExternalLink, PlayCircle, Video } from 'lucide-react';
import { useLmsData } from '../../contexts/LmsDataContext';

export function LiveClassesPage() {
  const { liveClasses, courses } = useLmsData();
  const [courseFilter, setCourseFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'scheduled' | 'live' | 'completed'>('all');

  const filtered = liveClasses
    .filter((lc) => (courseFilter === 'all' ? true : lc.courseId === courseFilter))
    .filter((lc) => (statusFilter === 'all' ? true : lc.status === statusFilter))
    .sort((a, b) => (a.scheduledAt || '').localeCompare(b.scheduledAt || ''));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Live Classes & Recordings
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Join scheduled interactive sessions or watch recorded workshops.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <select
            aria-label="Filter live classes by course"
            value={courseFilter}
            onChange={(e) => setCourseFilter(e.target.value)}
            className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
          >
            <option value="all">All Courses</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter live classes by status"
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(e.target.value as 'all' | 'scheduled' | 'live' | 'completed')
            }
            className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 dark:border-[#263449] dark:bg-[#172033] dark:text-slate-100"
          >
            <option value="all">All Status</option>
            <option value="live">Live Now</option>
            <option value="scheduled">Upcoming</option>
            <option value="completed">Recordings</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center dark:border-[#263449]">
          <Video className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            No live classes match your filter
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filtered.map((lc) => (
            <div
              key={lc.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-[#263449] dark:bg-[#172033]"
            >
              <div className="space-y-2">
                <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  {lc.status === 'live'
                    ? 'Live Session Active'
                    : lc.status === 'completed'
                    ? 'Recorded Session'
                    : 'Scheduled'}
                  {' · '}
                  {lc.courseTitle || 'Course'}
                </p>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  {lc.title}
                </h3>
                {lc.description && (
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {lc.description}
                  </p>
                )}
              </div>

              <div className="mt-5 space-y-3 border-t border-slate-100 pt-4 dark:border-[#263449]">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono-tabular">
                  <span className="inline-flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-emerald-500" />
                    {new Date(lc.scheduledAt).toLocaleString()}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-emerald-500" />
                    {lc.durationMinutes || 60} min · {lc.instructorName}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {lc.status !== 'completed' && lc.meetingUrl && (
                    <a
                      href={lc.meetingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Join Live Class
                    </a>
                  )}
                  {lc.recordingUrl && (
                    <a
                      href={lc.recordingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-[#263449] dark:text-slate-200 dark:hover:bg-[#111827]"
                    >
                      <PlayCircle className="h-3.5 w-3.5 text-emerald-500" />
                      Watch Recording
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
