export type UserRole = 'student' | 'instructor' | 'admin';

export interface InstructorPermissions {
  canCreateLessons?: boolean;
  canEditLessons?: boolean;
  canManageMaterials?: boolean;
  canManageLiveClasses?: boolean;
  canCreateExams?: boolean;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phone?: string;
  photoURL?: string;
  educationLevel?: string;
  institution?: string;
  role: UserRole;
  instructorPermissions?: InstructorPermissions;
  createdAt: string;
  updatedAt: string;
}

export interface PublicProfile {
  uid: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  title?: string;
  bio?: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  iconName?: string;
  isVisible: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export type CourseLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'HSC' | 'Admission';
export type PublishStatus = 'draft' | 'published';

export interface Course {
  id: string;
  title: string;
  slug: string;
  description?: string;
  thumbnailUrl?: string;
  bannerUrl?: string;
  categoryId: string;
  categoryName?: string;
  instructorId: string;
  instructorName?: string;
  instructorTitle?: string;
  level?: CourseLevel;
  language?: string;
  price: number;
  isFree: boolean;
  status: PublishStatus;
  isFeatured: boolean;
  isDemo?: boolean;
  requirements?: string[];
  outcomes?: string[];
  totalChapters?: number;
  totalLessons?: number;
  durationText?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface Lesson {
  id: string;
  courseId: string;
  chapterId: string;
  title: string;
  lessonNumber: number;
  order: number;
  durationText?: string;
  thumbnailUrl?: string;
  isFreePreview: boolean;
  status: PublishStatus;
  viewsCount?: number;
  likesCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface LessonContent {
  id: string;
  courseId: string;
  chapterId: string;
  isFreePreview: boolean;
  youtubeVideoId?: string;
  description?: string;
  learningObjectives?: string[];
  lectureNotesMarkdown?: string;
  slidesUrl?: string;
  slidesName?: string;
  notesPdfUrl?: string;
  notesPdfName?: string;
  attachmentUrl?: string;
  attachmentName?: string;
  downloadsEnabled: boolean;
  assignmentText?: string;
  quizId?: string;
  updatedAt: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  courseTitle?: string;
  status: 'active' | 'pending' | 'revoked';
  paymentId?: string;
  lastLessonId?: string;
  progressPercent: number;
  completedLessonsCount: number;
  enrolledAt: string;
  updatedAt: string;
}

export interface LessonProgress {
  id: string;
  userId: string;
  courseId: string;
  lessonId: string;
  completed: boolean;
  personalNotes?: string;
  lastWatchedAt?: string;
  updatedAt: string;
}

export interface CommentItem {
  id: string;
  courseId: string;
  lessonId?: string;
  userId: string;
  authorName: string;
  authorPhoto?: string;
  parentId?: string;
  content: string;
  status: 'visible' | 'hidden' | 'reported';
  reportCount: number;
  createdAt: string;
  updatedAt: string;
}

export type ReactionType = 'like' | 'helpful' | 'love' | 'dislike';

export interface Reaction {
  id: string;
  userId: string;
  courseId: string;
  lessonId: string;
  type: ReactionType;
  createdAt: string;
}

export interface BookmarkItem {
  id: string;
  userId: string;
  itemType: 'lesson' | 'material' | 'course';
  itemId: string;
  courseId?: string;
  title: string;
  subtitle?: string;
  createdAt: string;
}

export type MaterialType = 'pdf_notes' | 'slides' | 'book' | 'worksheet' | 'assignment';

export interface StudyMaterial {
  id: string;
  courseId: string;
  courseTitle?: string;
  title: string;
  type: MaterialType;
  description?: string;
  fileUrl: string;
  fileName?: string;
  downloadsEnabled: boolean;
  uploadedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LiveClass {
  id: string;
  courseId: string;
  courseTitle?: string;
  title: string;
  instructorId?: string;
  instructorName: string;
  scheduledAt: string;
  durationMinutes?: number;
  meetingUrl?: string;
  recordingUrl?: string;
  status: 'scheduled' | 'live' | 'completed';
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export type ExamType = 'mcq' | 'practice' | 'chapter' | 'full_course';

export interface Exam {
  id: string;
  courseId: string;
  courseTitle?: string;
  chapterId?: string;
  title: string;
  examType: ExamType;
  durationMinutes: number;
  totalMarks: number;
  practiceMode: boolean;
  status: PublishStatus;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Question {
  id: string;
  examId: string;
  courseId: string;
  prompt: string;
  options: string[];
  marks: number;
  order: number;
  createdAt: string;
}

export interface QuestionAnswer {
  id: string;
  examId: string;
  courseId: string;
  correctIndex: number;
  explanation?: string;
}

export interface ExamResult {
  id: string;
  userId: string;
  examId: string;
  courseId: string;
  examTitle?: string;
  answers: Record<string, number>;
  score?: number;
  totalMarks?: number;
  percentage?: number;
  graded: boolean;
  submittedAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  type: 'course' | 'lesson' | 'live_class' | 'exam' | 'announcement' | 'reply' | 'enrollment';
  title: string;
  message: string;
  link?: string;
  read: boolean;
  createdAt: string;
}

export interface Announcement {
  id: string;
  courseId?: string;
  courseTitle?: string;
  title: string;
  content: string;
  authorName: string;
  createdAt: string;
  updatedAt: string;
}

export type PaymentGateway = 'bkash' | 'nagad' | 'rocket' | 'sslcommerz';

export interface PaymentRecord {
  id: string;
  userId: string;
  courseId: string;
  courseTitle?: string;
  amount: number;
  currency: string;
  gateway: PaymentGateway;
  status: 'pending' | 'verified' | 'failed' | 'refunded';
  transactionRef?: string;
  createdAt: string;
  verifiedAt?: string;
}

export interface SiteSettings {
  id: string;
  siteName: string;
  tagline: string;
  heroTitle?: string;
  heroSubtitle?: string;
  contactEmail?: string;
  contactPhone?: string;
  contactAddress?: string;
  defaultTheme: 'dark' | 'light';
  allowRegistration: boolean;
  updatedAt: string;
}

export type AppRoute =
  | { page: 'home' }
  | { page: 'explore'; query?: string; categoryId?: string }
  | { page: 'course'; courseId: string }
  | { page: 'lecture'; courseId: string; lessonId?: string }
  | { page: 'dashboard' }
  | { page: 'live-classes' }
  | { page: 'exams'; examId?: string }
  | { page: 'materials' }
  | { page: 'community'; courseId?: string }
  | { page: 'bookmarks' }
  | { page: 'history' }
  | { page: 'notifications' }
  | { page: 'profile' }
  | { page: 'settings' }
  | { page: 'auth'; mode?: 'login' | 'signup' | 'forgot' }
  | { page: 'instructor' }
  | { page: 'admin'; tab?: AdminTab }
  | { page: 'info'; section: 'about' | 'contact' | 'privacy' | 'terms' };

export type AdminTab =
  | 'overview'
  | 'courses'
  | 'builder'
  | 'categories'
  | 'instructors'
  | 'students'
  | 'enrollments'
  | 'live_classes'
  | 'exams'
  | 'materials'
  | 'announcements'
  | 'comments'
  | 'payments'
  | 'reports'
  | 'settings';
